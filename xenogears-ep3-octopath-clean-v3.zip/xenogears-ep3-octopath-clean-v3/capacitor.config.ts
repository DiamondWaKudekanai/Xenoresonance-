export interface CapacitorConfig {
  appId: string;
  appName: string;
  webDir: string;
  bundledWebRuntime?: boolean;
  server?: {
    androidScheme?: string;
    cleartext?: boolean;
  };
  android?: {
    allowMixedContent?: boolean;
    backgroundColor?: string;
    captureInput?: boolean;
    webContentsDebuggingEnabled?: boolean;
  };
  plugins?: {
    StatusBar?: {
      overlaysWebView?: boolean;
      style?: string;
      backgroundColor?: string;
    };
    ScreenOrientation?: {
      lock?: 'landscape';
    };
    SplashScreen?: {
      launchShowDuration?: number;
      backgroundColor?: string;
      androidScaleType?: string;
      showSpinner?: boolean;
    };
  };
}

const config: CapacitorConfig = {
  appId: 'com.xenoresonance.episode3',
  appName: 'Xenogears Episode III: Cradle of Nisan',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https',
    cleartext: false,
  },
  android: {
    allowMixedContent: false,
    backgroundColor: '#090c14',
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    StatusBar: {
      overlaysWebView: true,
      style: 'DARK',
      backgroundColor: '#090c14',
    },
    ScreenOrientation: {
      lock: 'landscape',
    },
    SplashScreen: {
      launchShowDuration: 600,
      backgroundColor: '#090c14',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false,
    },
  },
};

export default config;
