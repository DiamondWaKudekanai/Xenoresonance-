import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { createInitialInventory, createInitialParty } from '../data/initialParty';
import { ITEMS } from '../data/itemsAndGear';
import { getMapById, MAP_REGISTRY } from '../data/maps/mapRegistry';
import { CUTSCENE_SCRIPTS, NPC_DIALOGUES } from '../data/storyEpisode3';
import {
  AppConfig,
  BattleContextData,
  DialogueLine,
  Direction,
  GameState,
  GraphicsQuality,
  InteractablePrompt,
  InventoryEntry,
  MapId,
  PartyMember,
  SaveSlotData,
} from '../types/rpg';
import { AudioManager } from './AudioManager';
import { getMemberStats } from './CombatRules';
import { EventDirector } from './EventDirector';
import { PixelTextureFactory } from './PixelTextureFactory';
import {
  deleteSlot,
  exportSaveToJson,
  importSaveFromJson,
  loadAllSlots,
  loadAppConfig,
  saveAppConfig,
  saveSlot,
} from './SaveManager';
import { SpriteSheetRegistry } from './SpriteAnimator';

export type ActiveOverlay =
  | null
  | 'main_menu'
  | 'save_menu'
  | 'config_modal'
  | 'continue_modal'
  | 'inn_modal'
  | 'armory_shop'
  | 'item_shop'
  | 'map_drawer';

export interface ActiveDialogueState {
  lines: DialogueLine[];
  index: number;
  onComplete?: () => void;
}

export interface GameStateContextValue {
  gameState: GameState;
  setGameState: (s: GameState) => void;
  mapId: MapId;
  playerPos: { x: number; z: number; facing: Direction };
  updatePlayerPos: (x: number, z: number, facing: Direction) => void;
  playtimeSeconds: number;
  gil: number;
  party: PartyMember[];
  inventory: InventoryEntry[];
  openedChests: string[];
  questFlags: Record<string, boolean>;
  visitedMaps: MapId[];
  config: AppConfig;
  saveSlots: Array<SaveSlotData | null>;
  activeOverlay: ActiveOverlay;
  setActiveOverlay: (ov: ActiveOverlay) => void;
  activeDialogue: ActiveDialogueState | null;
  activePrompt: InteractablePrompt | null;
  setActivePrompt: (p: InteractablePrompt | null) => void;
  battleContext: BattleContextData | null;
  screenFade: number; // 0..1
  screenFlash: string | null;
  toastMessage: string | null;
  showToast: (msg: string) => void;

  // Actions
  startNewGame: (skipAtelierIntro?: boolean) => void;
  continueFromSlot: (slotId: 1 | 2 | 3) => boolean;
  saveToSlot: (slotId: 1 | 2 | 3) => SaveSlotData;
  deleteSaveSlot: (slotId: 1 | 2 | 3) => void;
  exportSlotJson: (slotId: 1 | 2 | 3) => string | null;
  importSlotJson: (slotId: 1 | 2 | 3, json: string) => { ok: boolean; error?: string };
  updateAudioConfig: (patch: Partial<AppConfig['audio']>) => void;
  setGraphicsQuality: (q: GraphicsQuality) => void;
  setShowTouchControls: (show: boolean) => void;

  // World & Exploration Actions
  warpToMap: (
    targetMap: MapId,
    x: number,
    z: number,
    facing: Direction,
    playDoorSfx?: boolean
  ) => void;
  triggerInteract: (onFaceNpc?: (npcId: string) => void) => void;
  advanceDialogue: () => void;
  playCutscene: (scriptId: string) => void;
  startBattle: (
    enemyIds: string[],
    opts?: {
      isBoss?: boolean;
      allowGears?: boolean;
      arenaTheme?: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps';
      victoryFlag?: string;
    }
  ) => void;
  completeBattleVictory: (
    updatedParty: PartyMember[],
    gilGain: number,
    droppedItems: string[],
    victoryFlag?: string
  ) => void;
  completeBattleFlee: (updatedParty: PartyMember[]) => void;
  triggerGameOver: () => void;
  returnToTitle: () => void;

  // RPG Economy / Party Actions
  restAtInn: (cost: number) => boolean;
  buyItem: (itemId: string) => boolean;
  sellItem: (itemId: string) => boolean;
  useConsumableItem: (itemId: string, memberId: PartyMember['id']) => boolean;
  equipItem: (memberId: PartyMember['id'], itemId: string) => boolean;
  swapPartyFormation: (idxA: number, idxB: number) => void;
  consumeBattleItem: (itemId: string) => void;
}

const GameStateContext = createContext<GameStateContextValue | null>(null);

function getAutostartMode(): 'none' | 'town' | 'battle' {
  if (typeof window === 'undefined') return 'none';
  const v = new URLSearchParams(window.location.search).get('autostart');
  if (v === '1') return 'town';
  if (v === 'battle') return 'battle';
  return 'none';
}

export const GameStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const autostartMode = useMemo(() => getAutostartMode(), []);

  const [gameState, setGameStateRaw] = useState<GameState>(
    autostartMode === 'battle'
      ? 'BATTLE'
      : autostartMode === 'town'
        ? 'PLAYING_TOWN'
        : 'BOOT_LOGO'
  );
  const [mapId, setMapId] = useState<MapId>(
    autostartMode === 'battle' ? 'dungeon_zeboim_ruins' : 'town_nisan'
  );
  const [playerPos, setPlayerPos] = useState<{ x: number; z: number; facing: Direction }>({
    x: 15,
    z: 17,
    facing: 'N',
  });
  const [playtimeSeconds, setPlaytimeSeconds] = useState(0);
  const [gil, setGil] = useState(650);
  const [party, setParty] = useState<PartyMember[]>(() => createInitialParty());
  const [inventory, setInventory] = useState<InventoryEntry[]>(() => createInitialInventory());
  const [openedChests, setOpenedChests] = useState<string[]>([]);
  const [questFlags, setQuestFlags] = useState<Record<string, boolean>>({});
  const [visitedMaps, setVisitedMaps] = useState<MapId[]>(['town_nisan', 'interior_atelier']);
  const [config, setConfig] = useState<AppConfig>(() => loadAppConfig());
  const [saveSlots, setSaveSlots] = useState<Array<SaveSlotData | null>>(() => loadAllSlots());
  const [activeOverlay, setActiveOverlay] = useState<ActiveOverlay>(null);
  const [activeDialogue, setActiveDialogue] = useState<ActiveDialogueState | null>(null);
  const [activePrompt, setActivePrompt] = useState<InteractablePrompt | null>(null);
  const [battleContext, setBattleContext] = useState<BattleContextData | null>(() =>
    autostartMode === 'battle'
      ? {
          enemyIds: ['boss_diabolos'],
          isBoss: true,
          allowGears: true,
          arenaTheme: 'zeboim_ruins',
          returnMapId: 'dungeon_zeboim_ruins',
          returnX: 12,
          returnZ: 22,
          returnFacing: 'N',
          victoryFlag: 'zeboim_boss_defeated',
        }
      : null
  );
  const [screenFade, setScreenFade] = useState(0);
  const [screenFlash, setScreenFlash] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const toastTimerRef = useRef<number | null>(null);
  const directorRef = useRef<EventDirector | null>(null);
  const gameStateRef = useRef(gameState);
  gameStateRef.current = gameState;
  const activeOverlayRef = useRef(activeOverlay);
  activeOverlayRef.current = activeOverlay;
  const playerPosRef = useRef(playerPos);
  playerPosRef.current = playerPos;
  const mapIdRef = useRef(mapId);
  mapIdRef.current = mapId;

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimerRef.current !== null) window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  }, []);

  // Init asset manifests (zero 404s) and AudioManager config on boot
  useEffect(() => {
    AudioManager.setConfig(config.audio);
    void AudioManager.initManifest();
    void SpriteSheetRegistry.initManifest();
    void PixelTextureFactory.initManifest();
  }, []);

  // Mirror state machine to document.body.dataset.state for testability & shell hygiene
  useEffect(() => {
    let bodyState = 'playing';
    if (gameState === 'BOOT_LOGO' || gameState === 'PROLOGUE_INTRO' || gameState === 'TITLE_SCREEN') {
      bodyState = 'title';
    } else if (gameState === 'GAME_OVER') {
      bodyState = 'gameover';
    } else if (activeOverlay === 'main_menu' || activeOverlay === 'config_modal') {
      bodyState = 'paused';
    } else if (gameState === 'BATTLE') {
      bodyState = 'battle';
    }
    document.body.dataset.state = bodyState;
    document.body.dataset.map = mapId;
    document.body.dataset.jrpgState = gameState;
  }, [gameState, activeOverlay, mapId]);

  // Sync OST Track automatically on GameState / MapId changes
  useEffect(() => {
    if (gameState === 'TITLE_SCREEN' || gameState === 'BOOT_LOGO') {
      void AudioManager.playTrack('title');
    } else if (gameState === 'PROLOGUE_INTRO' || gameState === 'CUTSCENE') {
      void AudioManager.playTrack('cutscene_tragic');
    } else if (gameState === 'BATTLE') {
      void AudioManager.playTrack(battleContext?.isBoss ? 'battle_boss' : 'battle_normal');
    } else if (
      gameState === 'PLAYING_WORLDMAP' ||
      gameState === 'PLAYING_TOWN' ||
      gameState === 'PLAYING_INTERIOR' ||
      gameState === 'PLAYING_DUNGEON'
    ) {
      const m = getMapById(mapId);
      void AudioManager.playTrack(m.ostTrack);
    }
  }, [gameState, mapId, battleContext]);

  // Playtime clock ticks during active play
  useEffect(() => {
    const isPlaying =
      gameState === 'PLAYING_WORLDMAP' ||
      gameState === 'PLAYING_TOWN' ||
      gameState === 'PLAYING_INTERIOR' ||
      gameState === 'PLAYING_DUNGEON' ||
      gameState === 'BATTLE' ||
      gameState === 'CUTSCENE';
    if (!isPlaying) return;
    const id = window.setInterval(() => {
      if (document.visibilityState === 'visible') {
        setPlaytimeSeconds((s) => s + 1);
      }
    }, 1000);
    return () => window.clearInterval(id);
  }, [gameState]);

  // Android Capacitor hardware Back button & Escape interception
  useEffect(() => {
    const handleBack = () => {
      const gs = gameStateRef.current;
      const ov = activeOverlayRef.current;
      if (ov) {
        AudioManager.playSfx('cancel');
        setActiveOverlay(null);
        return;
      }
      if (
        gs === 'PLAYING_WORLDMAP' ||
        gs === 'PLAYING_TOWN' ||
        gs === 'PLAYING_INTERIOR' ||
        gs === 'PLAYING_DUNGEON'
      ) {
        AudioManager.playSfx('confirm');
        setActiveOverlay('main_menu');
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (activeDialogue) return;
        if (gameStateRef.current === 'TITLE_SCREEN' && activeOverlayRef.current) {
          AudioManager.playSfx('cancel');
          setActiveOverlay(null);
          return;
        }
        handleBack();
      }
    };

    const onHardwareBack = (e: Event) => {
      e.preventDefault();
      handleBack();
    };

    window.addEventListener('keydown', onKeyDown);
    document.addEventListener('backbutton', onHardwareBack);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('backbutton', onHardwareBack);
    };
  }, [activeDialogue]);

  const setGameState = useCallback((s: GameState) => {
    setGameStateRaw(s);
  }, []);

  const updatePlayerPos = useCallback((x: number, z: number, facing: Direction) => {
    setPlayerPos({ x, z, facing });
  }, []);

  const warpToMap = useCallback(
    (
      targetMap: MapId,
      x: number,
      z: number,
      facing: Direction,
      playDoorSfx = true
    ) => {
      if (playDoorSfx) AudioManager.playSfx('door');
      setScreenFade(1);
      window.setTimeout(() => {
        const nextMapDef = getMapById(targetMap);
        setMapId(targetMap);
        setPlayerPos({ x, z, facing });
        setActivePrompt(null);
        setGameStateRaw(nextMapDef.gameState);
        setVisitedMaps((prev) => (prev.includes(targetMap) ? prev : [...prev, targetMap]));
        window.setTimeout(() => setScreenFade(0), 140);
      }, 240);
    },
    []
  );

  const startBattle = useCallback(
    (
      enemyIds: string[],
      opts?: {
        isBoss?: boolean;
        allowGears?: boolean;
        arenaTheme?: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps';
        victoryFlag?: string;
      }
    ) => {
      const curMap = getMapById(mapIdRef.current);
      const pos = playerPosRef.current;
      AudioManager.playSfx('break');
      setActiveOverlay(null);
      setActiveDialogue(null);
      setScreenFlash('#ffffff');
      window.setTimeout(() => {
        setScreenFlash(null);
        setBattleContext({
          enemyIds,
          isBoss: Boolean(opts?.isBoss),
          allowGears: opts?.allowGears ?? (Boolean(opts?.isBoss) || curMap.id === 'worldmap_ignas'),
          arenaTheme: opts?.arenaTheme ?? curMap.arenaTheme,
          returnMapId: curMap.id,
          returnX: pos.x,
          returnZ: pos.z,
          returnFacing: pos.facing,
          victoryFlag: opts?.victoryFlag,
        });
        setGameStateRaw('BATTLE');
      }, 260);
    },
    []
  );

  const playCutscene = useCallback(
    (scriptId: string) => {
      const script = CUTSCENE_SCRIPTS[scriptId];
      if (!script) return;
      directorRef.current?.cancel();
      const dir = new EventDirector();
      directorRef.current = dir;
      setGameStateRaw('CUTSCENE');

      void dir.runScript(script, {
        onShowDialogue: (lines, onDone) => {
          setActiveDialogue({ lines, index: 0, onComplete: onDone });
        },
        onEmote: () => {
          AudioManager.playSfx('cursor', 1.2);
        },
        onFaceActor: () => {},
        onMoveActor: async () => {},
        onCameraPan: async (_dx, _dz, durationMs) => {
          await new Promise((r) => window.setTimeout(r, durationMs));
        },
        onFade: async (direction, durationMs) => {
          setScreenFade(direction === 'out' ? 1 : 0);
          await new Promise((r) => window.setTimeout(r, durationMs));
        },
        onFlash: async (color, durationMs) => {
          setScreenFlash(color);
          await new Promise((r) => window.setTimeout(r, durationMs));
          setScreenFlash(null);
        },
        onSetFlag: (flag, value) => {
          setQuestFlags((prev) => ({ ...prev, [flag]: value }));
        },
        onJoinParty: (memberId) => {
          setParty((prev) =>
            prev.map((m) => (m.id === memberId ? { ...m, joined: true } : m))
          );
        },
        onStartBattle: (step) => {
          startBattle(step.enemyIds, {
            isBoss: step.isBoss,
            allowGears: step.allowGears,
            arenaTheme: step.arenaTheme,
            victoryFlag: step.victoryFlag,
          });
        },
        onWarp: (tMap, tx, tz, tf) => {
          warpToMap(tMap, tx, tz, tf, false);
        },
        onComplete: () => {
          const curMap = getMapById(mapIdRef.current);
          setGameStateRaw(curMap.gameState);
        },
      });
    },
    [startBattle, warpToMap]
  );

  const startNewGame = useCallback(
    (skipAtelierIntro = false) => {
      AudioManager.playSfx('confirm');
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      setActiveOverlay(null);
      setActiveDialogue(null);
      setParty(createInitialParty());
      setInventory(createInitialInventory());
      setGil(650);
      setPlaytimeSeconds(0);
      setOpenedChests([]);
      setQuestFlags({});
      setVisitedMaps(['town_nisan', 'interior_atelier']);

      if (skipAtelierIntro) {
        setMapId('town_nisan');
        setPlayerPos({ x: 15, z: 17, facing: 'N' });
        setGameStateRaw('PLAYING_TOWN');
      } else {
        // Start in Town of Nisan facing the Cathedral steps (open landmark vista!)
        setMapId('town_nisan');
        setPlayerPos({ x: 15, z: 17, facing: 'N' });
        setGameStateRaw('PLAYING_TOWN');
        showToast('Chapter 1: Shadows Over Nisan — Enter the Cathedral north of the plaza.');
      }
    },
    [showToast]
  );

  const continueFromSlot = useCallback(
    (slotId: 1 | 2 | 3): boolean => {
      const slot = saveSlots[slotId - 1];
      if (!slot) return false;
      AudioManager.playSfx('confirm');
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      setActiveOverlay(null);
      setActiveDialogue(null);
      const targetMap = MAP_REGISTRY[slot.mapId] ? slot.mapId : 'town_nisan';
      setMapId(targetMap);
      setPlayerPos({ x: slot.playerX, z: slot.playerZ, facing: slot.facing });
      setPlaytimeSeconds(slot.playtimeSeconds);
      setGil(slot.gil);
      setParty(slot.party);
      setInventory(slot.inventory);
      setOpenedChests(slot.openedChests);
      setQuestFlags(slot.questFlags);
      setVisitedMaps(slot.visitedMaps?.length ? slot.visitedMaps : [targetMap]);
      setGameStateRaw(getMapById(targetMap).gameState);
      showToast(`Loaded Slot ${slotId} — ${getMapById(targetMap).name}`);
      return true;
    },
    [saveSlots, showToast]
  );

  const saveToSlot = useCallback(
    (slotId: 1 | 2 | 3): SaveSlotData => {
      const curMap = getMapById(mapIdRef.current);
      const pos = playerPosRef.current;
      const saved = saveSlot(slotId, {
        mapId: curMap.id,
        locationName: curMap.name,
        playerX: Number(pos.x.toFixed(2)),
        playerZ: Number(pos.z.toFixed(2)),
        facing: pos.facing,
        playtimeSeconds,
        gil,
        party,
        inventory,
        openedChests,
        questFlags,
        visitedMaps,
      });
      setSaveSlots(loadAllSlots());
      AudioManager.playSfx('save');
      showToast(`Journey recorded to Save Slot ${slotId}.`);
      return saved;
    },
    [playtimeSeconds, gil, party, inventory, openedChests, questFlags, visitedMaps, showToast]
  );

  const deleteSaveSlot = useCallback((slotId: 1 | 2 | 3) => {
    deleteSlot(slotId);
    setSaveSlots(loadAllSlots());
    AudioManager.playSfx('cancel');
  }, []);

  const exportSlotJson = useCallback(
    (slotId: 1 | 2 | 3): string | null => {
      const s = saveSlots[slotId - 1];
      if (!s) return null;
      return exportSaveToJson(s);
    },
    [saveSlots]
  );

  const importSlotJson = useCallback(
    (slotId: 1 | 2 | 3, json: string): { ok: boolean; error?: string } => {
      const res = importSaveFromJson(json, slotId);
      if (res.ok) {
        setSaveSlots(loadAllSlots());
        AudioManager.playSfx('save');
        showToast(`Imported save data into Slot ${slotId}.`);
        return { ok: true };
      }
      return { ok: false, error: res.error };
    },
    [showToast]
  );

  const updateAudioConfig = useCallback((patch: Partial<AppConfig['audio']>) => {
    setConfig((prev) => {
      const next: AppConfig = {
        ...prev,
        audio: { ...prev.audio, ...patch },
      };
      AudioManager.setConfig(next.audio);
      saveAppConfig(next);
      return next;
    });
  }, []);

  const setGraphicsQuality = useCallback((q: GraphicsQuality) => {
    setConfig((prev) => {
      const next: AppConfig = { ...prev, graphicsQuality: q };
      saveAppConfig(next);
      return next;
    });
  }, []);

  const setShowTouchControls = useCallback((show: boolean) => {
    setConfig((prev) => {
      const next: AppConfig = { ...prev, showTouchControls: show };
      saveAppConfig(next);
      return next;
    });
  }, []);

  const advanceDialogue = useCallback(() => {
    setActiveDialogue((prev) => {
      if (!prev) return null;
      AudioManager.playSfx('confirm');
      if (prev.index + 1 < prev.lines.length) {
        return { ...prev, index: prev.index + 1 };
      }
      const cb = prev.onComplete;
      window.setTimeout(() => cb?.(), 0);
      return null;
    });
  }, []);

  const triggerInteract = useCallback(
    (onFaceNpc?: (npcId: string) => void) => {
      if (activeDialogue) {
        advanceDialogue();
        return;
      }
      if (!activePrompt) return;
      const map = getMapById(mapIdRef.current);

      if (activePrompt.type === 'chest') {
        const chest = map.chests.find((c) => c.id === activePrompt.id);
        if (!chest || openedChests.includes(chest.id)) return;
        AudioManager.playSfx('chest');
        setOpenedChests((prev) => [...prev, chest.id]);
        let rewardText = '';
        if (chest.rewardGil) {
          setGil((g) => g + chest.rewardGil!);
          rewardText = `${chest.rewardGil} G`;
        }
        if (chest.rewardItemId) {
          const qty = chest.rewardQty ?? 1;
          const def = ITEMS[chest.rewardItemId];
          setInventory((prev) => {
            const idx = prev.findIndex((i) => i.itemId === chest.rewardItemId);
            if (idx >= 0) {
              const copy = [...prev];
              copy[idx] = { ...copy[idx], quantity: copy[idx].quantity + qty };
              return copy;
            }
            return [...prev, { itemId: chest.rewardItemId!, quantity: qty }];
          });
          rewardText = `${def?.name ?? chest.rewardItemId} x${qty}`;
        }
        setActiveDialogue({
          lines: [
            {
              speaker: chest.label,
              accentColor: '#e5c16a',
              text: `Opened the treasure chest and obtained ${rewardText}!`,
            },
          ],
          index: 0,
        });
        return;
      }

      if (activePrompt.type === 'save') {
        AudioManager.playSfx('save');
        setParty((prev) =>
          prev.map((m) => ({
            ...m,
            hp: getMemberStats(m).maxHp,
            ep: m.maxEp,
            gear: m.gear
              ? { ...m.gear, frameHp: getMemberStats(m).gearMaxHp, fuel: getMemberStats(m).gearMaxFuel }
              : null,
          }))
        );
        setActiveOverlay('save_menu');
        showToast('Memory Cube resonance restored party vitality.');
        return;
      }

      if (activePrompt.type === 'switch') {
        const sw = map.switches?.find((s) => s.id === activePrompt.id);
        if (!sw) return;
        AudioManager.playSfx('switch');
        setQuestFlags((prev) => ({ ...prev, [sw.flagId]: true }));
        setScreenFlash('#66d9ff');
        window.setTimeout(() => setScreenFlash(null), 260);
        setActiveDialogue({
          lines: [
            {
              speaker: 'Zeboim Mechanism',
              accentColor: '#66d9ff',
              text: 'The Resonance Floor Switch locks into place! A heavy ancient bulkhead unseals to the north, revealing the Boss Sanctum.',
            },
          ],
          index: 0,
        });
        return;
      }

      if (activePrompt.type === 'npc') {
        const npc = map.npcs.find((n) => n.id === activePrompt.id);
        if (!npc) return;
        onFaceNpc?.(npc.id);
        AudioManager.playSfx('confirm');

        if (npc.shopType === 'inn') {
          setActiveOverlay('inn_modal');
          return;
        }
        if (npc.shopType === 'armory') {
          setActiveOverlay('armory_shop');
          return;
        }
        if (npc.shopType === 'items') {
          setActiveOverlay('item_shop');
          return;
        }

        // Story cutscene triggers
        if (npc.dialogueId === 'cathedral_sophia_story') {
          if (!questFlags.cathedral_summit_done) {
            playCutscene('scene2_cathedral_summit');
          } else {
            setActiveDialogue({
              lines: [
                {
                  speaker: 'Sophia',
                  spriteId: 'sophia',
                  accentColor: '#d87070',
                  text: 'Please be careful inside the Zeboim ruins, Lacan. The portrait can wait until Nisan is safe.',
                  voicePitch: 1.24,
                },
              ],
              index: 0,
            });
          }
          return;
        }

        if (npc.dialogueId === 'zeboim_hologram_story') {
          playCutscene('scene3_zeboim_hologram');
          return;
        }

        if (npc.dialogueId === 'zeboim_boss_encounter') {
          playCutscene('scene4_zeboim_boss');
          return;
        }

        const lines = npc.dialogueId ? NPC_DIALOGUES[npc.dialogueId] : null;
        if (lines) {
          setActiveDialogue({ lines, index: 0 });
        }
      }
    },
    [activeDialogue, activePrompt, advanceDialogue, openedChests, playCutscene, questFlags, showToast]
  );

  const completeBattleVictory = useCallback(
    (
      updatedParty: PartyMember[],
      gilGain: number,
      droppedItems: string[],
      victoryFlag?: string
    ) => {
      setParty(updatedParty);
      setGil((g) => g + gilGain);
      if (droppedItems.length > 0) {
        setInventory((prev) => {
          const copy = [...prev];
          for (const itemId of droppedItems) {
            const idx = copy.findIndex((i) => i.itemId === itemId);
            if (idx >= 0) copy[idx] = { ...copy[idx], quantity: copy[idx].quantity + 1 };
            else copy.push({ itemId, quantity: 1 });
          }
          return copy;
        });
      }
      if (victoryFlag) {
        setQuestFlags((prev) => ({ ...prev, [victoryFlag]: true }));
      }
      const ret = battleContext;
      setBattleContext(null);
      if (ret) {
        const retMap = getMapById(ret.returnMapId);
        setMapId(ret.returnMapId);
        setPlayerPos({ x: ret.returnX, z: ret.returnZ, facing: ret.returnFacing });
        setGameStateRaw(retMap.gameState);
        if (victoryFlag === 'zeboim_boss_defeated') {
          showToast('Prototype Diabolos defeated! Chapter 1 Complete!');
        }
      } else {
        setGameStateRaw('PLAYING_TOWN');
      }
    },
    [battleContext, showToast]
  );

  const completeBattleFlee = useCallback(
    (updatedParty: PartyMember[]) => {
      setParty(updatedParty);
      const ret = battleContext;
      setBattleContext(null);
      if (ret) {
        setGameStateRaw(getMapById(ret.returnMapId).gameState);
      } else {
        setGameStateRaw('PLAYING_TOWN');
      }
    },
    [battleContext]
  );

  const triggerGameOver = useCallback(() => {
    setBattleContext(null);
    setActiveOverlay(null);
    setGameStateRaw('GAME_OVER');
  }, []);

  const returnToTitle = useCallback(() => {
    AudioManager.playSfx('cancel');
    setBattleContext(null);
    setActiveOverlay(null);
    setActiveDialogue(null);
    setMapId('town_nisan');
    setGameStateRaw('TITLE_SCREEN');
  }, []);

  const restAtInn = useCallback(
    (cost: number): boolean => {
      if (gil < cost) {
        AudioManager.playSfx('cancel');
        showToast('Not enough Gil to stay at the Inn.');
        return false;
      }
      AudioManager.playSfx('rest');
      setGil((g) => g - cost);
      setScreenFade(1);
      window.setTimeout(() => {
        setParty((prev) =>
          prev.map((m) => {
            const st = getMemberStats(m);
            return {
              ...m,
              hp: st.maxHp,
              ep: m.maxEp,
              gear: m.gear
                ? { ...m.gear, frameHp: st.gearMaxHp, fuel: st.gearMaxFuel }
                : null,
            };
          })
        );
        setActiveOverlay(null);
        window.setTimeout(() => {
          setScreenFade(0);
          showToast('Rested soundly! Party HP, EP, and Gear Fuel fully restored.');
        }, 380);
      }, 320);
      return true;
    },
    [gil, showToast]
  );

  const buyItem = useCallback(
    (itemId: string): boolean => {
      const def = ITEMS[itemId];
      if (!def || gil < def.price) {
        AudioManager.playSfx('cancel');
        return false;
      }
      AudioManager.playSfx('confirm');
      setGil((g) => g - def.price);
      setInventory((prev) => {
        const idx = prev.findIndex((e) => e.itemId === itemId);
        if (idx >= 0) {
          const copy = [...prev];
          copy[idx] = { ...copy[idx], quantity: copy[idx].quantity + 1 };
          return copy;
        }
        return [...prev, { itemId, quantity: 1 }];
      });
      showToast(`Purchased ${def.name}.`);
      return true;
    },
    [gil, showToast]
  );

  const sellItem = useCallback(
    (itemId: string): boolean => {
      const def = ITEMS[itemId];
      const entry = inventory.find((e) => e.itemId === itemId);
      if (!def || !entry || entry.quantity <= 0) return false;
      AudioManager.playSfx('confirm');
      setGil((g) => g + def.sellPrice);
      setInventory((prev) =>
        prev
          .map((e) => (e.itemId === itemId ? { ...e, quantity: e.quantity - 1 } : e))
          .filter((e) => e.quantity > 0)
      );
      showToast(`Sold ${def.name} for ${def.sellPrice} G.`);
      return true;
    },
    [inventory, showToast]
  );

  const consumeBattleItem = useCallback((itemId: string) => {
    setInventory((prev) =>
      prev
        .map((e) => (e.itemId === itemId ? { ...e, quantity: e.quantity - 1 } : e))
        .filter((e) => e.quantity > 0)
    );
  }, []);

  const useConsumableItem = useCallback(
    (itemId: string, memberId: PartyMember['id']): boolean => {
      const def = ITEMS[itemId];
      const entry = inventory.find((e) => e.itemId === itemId);
      if (!def || !def.effect || !entry || entry.quantity <= 0) return false;

      AudioManager.playSfx('ether');
      consumeBattleItem(itemId);
      setParty((prev) =>
        prev.map((m) => {
          if (!def.effect!.allParty && m.id !== memberId) return m;
          const st = getMemberStats(m);
          let hp = m.hp;
          let ep = m.ep;
          let gear = m.gear;
          if (def.effect!.revive && hp <= 0) {
            hp = Math.min(st.maxHp, def.effect!.healHp ?? Math.round(st.maxHp * 0.5));
          } else if (def.effect!.healHp && hp > 0) {
            hp = Math.min(st.maxHp, hp + def.effect!.healHp);
          }
          if (def.effect!.healEp) {
            ep = Math.min(m.maxEp, ep + def.effect!.healEp);
          }
          if (def.effect!.healFuel && gear) {
            gear = {
              ...gear,
              fuel: Math.min(st.gearMaxFuel, gear.fuel + def.effect!.healFuel),
            };
          }
          return { ...m, hp, ep, gear };
        })
      );
      showToast(`Used ${def.name}.`);
      return true;
    },
    [consumeBattleItem, inventory, showToast]
  );

  const equipItem = useCallback(
    (memberId: PartyMember['id'], itemId: string): boolean => {
      const def = ITEMS[itemId];
      const entry = inventory.find((e) => e.itemId === itemId);
      if (!def || !entry || entry.quantity <= 0) return false;
      if (def.category === 'consumable') return false;

      let prevEquippedId: string | null = null;
      setParty((prev) =>
        prev.map((m) => {
          if (m.id !== memberId) return m;
          if (def.category === 'weapon') {
            prevEquippedId = m.weaponId;
            return { ...m, weaponId: itemId };
          }
          if (def.category === 'armor') {
            prevEquippedId = m.armorId;
            return { ...m, armorId: itemId };
          }
          if (def.category === 'accessory') {
            prevEquippedId = m.accessoryId;
            return { ...m, accessoryId: itemId };
          }
          if (def.category === 'gear_part' && m.gear) {
            prevEquippedId = m.gear.equippedPartId;
            return { ...m, gear: { ...m.gear, equippedPartId: itemId } };
          }
          return m;
        })
      );

      setInventory((prev) => {
        let next = prev
          .map((e) => (e.itemId === itemId ? { ...e, quantity: e.quantity - 1 } : e))
          .filter((e) => e.quantity > 0);
        if (prevEquippedId) {
          const idx = next.findIndex((e) => e.itemId === prevEquippedId);
          if (idx >= 0) {
            next = [...next];
            next[idx] = { ...next[idx], quantity: next[idx].quantity + 1 };
          } else {
            next = [...next, { itemId: prevEquippedId, quantity: 1 }];
          }
        }
        return next;
      });
      AudioManager.playSfx('confirm');
      showToast(`Equipped ${def.name}.`);
      return true;
    },
    [inventory, showToast]
  );

  const swapPartyFormation = useCallback((idxA: number, idxB: number) => {
    setParty((prev) => {
      if (idxA < 0 || idxB < 0 || idxA >= prev.length || idxB >= prev.length) return prev;
      const copy = [...prev];
      const tmp = copy[idxA];
      copy[idxA] = copy[idxB];
      copy[idxB] = tmp;
      return copy;
    });
    AudioManager.playSfx('cursor');
  }, []);

  const value: GameStateContextValue = {
    gameState,
    setGameState,
    mapId,
    playerPos,
    updatePlayerPos,
    playtimeSeconds,
    gil,
    party,
    inventory,
    openedChests,
    questFlags,
    visitedMaps,
    config,
    saveSlots,
    activeOverlay,
    setActiveOverlay,
    activeDialogue,
    activePrompt,
    setActivePrompt,
    battleContext,
    screenFade,
    screenFlash,
    toastMessage,
    showToast,
    startNewGame,
    continueFromSlot,
    saveToSlot,
    deleteSaveSlot,
    exportSlotJson,
    importSlotJson,
    updateAudioConfig,
    setGraphicsQuality,
    setShowTouchControls,
    warpToMap,
    triggerInteract,
    advanceDialogue,
    playCutscene,
    startBattle,
    completeBattleVictory,
    completeBattleFlee,
    triggerGameOver,
    returnToTitle,
    restAtInn,
    buyItem,
    sellItem,
    useConsumableItem,
    equipItem,
    swapPartyFormation,
    consumeBattleItem,
  };

  return <GameStateContext.Provider value={value}>{children}</GameStateContext.Provider>;
};

export function useGameState(): GameStateContextValue {
  const ctx = useContext(GameStateContext);
  if (!ctx) throw new Error('useGameState must be used inside GameStateProvider');
  return ctx;
}
