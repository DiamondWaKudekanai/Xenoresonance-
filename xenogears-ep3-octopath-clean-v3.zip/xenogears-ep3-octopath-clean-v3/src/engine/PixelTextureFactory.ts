import * as THREE from 'three';

export type PixelTileKey =
  | 'grass'
  | 'cobble'
  | 'stone_plaza'
  | 'water'
  | 'sand'
  | 'forest'
  | 'mountain'
  | 'wood_floor'
  | 'marble_checker'
  | 'rug_red'
  | 'zeboim_floor'
  | 'bridge'
  | 'wall_stone'
  | 'wall_stucco'
  | 'wall_cathedral'
  | 'wall_wood'
  | 'wall_zeboim'
  | 'roof_clay'
  | 'roof_slate'
  | 'stained_glass'
  | 'sophia_portrait';

function makeCanvas(size: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  return [c, ctx];
}

function seededNoise(x: number, y: number, seed: number): number {
  const n = Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453;
  return n - Math.floor(n);
}

const BUNDLED_TILE_FILES = [
  'bridge.png',
  'cobble.png',
  'forest.png',
  'grass.png',
  'marble_checker.png',
  'mountain.png',
  'roof_clay.png',
  'roof_slate.png',
  'rug_red.png',
  'sand.png',
  'sophia_portrait.png',
  'stained_glass.png',
  'stone_plaza.png',
  'wall_cathedral.png',
  'wall_stone.png',
  'wall_stucco.png',
  'wall_wood.png',
  'wall_zeboim.png',
  'water.png',
  'wood_floor.png',
  'zeboim_floor.png',
];

class PixelTextureFactoryImpl {
  private cache = new Map<PixelTileKey, THREE.Texture>();
  private clonesByKey = new Map<PixelTileKey, Set<THREE.Texture>>();
  private propCache = new Map<string, THREE.Texture>();
  private bumpCache = new Map<PixelTileKey, THREE.Texture>();
  private availableOverrides = new Set<string>(BUNDLED_TILE_FILES);
  private customTileUrls = new Map<string, string>();
  private manifestLoaded = false;

  public async initManifest(): Promise<void> {
    if (this.manifestLoaded || typeof fetch === 'undefined') return;
    this.manifestLoaded = true;
    try {
      const res = await fetch('/assets/tiles/manifest.json', { cache: 'no-store' });
      if (res.ok) {
        const data = (await res.json()) as { available?: string[] };
        if (Array.isArray(data.available)) {
          data.available.forEach((f) => this.availableOverrides.add(f.toLowerCase()));
        }
      }
    } catch {
      // Fail silently
    }
  }

  public getAvailableOverrides(): string[] {
    return [...Array.from(this.availableOverrides), ...Array.from(this.customTileUrls.keys())];
  }

  public registerCustomTile(tileFile: string, file: File): void {
    const key = tileFile.toLowerCase();
    const prev = this.customTileUrls.get(key);
    if (prev) URL.revokeObjectURL(prev);
    const url = URL.createObjectURL(file);
    this.customTileUrls.set(key, url);
    const base = key.replace(/\.(png|jpg|jpeg|webp)$/i, '') as PixelTileKey;
    const existing = this.cache.get(base);
    if (existing) {
      this.applyExternalTileImage(base, existing, url);
    }
  }

  private applyExternalTileImage(key: PixelTileKey, base: THREE.Texture, url: string) {
    if (typeof Image === 'undefined') return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const SourceCtor =
        (THREE as unknown as { TextureSource?: typeof THREE.Source }).TextureSource ?? THREE.Source;
      const newSource = new SourceCtor(img);
      base.dispose();
      base.source = newSource;
      base.needsUpdate = true;
      const clones = this.clonesByKey.get(key);
      if (clones) {
        clones.forEach((c) => {
          c.dispose();
          c.source = newSource;
          c.needsUpdate = true;
        });
      }
    };
    img.src = url;
  }

  public getPropTexture(filename: string): THREE.Texture {
    const existing = this.propCache.get(filename);
    if (existing) return existing;
    const [canvas] = makeCanvas(2);
    const tex: THREE.Texture = new THREE.CanvasTexture(canvas);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    tex.colorSpace = THREE.SRGBColorSpace;
    if (typeof Image !== 'undefined') {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const SourceCtor =
          (THREE as unknown as { TextureSource?: typeof THREE.Source }).TextureSource ?? THREE.Source;
        const newSource = new SourceCtor(img);
        tex.dispose();
        tex.source = newSource;
        tex.needsUpdate = true;
      };
      img.src = `/assets/props/${filename}`;
    }
    this.propCache.set(filename, tex);
    return tex;
  }

  public getTexture(key: PixelTileKey, repeatX = 1, repeatY = 1): THREE.Texture {
    let base = this.cache.get(key);
    if (!base) {
      base = this.createProceduralTexture(key);
      const overrideFile = `${key}.png`;
      const customUrl = this.customTileUrls.get(overrideFile);
      const url = customUrl || (this.availableOverrides.has(overrideFile) ? `/assets/tiles/${overrideFile}` : null);
      if (url) {
        this.applyExternalTileImage(key, base, url);
      }
      this.cache.set(key, base);
    }

    if (repeatX === 1 && repeatY === 1) return base;
    const cloned = base.clone();
    cloned.needsUpdate = true;
    cloned.repeat.set(repeatX, repeatY);
    cloned.wrapS = THREE.RepeatWrapping;
    cloned.wrapT = THREE.RepeatWrapping;
    cloned.magFilter = THREE.NearestFilter;
    cloned.minFilter = THREE.NearestFilter;
    cloned.generateMipmaps = false;
    cloned.colorSpace = THREE.SRGBColorSpace;
    let set = this.clonesByKey.get(key);
    if (!set) {
      set = new Set();
      this.clonesByKey.set(key, set);
    }
    set.add(cloned);
    return cloned;
  }

  public releaseClone(tex: THREE.Texture | null | undefined): void {
    if (!tex) return;
    for (const set of this.clonesByKey.values()) {
      if (set.delete(tex)) {
        tex.dispose();
        return;
      }
    }
  }

  public getBumpMap(key: PixelTileKey): THREE.Texture {
    const existing = this.bumpCache.get(key);
    if (existing) return existing;
    const [c, ctx] = makeCanvas(16);
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        let v = Math.floor(110 + seededNoise(x, y, key.length * 13) * 55);
        if (key === 'cobble' || key === 'stone_plaza' || key === 'wall_stone') {
          if (y % 8 === 0 || (x + (Math.floor(y / 8) % 2) * 4) % 8 === 0) v = 40;
        } else if (key === 'wood_floor' || key === 'bridge') {
          if (y % 4 === 0) v = 45;
        }
        ctx.fillStyle = `rgb(${v},${v},${v})`;
        ctx.fillRect(x, y, 1, 1);
      }
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    this.bumpCache.set(key, tex);
    return tex;
  }

  private createProceduralTexture(key: PixelTileKey): THREE.Texture {
    const size = key === 'stained_glass' || key === 'sophia_portrait' ? 32 : 16;
    const [canvas, ctx] = makeCanvas(size);

    switch (key) {
      case 'grass': {
        const pal = ['#4d7548', '#56804f', '#446840', '#638e59'];
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            const n = seededNoise(x, y, 1);
            ctx.fillStyle = pal[Math.floor(n * pal.length)];
            ctx.fillRect(x, y, 1, 1);
          }
        }
        ctx.fillStyle = '#79a868';
        ctx.fillRect(3, 4, 1, 2);
        ctx.fillRect(11, 10, 1, 2);
        ctx.fillRect(7, 13, 1, 1);
        break;
      }

      case 'forest': {
        const pal = ['#345436', '#3d613f', '#2b472d', '#476e45'];
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            ctx.fillStyle = pal[Math.floor(seededNoise(x, y, 2) * pal.length)];
            ctx.fillRect(x, y, 1, 1);
          }
        }
        break;
      }

      case 'sand': {
        const pal = ['#cfb27a', '#c6a76e', '#dabf88', '#b89861'];
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            const wave = Math.sin((x + y * 0.6) * 0.6) > 0.4 ? 2 : 0;
            const idx = (Math.floor(seededNoise(x, y, 3) * 2) + wave) % pal.length;
            ctx.fillStyle = pal[idx];
            ctx.fillRect(x, y, 1, 1);
          }
        }
        break;
      }

      case 'water': {
        ctx.fillStyle = '#2d638a';
        ctx.fillRect(0, 0, 16, 16);
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            const n = seededNoise(x, y, 4);
            if (n > 0.72) {
              ctx.fillStyle = '#3b7ba6';
              ctx.fillRect(x, y, 2, 1);
            }
          }
        }
        ctx.fillStyle = '#7ec2e6';
        ctx.fillRect(2, 4, 4, 1);
        ctx.fillRect(9, 11, 4, 1);
        ctx.fillRect(5, 14, 3, 1);
        break;
      }

      case 'mountain': {
        const pal = ['#6e655c', '#5e564e', '#7e746a', '#4f4842'];
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            ctx.fillStyle = pal[Math.floor(seededNoise(x, y, 5) * pal.length)];
            ctx.fillRect(x, y, 1, 1);
          }
        }
        break;
      }

      case 'cobble': {
        ctx.fillStyle = '#534d47';
        ctx.fillRect(0, 0, 16, 16);
        const stones = [
          [1, 1, 6, 6, '#8c8378'],
          [8, 1, 7, 6, '#7f776c'],
          [0, 8, 4, 7, '#7d7469'],
          [5, 8, 6, 7, '#93897c'],
          [12, 8, 4, 7, '#857c70'],
        ] as const;
        for (const [sx, sy, sw, sh, col] of stones) {
          ctx.fillStyle = col;
          ctx.fillRect(sx, sy, sw, sh);
          ctx.fillStyle = '#a59b8d';
          ctx.fillRect(sx, sy, sw, 1);
          ctx.fillStyle = '#6a6258';
          ctx.fillRect(sx, sy + sh - 1, sw, 1);
        }
        break;
      }

      case 'stone_plaza': {
        ctx.fillStyle = '#716960';
        ctx.fillRect(0, 0, 16, 16);
        ctx.fillStyle = '#a59b8c';
        ctx.fillRect(1, 1, 14, 14);
        ctx.fillStyle = '#b9afa0';
        ctx.fillRect(1, 1, 14, 2);
        ctx.fillRect(1, 1, 2, 14);
        ctx.fillStyle = '#8b8173';
        ctx.fillRect(2, 13, 13, 2);
        ctx.fillRect(13, 2, 2, 13);
        ctx.fillStyle = '#978d7f';
        ctx.fillRect(7, 7, 2, 2);
        break;
      }

      case 'wood_floor':
      case 'bridge': {
        ctx.fillStyle = key === 'bridge' ? '#6a4b32' : '#7b5638';
        ctx.fillRect(0, 0, 16, 16);
        for (let y = 0; y < 16; y += 4) {
          ctx.fillStyle = '#47301d';
          ctx.fillRect(0, y, 16, 1);
          ctx.fillStyle = key === 'bridge' ? '#7f5b3d' : '#8f6744';
          ctx.fillRect(0, y + 1, 16, 1);
          ctx.fillStyle = '#5c3f27';
          ctx.fillRect((y * 3) % 14, y + 1, 1, 3);
        }
        break;
      }

      case 'marble_checker': {
        ctx.fillStyle = '#d9d2c5';
        ctx.fillRect(0, 0, 8, 8);
        ctx.fillRect(8, 8, 8, 8);
        ctx.fillStyle = '#505b70';
        ctx.fillRect(8, 0, 8, 8);
        ctx.fillRect(0, 8, 8, 8);
        ctx.fillStyle = '#c5bca9';
        ctx.fillRect(1, 1, 6, 1);
        ctx.fillRect(9, 9, 6, 1);
        ctx.fillStyle = '#63718a';
        ctx.fillRect(9, 1, 6, 1);
        ctx.fillRect(1, 9, 6, 1);
        break;
      }

      case 'rug_red': {
        ctx.fillStyle = '#7e262b';
        ctx.fillRect(0, 0, 16, 16);
        ctx.fillStyle = '#c8a258';
        ctx.fillRect(1, 0, 1, 16);
        ctx.fillRect(14, 0, 1, 16);
        ctx.fillStyle = '#9c3237';
        ctx.fillRect(3, 2, 10, 12);
        ctx.fillStyle = '#d4b06a';
        ctx.fillRect(7, 6, 2, 4);
        ctx.fillRect(6, 7, 4, 2);
        break;
      }

      case 'zeboim_floor': {
        ctx.fillStyle = '#2a3342';
        ctx.fillRect(0, 0, 16, 16);
        ctx.fillStyle = '#384559';
        ctx.fillRect(1, 1, 14, 14);
        ctx.fillStyle = '#202733';
        ctx.fillRect(0, 7, 16, 1);
        ctx.fillRect(7, 0, 1, 16);
        ctx.fillStyle = '#477696';
        ctx.fillRect(7, 7, 2, 2);
        break;
      }

      case 'wall_stone': {
        ctx.fillStyle = '#4d4843';
        ctx.fillRect(0, 0, 16, 16);
        for (let row = 0; row < 4; row++) {
          const offset = (row % 2) * 4;
          for (let col = -1; col < 3; col++) {
            const bx = col * 8 + offset;
            const by = row * 4;
            ctx.fillStyle = (row + col) % 2 === 0 ? '#8c8378' : '#7b7369';
            ctx.fillRect(bx + 1, by + 1, 7, 3);
            ctx.fillStyle = '#a3998d';
            ctx.fillRect(bx + 1, by + 1, 7, 1);
          }
        }
        break;
      }

      case 'wall_cathedral': {
        ctx.fillStyle = '#9a9387';
        ctx.fillRect(0, 0, 16, 16);
        for (let row = 0; row < 4; row++) {
          const y = row * 4;
          ctx.fillStyle = '#cfc7b9';
          ctx.fillRect(0, y + 1, 16, 3);
          ctx.fillStyle = '#e0d8ca';
          ctx.fillRect(0, y + 1, 16, 1);
          ctx.fillStyle = '#b1a898';
          ctx.fillRect(((row % 2) * 8) % 16, y, 1, 4);
        }
        ctx.fillStyle = '#c8a662';
        ctx.fillRect(0, 14, 16, 2);
        break;
      }

      case 'wall_stucco': {
        ctx.fillStyle = '#d8ccb4';
        ctx.fillRect(0, 0, 16, 16);
        // Timber half-framing
        ctx.fillStyle = '#5c3f28';
        ctx.fillRect(0, 0, 16, 2);
        ctx.fillRect(0, 14, 16, 2);
        ctx.fillRect(0, 0, 2, 16);
        ctx.fillRect(14, 0, 2, 16);
        ctx.fillRect(7, 2, 2, 12);
        ctx.fillStyle = '#c7b89c';
        ctx.fillRect(2, 12, 12, 2);
        break;
      }

      case 'wall_wood': {
        ctx.fillStyle = '#5f4027';
        ctx.fillRect(0, 0, 16, 16);
        for (let x = 0; x < 16; x += 4) {
          ctx.fillStyle = '#3f2817';
          ctx.fillRect(x, 0, 1, 16);
          ctx.fillStyle = '#735034';
          ctx.fillRect(x + 1, 0, 1, 16);
        }
        ctx.fillStyle = '#472f1c';
        ctx.fillRect(0, 13, 16, 3);
        break;
      }

      case 'wall_zeboim': {
        ctx.fillStyle = '#252f3d';
        ctx.fillRect(0, 0, 16, 16);
        ctx.fillStyle = '#323f52';
        ctx.fillRect(1, 1, 14, 6);
        ctx.fillRect(1, 9, 14, 6);
        ctx.fillStyle = '#4d98c4';
        ctx.fillRect(0, 7, 16, 2);
        ctx.fillStyle = '#7ad4ff';
        ctx.fillRect(3, 7, 4, 1);
        ctx.fillRect(10, 8, 3, 1);
        break;
      }

      case 'roof_clay': {
        ctx.fillStyle = '#803d2c';
        ctx.fillRect(0, 0, 16, 16);
        for (let y = 0; y < 16; y += 4) {
          ctx.fillStyle = '#9c4c37';
          ctx.fillRect(0, y, 16, 2);
          ctx.fillStyle = '#5e2a1d';
          ctx.fillRect(0, y + 3, 16, 1);
          for (let x = (y % 8 === 0 ? 0 : 2); x < 16; x += 4) {
            ctx.fillStyle = '#693022';
            ctx.fillRect(x, y, 1, 4);
          }
        }
        break;
      }

      case 'roof_slate': {
        ctx.fillStyle = '#344156';
        ctx.fillRect(0, 0, 16, 16);
        for (let y = 0; y < 16; y += 4) {
          ctx.fillStyle = '#465873';
          ctx.fillRect(0, y, 16, 2);
          ctx.fillStyle = '#232c3b';
          ctx.fillRect(0, y + 3, 16, 1);
          for (let x = (y % 8 === 0 ? 0 : 2); x < 16; x += 4) {
            ctx.fillStyle = '#2b3648';
            ctx.fillRect(x, y, 1, 4);
          }
        }
        break;
      }

      case 'stained_glass': {
        ctx.fillStyle = '#1b2640';
        ctx.fillRect(0, 0, 32, 32);
        // Ornate gold & azure lancet window
        ctx.fillStyle = '#4c88cc';
        ctx.fillRect(4, 4, 24, 24);
        ctx.fillStyle = '#70b8f0';
        ctx.fillRect(8, 6, 16, 20);
        // Rose emblem in center
        ctx.fillStyle = '#f2c86b';
        ctx.fillRect(11, 10, 10, 10);
        ctx.fillStyle = '#e06464';
        ctx.fillRect(13, 12, 6, 6);
        ctx.fillStyle = '#fff1c4';
        ctx.fillRect(15, 14, 2, 2);
        // Lead mullions
        ctx.fillStyle = '#141b2c';
        ctx.fillRect(15, 2, 2, 28);
        ctx.fillRect(2, 15, 28, 2);
        ctx.strokeStyle = '#c8a662';
        ctx.lineWidth = 2;
        ctx.strokeRect(2, 2, 28, 28);
        break;
      }

      case 'sophia_portrait': {
        // Golden frame
        ctx.fillStyle = '#b98f46';
        ctx.fillRect(0, 0, 32, 32);
        ctx.fillStyle = '#e6c57a';
        ctx.fillRect(1, 1, 30, 30);
        // Deep sanctuary blue sky backdrop
        ctx.fillStyle = '#273a61';
        ctx.fillRect(3, 3, 26, 26);
        // Golden halo
        ctx.fillStyle = '#f0cc75';
        ctx.fillRect(10, 5, 12, 10);
        ctx.fillStyle = '#273a61';
        ctx.fillRect(12, 7, 8, 8);
        // Sophia's long crimson-auburn hair
        ctx.fillStyle = '#99333a';
        ctx.fillRect(11, 7, 10, 14);
        ctx.fillStyle = '#b8464d';
        ctx.fillRect(12, 8, 8, 4);
        // Face
        ctx.fillStyle = '#f4d9c0';
        ctx.fillRect(13, 10, 6, 6);
        ctx.fillStyle = '#2c2530';
        ctx.fillRect(14, 12, 1, 1);
        ctx.fillRect(17, 12, 1, 1);
        // White & gold Holy Mother robes
        ctx.fillStyle = '#ece6d8';
        ctx.fillRect(9, 17, 14, 12);
        ctx.fillStyle = '#d4b06a';
        ctx.fillRect(14, 17, 4, 12);
        ctx.fillRect(11, 19, 10, 2);
        break;
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.magFilter = THREE.NearestFilter;
    texture.minFilter = THREE.NearestFilter;
    texture.generateMipmaps = false;
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }

  public disposeAll() {
    this.cache.forEach((t) => t.dispose());
    this.cache.clear();
    this.bumpCache.forEach((t) => t.dispose());
    this.bumpCache.clear();
  }
}

export const PixelTextureFactory = new PixelTextureFactoryImpl();
