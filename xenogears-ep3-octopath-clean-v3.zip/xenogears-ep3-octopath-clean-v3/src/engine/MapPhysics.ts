import {
  Direction,
  InteractablePrompt,
  MapDefinition,
  WarpZone,
} from '../types/rpg';

export interface BreadcrumbPoint {
  x: number;
  z: number;
  facing: Direction;
}

export function isTileWalkable(
  map: MapDefinition,
  tileX: number,
  tileZ: number,
  questFlags: Record<string, boolean>
): boolean {
  const ix = Math.round(tileX);
  const iz = Math.round(tileZ);
  if (ix < 0 || iz < 0 || ix >= map.width || iz >= map.depth) return false;
  if (map.collisionGrid[iz]?.[ix] === 1) return false;

  // Check locked switch gates
  if (map.switches) {
    for (const sw of map.switches) {
      if (!questFlags[sw.flagId]) {
        for (const gt of sw.gateTiles) {
          if (gt.x === ix && gt.z === iz) return false;
        }
      }
    }
  }
  return true;
}

export function getElevationAt(map: MapDefinition, x: number, z: number): number {
  const ix = Math.max(0, Math.min(map.width - 1, Math.round(x)));
  const iz = Math.max(0, Math.min(map.depth - 1, Math.round(z)));
  return map.heightGrid[iz]?.[ix] ?? 0;
}

export function canStepTo(
  map: MapDefinition,
  fromX: number,
  fromZ: number,
  toX: number,
  toZ: number,
  questFlags: Record<string, boolean>
): boolean {
  // Check bounding box corners (small character radius = 0.26 tiles)
  const r = 0.24;
  const checks = [
    [toX - r, toZ - r],
    [toX + r, toZ - r],
    [toX - r, toZ + r],
    [toX + r, toZ + r],
  ];
  for (const [cx, cz] of checks) {
    if (!isTileWalkable(map, cx, cz, questFlags)) return false;
  }

  // Elevation delta cap (stairs bridge 0.5u steps smoothly; sheer cliffs > 0.6u block)
  const hFrom = getElevationAt(map, fromX, fromZ);
  const hTo = getElevationAt(map, toX, toZ);
  if (Math.abs(hTo - hFrom) > 0.65) return false;

  return true;
}

export function findTriggeredWarp(
  map: MapDefinition,
  x: number,
  z: number
): WarpZone | null {
  for (const w of map.warpZones) {
    const ww = w.width ?? 1;
    const wd = w.depth ?? 1;
    const minX = w.x - 0.45;
    const maxX = w.x + (ww - 1) + 0.45;
    const minZ = w.z - 0.45;
    const maxZ = w.z + (wd - 1) + 0.45;
    if (x >= minX && x <= maxX && z >= minZ && z <= maxZ) {
      return w;
    }
  }
  return null;
}

export function findNearestInteractable(
  map: MapDefinition,
  playerX: number,
  playerZ: number,
  facing: Direction,
  openedChests: string[],
  questFlags: Record<string, boolean>,
  npcPositions?: Record<string, { x: number; z: number }>,
  maxDistance = 1.65
): InteractablePrompt | null {
  const dirVec: Record<Direction, [number, number]> = {
    N: [0, -1],
    S: [0, 1],
    E: [1, 0],
    W: [-1, 0],
  };
  const [fx, fz] = dirVec[facing];
  const probeX = playerX + fx * 0.65;
  const probeZ = playerZ + fz * 0.65;

  let best: { item: InteractablePrompt; score: number } | null = null;

  const consider = (item: InteractablePrompt) => {
    const distPlayer = Math.hypot(item.x - playerX, item.z - playerZ);
    if (distPlayer > maxDistance) return;
    const distProbe = Math.hypot(item.x - probeX, item.z - probeZ);
    const score = distProbe * 0.7 + distPlayer * 0.3;
    if (!best || score < best.score) {
      best = { item, score };
    }
  };

  // NPCs
  for (const npc of map.npcs) {
    if (npc.questFlagCondition) {
      const current = Boolean(questFlags[npc.questFlagCondition.flag]);
      if (current !== npc.questFlagCondition.expected) continue;
    }
    const pos = npcPositions?.[npc.id] ?? { x: npc.x, z: npc.z };
    const actionPrefix =
      npc.shopType === 'inn'
        ? 'Rest'
        : npc.shopType === 'armory'
          ? 'Armory'
          : npc.shopType === 'items'
            ? 'Items'
            : 'Talk';
    consider({
      type: 'npc',
      id: npc.id,
      label: `${actionPrefix}: ${npc.name}`,
      x: pos.x,
      z: pos.z,
    });
  }

  // Chests
  for (const chest of map.chests) {
    if (openedChests.includes(chest.id)) continue;
    consider({
      type: 'chest',
      id: chest.id,
      label: `Open ${chest.label}`,
      x: chest.x,
      z: chest.z,
    });
  }

  // Save Points
  for (const sp of map.savePoints) {
    consider({
      type: 'save',
      id: sp.id,
      label: `Save: ${sp.label}`,
      x: sp.x,
      z: sp.z,
    });
  }

  // Floor Switches
  if (map.switches) {
    for (const sw of map.switches) {
      if (questFlags[sw.flagId]) continue;
      consider({
        type: 'switch',
        id: sw.id,
        label: `Activate ${sw.label}`,
        x: sw.x,
        z: sw.z,
      });
    }
  }

  return best ? (best as { item: InteractablePrompt; score: number }).item : null;
}

export function checkEncounterStep(
  map: MapDefinition,
  playerX: number,
  playerZ: number,
  currentStepAccum: number,
  stepThreshold: number,
  rng: () => number = Math.random
): {
  triggered: boolean;
  enemyIds: string[];
  arenaTheme: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps';
  nextThreshold: number;
} {
  // Strictly zero random battles inside Towns or Interiors
  if (map.encounterZones.length === 0) {
    return {
      triggered: false,
      enemyIds: [],
      arenaTheme: map.arenaTheme,
      nextThreshold: stepThreshold,
    };
  }

  const zone = map.encounterZones.find(
    (z) => playerX >= z.minX && playerX <= z.maxX && playerZ >= z.minZ && playerZ <= z.maxZ
  );
  if (!zone) {
    return {
      triggered: false,
      enemyIds: [],
      arenaTheme: map.arenaTheme,
      nextThreshold: stepThreshold,
    };
  }

  if (currentStepAccum >= stepThreshold) {
    const groupIdx = Math.floor(rng() * zone.enemyGroups.length);
    const nextT =
      zone.stepThresholdMin +
      Math.floor(rng() * (zone.stepThresholdMax - zone.stepThresholdMin + 1));
    return {
      triggered: true,
      enemyIds: zone.enemyGroups[groupIdx] ?? zone.enemyGroups[0],
      arenaTheme: zone.arenaTheme,
      nextThreshold: nextT,
    };
  }

  return {
    triggered: false,
    enemyIds: [],
    arenaTheme: zone.arenaTheme,
    nextThreshold: stepThreshold,
  };
}

export function pushBreadcrumb(
  trail: BreadcrumbPoint[],
  x: number,
  z: number,
  facing: Direction,
  minStepDist = 0.08,
  maxPoints = 96
): BreadcrumbPoint[] {
  const head = trail[0];
  if (head && Math.hypot(head.x - x, head.z - z) < minStepDist) {
    return trail;
  }
  const next = [{ x, z, facing }, ...trail];
  if (next.length > maxPoints) {
    next.length = maxPoints;
  }
  return next;
}

export function sampleBreadcrumb(
  trail: BreadcrumbPoint[],
  followerIndex: number,
  spacing = 0.85
): BreadcrumbPoint | null {
  if (trail.length === 0) return null;
  const targetDist = followerIndex * spacing;
  let accum = 0;
  for (let i = 0; i < trail.length - 1; i++) {
    const a = trail[i];
    const b = trail[i + 1];
    const seg = Math.hypot(b.x - a.x, b.z - a.z);
    if (accum + seg >= targetDist && seg > 0.0001) {
      const t = (targetDist - accum) / seg;
      return {
        x: a.x + (b.x - a.x) * t,
        z: a.z + (b.z - a.z) * t,
        facing: a.facing,
      };
    }
    accum += seg;
  }
  return trail[trail.length - 1];
}
