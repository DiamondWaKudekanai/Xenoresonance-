import { DEATHBLOWS, ITEMS } from '../data/itemsAndGear';
import {
  APInput,
  BattleEnemyInstance,
  DeathblowDef,
  PartyMember,
  WeaknessType,
} from '../types/rpg';

export const AP_COST_MAP: Record<APInput, number> = {
  T: 1, // Weak
  S: 2, // Medium
  X: 3, // Strong
};

export const MAX_TURN_AP = 7;

export interface DerivedStats {
  atk: number;
  def: number;
  ether: number;
  spd: number;
  maxHp: number;
  gearAtk: number;
  gearDef: number;
  gearMaxHp: number;
  gearMaxFuel: number;
}

export function getMemberStats(member: PartyMember): DerivedStats {
  const weapon = member.weaponId ? ITEMS[member.weaponId]?.stats : undefined;
  const armor = member.armorId ? ITEMS[member.armorId]?.stats : undefined;
  const acc = member.accessoryId ? ITEMS[member.accessoryId]?.stats : undefined;
  const gearPart = member.gear?.equippedPartId
    ? ITEMS[member.gear.equippedPartId]?.stats
    : undefined;

  const atk = member.baseAtk + (weapon?.atk ?? 0) + (armor?.atk ?? 0) + (acc?.atk ?? 0);
  const def = member.baseDef + (weapon?.def ?? 0) + (armor?.def ?? 0) + (acc?.def ?? 0);
  const ether = member.baseEther + (weapon?.ether ?? 0) + (armor?.ether ?? 0) + (acc?.ether ?? 0);
  const spd = member.baseSpd + (weapon?.spd ?? 0) + (armor?.spd ?? 0) + (acc?.spd ?? 0);
  const maxHp = member.maxHp + (armor?.maxHp ?? 0) + (acc?.maxHp ?? 0);

  const gearAtk = atk + (member.gear?.atkBonus ?? 0) + (gearPart?.atk ?? 0);
  const gearDef = def + (member.gear?.defBonus ?? 0) + (gearPart?.def ?? 0);
  const gearMaxHp = (member.gear?.maxFrameHp ?? 0) + (gearPart?.frameHp ?? 0);
  const gearMaxFuel = (member.gear?.maxFuel ?? 0) + (gearPart?.maxFuel ?? 0);

  return { atk, def, ether, spd, maxHp, gearAtk, gearDef, gearMaxHp, gearMaxFuel };
}

export function getSequenceApCost(seq: APInput[]): number {
  return seq.reduce((sum, key) => sum + AP_COST_MAP[key], 0);
}

export function matchDeathblow(seq: APInput[], memberLevel: number): DeathblowDef | null {
  for (const db of DEATHBLOWS) {
    if (memberLevel < db.requiredLevel) continue;
    if (db.sequence.length !== seq.length) continue;
    let exact = true;
    for (let i = 0; i < seq.length; i++) {
      if (db.sequence[i] !== seq[i]) {
        exact = false;
        break;
      }
    }
    if (exact) return db;
  }
  return null;
}

export interface TurnTimelineSlot {
  uid: string;
  name: string;
  side: 'party' | 'enemy';
  spriteId: string;
  accentColor: string;
  isActive: boolean;
}

export function computeTurnTimeline(
  party: PartyMember[],
  enemies: BattleEnemyInstance[],
  activeUid: string | null,
  slots = 8
): TurnTimelineSlot[] {
  const combatants: Array<{
    uid: string;
    name: string;
    side: 'party' | 'enemy';
    spriteId: string;
    accentColor: string;
    spd: number;
    broken: boolean;
  }> = [];

  for (const p of party) {
    if (!p.joined || p.hp <= 0) continue;
    const stats = getMemberStats(p);
    combatants.push({
      uid: p.id,
      name: p.name,
      side: 'party',
      spriteId: p.spriteId,
      accentColor: p.accentColor,
      spd: stats.spd,
      broken: false,
    });
  }

  for (const e of enemies) {
    if (e.hp <= 0) continue;
    combatants.push({
      uid: e.uid,
      name: e.name,
      side: 'enemy',
      spriteId: e.spriteId,
      accentColor: e.isBoss ? '#e05858' : '#b46f5c',
      spd: e.spd,
      broken: e.brokenTurns > 0,
    });
  }

  if (combatants.length === 0) return [];

  // Sort by speed descending, broken enemies pushed behind unbroken
  const sorted = [...combatants].sort((a, b) => {
    if (a.broken !== b.broken) return a.broken ? 1 : -1;
    return b.spd - a.spd;
  });

  // Rotate so activeUid is first if present
  const activeIdx = activeUid ? sorted.findIndex((c) => c.uid === activeUid) : 0;
  const ordered =
    activeIdx >= 0
      ? [...sorted.slice(activeIdx), ...sorted.slice(0, activeIdx)]
      : sorted;

  const result: TurnTimelineSlot[] = [];
  for (let i = 0; i < slots; i++) {
    const c = ordered[i % ordered.length];
    result.push({
      uid: c.uid,
      name: c.name,
      side: c.side,
      spriteId: c.spriteId,
      accentColor: c.accentColor,
      isActive: i === 0 && c.uid === activeUid,
    });
  }
  return result;
}

export interface AttackResolution {
  damage: number;
  hitWeakness: boolean;
  triggeredBreak: boolean;
  newShield: number;
  newHp: number;
  deathblowUsed: DeathblowDef | null;
  bankedAp: number;
}

export function resolveOnFootCombo(
  attacker: PartyMember,
  target: BattleEnemyInstance,
  sequence: APInput[],
  useBoostBurst: boolean
): AttackResolution {
  const stats = getMemberStats(attacker);
  const apSpent = getSequenceApCost(sequence);
  const bankedAp = Math.max(0, MAX_TURN_AP - apSpent);
  const deathblow = matchDeathblow(sequence, attacker.level);

  let rawMult = 0;
  for (const input of sequence) {
    rawMult += input === 'T' ? 0.38 : input === 'S' ? 0.65 : 0.95;
  }
  if (deathblow) {
    const masteryBonus = 1 + (attacker.deathblowMastery[deathblow.id] ?? 0) * 0.0025;
    rawMult = deathblow.multiplier * masteryBonus;
  }
  if (useBoostBurst) {
    rawMult *= 1.45;
  }

  // Element determination: Deathblow element or weapon-based Sword/Physical
  const attackElement: WeaknessType = deathblow
    ? deathblow.element
    : attacker.id === 'roni' || attacker.id === 'krelian'
      ? 'SWORD'
      : 'PHYSICAL';

  const isWeak = target.weaknesses.includes(attackElement);
  const shieldHitCount = isWeak ? (deathblow ? 2 : 1) + (useBoostBurst ? 1 : 0) : 0;

  let newShield = target.shield;
  let triggeredBreak = false;
  if (target.brokenTurns <= 0 && shieldHitCount > 0) {
    newShield = Math.max(0, target.shield - shieldHitCount);
    if (newShield === 0 && target.shield > 0) {
      triggeredBreak = true;
    }
  }

  const breakMultiplier = target.brokenTurns > 0 || triggeredBreak ? 2.0 : 1.0;
  const weaknessMultiplier = isWeak ? 1.3 : 1.0;
  const baseDmg = Math.max(8, stats.atk * 2.15 - target.def * 0.72);
  const damage = Math.max(1, Math.round(baseDmg * rawMult * weaknessMultiplier * breakMultiplier));
  const newHp = Math.max(0, target.hp - damage);

  return {
    damage,
    hitWeakness: isWeak,
    triggeredBreak,
    newShield,
    newHp,
    deathblowUsed: deathblow,
    bankedAp,
  };
}

export function resolveGearAttack(
  attacker: PartyMember,
  target: BattleEnemyInstance,
  attackLevel: 1 | 2 | 3 | 4, // 4 = Infinity
  boosterActive: boolean
): {
  damage: number;
  fuelCost: number;
  hitWeakness: boolean;
  triggeredBreak: boolean;
  newShield: number;
  newHp: number;
} {
  const stats = getMemberStats(attacker);
  const baseFuelCost = attackLevel === 1 ? 60 : attackLevel === 2 ? 120 : attackLevel === 3 ? 210 : 0;
  const fuelCost = baseFuelCost + (boosterActive ? 40 : 0);
  const levelMult = attackLevel === 1 ? 1.4 : attackLevel === 2 ? 2.1 : attackLevel === 3 ? 3.0 : 4.2;

  const gearElement: WeaknessType =
    attacker.id === 'sophia' ? 'ETHER' : attacker.id === 'krelian' ? 'LIGHTNING' : 'SWORD';
  const hitWeakness = target.weaknesses.includes(gearElement) || attackLevel >= 3;

  let newShield = target.shield;
  let triggeredBreak = false;
  if (target.brokenTurns <= 0 && hitWeakness) {
    const breakHits = attackLevel >= 3 ? 2 : 1;
    newShield = Math.max(0, target.shield - breakHits);
    if (newShield === 0 && target.shield > 0) {
      triggeredBreak = true;
    }
  }

  const breakMult = target.brokenTurns > 0 || triggeredBreak ? 2.0 : 1.0;
  const baseDmg = Math.max(25, stats.gearAtk * 2.4 - target.def * 0.65);
  const damage = Math.max(
    1,
    Math.round(baseDmg * levelMult * (hitWeakness ? 1.25 : 1.0) * breakMult)
  );
  return {
    damage,
    fuelCost,
    hitWeakness,
    triggeredBreak,
    newShield,
    newHp: Math.max(0, target.hp - damage),
  };
}

export function resolveEtherSkill(
  caster: PartyMember,
  target: BattleEnemyInstance,
  skillPower: number,
  element: WeaknessType,
  useBoost: boolean
): {
  damage: number;
  hitWeakness: boolean;
  triggeredBreak: boolean;
  newShield: number;
  newHp: number;
} {
  const stats = getMemberStats(caster);
  const hitWeakness = target.weaknesses.includes(element);
  let newShield = target.shield;
  let triggeredBreak = false;
  if (target.brokenTurns <= 0 && hitWeakness) {
    const hits = useBoost ? 2 : 1;
    newShield = Math.max(0, target.shield - hits);
    if (newShield === 0 && target.shield > 0) {
      triggeredBreak = true;
    }
  }
  const breakMult = target.brokenTurns > 0 || triggeredBreak ? 2.0 : 1.0;
  const boostMult = useBoost ? 1.4 : 1.0;
  const base = Math.max(12, stats.ether * 2.55 - target.def * 0.45);
  const damage = Math.max(
    1,
    Math.round(base * skillPower * (hitWeakness ? 1.3 : 1.0) * breakMult * boostMult)
  );
  return {
    damage,
    hitWeakness,
    triggeredBreak,
    newShield,
    newHp: Math.max(0, target.hp - damage),
  };
}

export interface LevelUpResult {
  updatedMember: PartyMember;
  leveledUp: boolean;
  newLevel: number;
}

export function awardMemberXp(member: PartyMember, xpGain: number, usedDeathblowId?: string): LevelUpResult {
  let updated: PartyMember = {
    ...member,
    xp: member.xp + xpGain,
    deathblowMastery: { ...member.deathblowMastery },
  };
  if (usedDeathblowId) {
    updated.deathblowMastery[usedDeathblowId] = Math.min(
      100,
      (updated.deathblowMastery[usedDeathblowId] ?? 0) + 12
    );
  }
  let leveledUp = false;
  while (updated.xp >= updated.nextLevelXp) {
    updated.xp -= updated.nextLevelXp;
    updated.level += 1;
    updated.nextLevelXp = Math.round(updated.nextLevelXp * 1.45);
    updated.maxHp += 24;
    updated.hp = updated.maxHp;
    updated.maxEp += 6;
    updated.ep = updated.maxEp;
    updated.baseAtk += 3;
    updated.baseDef += 2;
    updated.baseEther += 3;
    updated.baseSpd += 1;
    leveledUp = true;
  }
  return { updatedMember: updated, leveledUp, newLevel: updated.level };
}
