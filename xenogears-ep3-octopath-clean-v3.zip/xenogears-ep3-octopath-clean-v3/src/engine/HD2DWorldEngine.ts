import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import {
  Building3DSpec,
  Direction,
  GraphicsQuality,
  InteractablePrompt,
  MapDefinition,
  PartyMember,
  Prop3DSpec,
  TileType,
} from '../types/rpg';
import {
  BreadcrumbPoint,
  canStepTo,
  checkEncounterStep,
  findNearestInteractable,
  findTriggeredWarp,
  getElevationAt,
  pushBreadcrumb,
  sampleBreadcrumb,
} from './MapPhysics';
import { PixelTextureFactory, PixelTileKey } from './PixelTextureFactory';
import { ChibiSpriteAnimator } from './SpriteAnimator';

const CHIBI_HEIGHT = 1.15;

const TiltShiftShader = {
  uniforms: {
    tDiffuse: { value: null },
    vBlur: { value: 0.0022 },
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform float vBlur;
    varying vec2 vUv;
    void main() {
      float dist = abs(vUv.y - 0.52);
      float blur = smoothstep(0.18, 0.5, dist) * vBlur;
      vec4 sum = texture2D(tDiffuse, vUv) * 0.44;
      sum += texture2D(tDiffuse, vUv + vec2(0.0, blur)) * 0.16;
      sum += texture2D(tDiffuse, vUv - vec2(0.0, blur)) * 0.16;
      sum += texture2D(tDiffuse, vUv + vec2(blur * 0.7, 0.0)) * 0.12;
      sum += texture2D(tDiffuse, vUv - vec2(blur * 0.7, 0.0)) * 0.12;
      gl_FragColor = sum;
    }
  `,
};

export function detectSoftwareWebGL(): boolean {
  if (typeof document === 'undefined') return true;
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export interface WorldInputState {
  moveX: number; // -1..1
  moveZ: number; // -1..1
  sprint: boolean;
}

export interface WorldEngineCallbacks {
  onWarp: (targetMap: MapDefinition['id'], x: number, z: number, facing: Direction) => void;
  onEncounter: (enemyIds: string[], arenaTheme: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps') => void;
  onPromptChange: (prompt: InteractablePrompt | null) => void;
  onPositionSample: (x: number, z: number, facing: Direction) => void;
}

interface NpcRuntime {
  id: string;
  def: MapDefinition['npcs'][number];
  animator: ChibiSpriteAnimator;
  x: number;
  z: number;
  facing: Direction;
  waypointIdx: number;
  pauseTimer: number;
}

interface ChestRuntime {
  id: string;
  closedMesh: THREE.Mesh;
  openMesh: THREE.Mesh;
  opened: boolean;
}

const _camTarget = new THREE.Vector3();
const _camDesired = new THREE.Vector3();
const _lookVec = new THREE.Vector3();

function createSpeechBubbleTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 24;
  c.height = 24;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = '#141926';
  ctx.fillRect(2, 3, 20, 14);
  ctx.fillRect(9, 17, 6, 3);
  ctx.fillRect(11, 20, 2, 2);
  ctx.fillStyle = '#f5ecd7';
  ctx.fillRect(4, 5, 16, 10);
  ctx.fillStyle = '#c89e52';
  ctx.fillRect(6, 9, 2, 2);
  ctx.fillRect(11, 9, 2, 2);
  ctx.fillRect(16, 9, 2, 2);
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export class HD2DWorldEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private composer: EffectComposer | null = null;
  private isSoftwareGl: boolean;
  private quality: GraphicsQuality = 'medium';
  private mapGroup: THREE.Group;
  private dynamicGroup: THREE.Group;
  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private flickerLights: Array<{ light: THREE.PointLight; baseIntensity: number; phase: number }> = [];
  private dustPoints: THREE.Points | null = null;
  private waterMeshes: THREE.Mesh[] = [];
  private memoryCubes: THREE.Mesh[] = [];
  private gateMeshes: THREE.Mesh[] = [];
  private switchPads: Map<string, THREE.Mesh> = new Map();
  private chests = new Map<string, ChestRuntime>();
  private npcs: NpcRuntime[] = [];
  private partyAnimators: ChibiSpriteAnimator[] = [];
  private speechBubbleMesh: THREE.Sprite;

  private currentMap: MapDefinition | null = null;
  private questFlags: Record<string, boolean> = {};
  private openedChests: string[] = [];
  private activeParty: PartyMember[] = [];
  private callbacks: WorldEngineCallbacks;

  private playerX = 15;
  private playerZ = 17;
  private playerFacing: Direction = 'N';
  private trail: BreadcrumbPoint[] = [];
  private input: WorldInputState = { moveX: 0, moveZ: 0, sprint: false };
  private stepAccum = 0;
  private stepThreshold = 16;
  private warpCooldown = 0;
  private mode: 'title_tour' | 'gameplay' | 'frozen' = 'title_tour';
  private tourAngle = 0;
  private cameraPanOffset = { x: 0, z: 0 };
  private parallaxX = 0;
  private lastPromptKey = '';
  private posReportAccum = 0;

  private running = false;
  private hiddenPaused = false;
  private frameId = 0;
  private lastTime = 0;
  private resizeObserver: ResizeObserver | null = null;
  private onVisibilityChange: () => void;

  constructor(container: HTMLElement, callbacks: WorldEngineCallbacks, quality: GraphicsQuality) {
    this.container = container;
    this.callbacks = callbacks;
    this.quality = quality;
    this.isSoftwareGl = detectSoftwareWebGL();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 1.5)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.style.display = 'block';
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();

    // Mandatory studio environment map for metallic trim & realistic surface bounce
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // Octopath Traveler Diorama Camera (FOV 34°)
    const w = Math.max(1, container.clientWidth);
    const h = Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(34, w / h, 0.2, 120);

    // Core lighting rig (warm directional sun + soft blue hemisphere >= 0.75)
    this.hemiLight = new THREE.HemisphereLight(0x8eb2df, 0x56473d, 0.85);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xffd49b, 2.0);
    this.sunLight.position.set(16, 26, 18);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.02;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 70;
    const d = 22;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    this.mapGroup = new THREE.Group();
    this.dynamicGroup = new THREE.Group();
    this.scene.add(this.mapGroup);
    this.scene.add(this.dynamicGroup);

    // Floating pixel speech-bubble icon
    const bubbleMat = new THREE.SpriteMaterial({
      map: createSpeechBubbleTexture(),
      transparent: true,
      depthTest: false,
    });
    this.speechBubbleMesh = new THREE.Sprite(bubbleMat);
    this.speechBubbleMesh.scale.set(0.7, 0.7, 1);
    this.speechBubbleMesh.visible = false;
    this.speechBubbleMesh.renderOrder = 25;
    this.scene.add(this.speechBubbleMesh);

    this.applyQuality(quality);
    this.handleResize();

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);

    this.onVisibilityChange = () => {
      this.hiddenPaused = document.visibilityState === 'hidden';
      if (this.hiddenPaused) {
        window.cancelAnimationFrame(this.frameId);
        window.clearTimeout(this.frameId);
        this.frameId = 0;
      } else if (this.running) {
        this.lastTime = performance.now();
        this.scheduleNextTick();
      }
    };
    document.addEventListener('visibilitychange', this.onVisibilityChange);
  }

  public applyQuality(quality: GraphicsQuality) {
    this.quality = quality;
    const shadowSize = quality === 'low' ? 512 : 1024;
    this.sunLight.shadow.mapSize.width = shadowSize;
    this.sunLight.shadow.mapSize.height = shadowSize;
    if (this.sunLight.shadow.map) {
      this.sunLight.shadow.map.dispose();
      this.sunLight.shadow.map = null;
    }

    if (this.composer) {
      this.composer.dispose();
      this.composer = null;
    }

    // Mobile-safe Tilt-Shift DoF + Soft Bloom on GPU devices (skipped on software WebGL & low quality)
    if (!this.isSoftwareGl && quality !== 'low') {
      const w = Math.max(1, this.container.clientWidth);
      const h = Math.max(1, this.container.clientHeight);
      const composer = new EffectComposer(this.renderer);
      composer.addPass(new RenderPass(this.scene, this.camera));
      const bloom = new UnrealBloomPass(
        new THREE.Vector2(w, h),
        quality === 'high' ? 0.28 : 0.18,
        0.55,
        0.82
      );
      composer.addPass(bloom);
      const tiltShift = new ShaderPass(TiltShiftShader);
      tiltShift.uniforms.vBlur.value = quality === 'high' ? 0.0024 : 0.0016;
      composer.addPass(tiltShift);
      this.composer = composer;
    }
  }

  private handleResize() {
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    if (this.composer) {
      this.composer.setSize(w, h);
    }
    if (this.currentMap) {
      this.renderer.render(this.scene, this.camera);
    }
  }

  public setMode(mode: 'title_tour' | 'gameplay' | 'frozen') {
    this.mode = mode;
    if (mode !== 'gameplay') {
      this.speechBubbleMesh.visible = false;
      this.input.moveX = 0;
      this.input.moveZ = 0;
    }
  }

  public setInput(input: WorldInputState) {
    this.input = input;
  }

  public setQuestState(openedChests: string[], questFlags: Record<string, boolean>) {
    this.openedChests = openedChests;
    this.questFlags = questFlags;
    // Update opened chest lids immediately
    this.chests.forEach((c, id) => {
      const isOpen = openedChests.includes(id);
      c.opened = isOpen;
      c.closedMesh.visible = !isOpen; c.openMesh.visible = isOpen;
    });
    // Update gate meshes if switch unlocked
    if (this.currentMap?.switches) {
      for (const sw of this.currentMap.switches) {
        const unlocked = Boolean(questFlags[sw.flagId]);
        this.gateMeshes.forEach((m) => {
          if (m.userData.switchFlag === sw.flagId) {
            m.visible = !unlocked;
          }
        });
        const pad = this.switchPads.get(sw.id);
        if (pad) {
          const mat = pad.material as THREE.MeshStandardMaterial;
          mat.emissive.setHex(unlocked ? 0x3ae096 : 0x4dbbff);
        }
      }
    }
    // Hide NPCs whose questFlagCondition no longer matches (e.g. defeated Boss Guard)
    for (const npc of this.npcs) {
      if (npc.def.questFlagCondition) {
        const cur = Boolean(questFlags[npc.def.questFlagCondition.flag]);
        npc.animator.group.visible = cur === npc.def.questFlagCondition.expected;
      }
    }
  }

  public setCameraPan(dx: number, dz: number) {
    this.cameraPanOffset.x = dx;
    this.cameraPanOffset.z = dz;
  }

  public getPlayerState(): { x: number; z: number; facing: Direction } {
    return { x: this.playerX, z: this.playerZ, facing: this.playerFacing };
  }

  public faceNpcTowardPlayer(npcId: string) {
    const npc = this.npcs.find((n) => n.id === npcId);
    if (!npc) return;
    const dx = this.playerX - npc.x;
    const dz = this.playerZ - npc.z;
    if (Math.abs(dx) > Math.abs(dz)) {
      npc.facing = dx > 0 ? 'E' : 'W';
    } else {
      npc.facing = dz > 0 ? 'S' : 'N';
    }
    npc.pauseTimer = 3.0;
    npc.animator.updateOverworld(npc.facing, false, 0);
  }

  public loadMap(
    map: MapDefinition,
    spawnX: number,
    spawnZ: number,
    facing: Direction,
    party: PartyMember[],
    openedChests: string[],
    questFlags: Record<string, boolean>
  ) {
    this.disposeMapScene();
    this.currentMap = map;
    this.activeParty = party.filter((p) => p.joined);
    this.openedChests = openedChests;
    this.questFlags = questFlags;
    this.playerX = spawnX;
    this.playerZ = spawnZ;
    this.playerFacing = facing;
    this.warpCooldown = 0.85;
    this.stepAccum = 0;

    // Seed party breadcrumb trail cleanly behind player facing direction (clamped to walkable ground)
    const backDx = facing === 'E' ? -1 : facing === 'W' ? 1 : 0;
    const backDz = facing === 'N' ? 1 : facing === 'S' ? -1 : 0;
    this.trail = [{ x: spawnX, z: spawnZ, facing }];
    let curX = spawnX;
    let curZ = spawnZ;
    for (let i = 1; i < 20; i++) {
      const candX = curX + backDx * 0.22;
      const candZ = curZ + backDz * 0.22;
      if (canStepTo(map, curX, curZ, candX, candZ, questFlags)) {
        curX = candX;
        curZ = candZ;
      }
      this.trail.push({ x: curX, z: curZ, facing });
    }

    // Atmosphere & Horizon Continuity
    this.scene.background = new THREE.Color(map.skyColor);
    this.scene.fog = new THREE.Fog(map.fogColor, map.fogNear, map.fogFar);

    this.hemiLight.color.set(map.hemiSkyColor);
    this.hemiLight.groundColor.set(map.hemiGroundColor);
    this.hemiLight.intensity = Math.max(0.82, map.hemiIntensity);

    this.sunLight.color.set(map.sunColor);
    this.sunLight.intensity = map.sunIntensity;
    this.sunLight.position.set(map.width * 0.5 + 14, 24, map.depth * 0.5 + 12);
    this.sunLight.target.position.set(map.width * 0.5, 0, map.depth * 0.5);

    this.buildTerrainTiles(map);
    this.buildBuildings(map);
    this.buildProps(map);
    this.buildChests(map);
    this.buildSavePoints(map);
    this.buildSwitchesAndGates(map);
    this.buildNpcs(map);
    this.buildPartyTrain(map);
    this.buildDustMotes(map);

    // Snap camera immediately & paint Frame 1 synchronously to prevent blank frames on transitions/reloads
    const elev = getElevationAt(map, spawnX, spawnZ);
    if (this.mode === 'title_tour') {
      const cx = map.width * 0.5;
      const cz = map.depth * 0.46;
      this.camera.position.set(cx, 7.6, cz + 17.5);
      this.camera.lookAt(cx, 2.6, cz - 3.6);
    } else {
      const camH = map.isOutdoor ? 8.2 : 7.2;
      const camZ = map.isOutdoor ? 12.2 : 10.6;
      this.camera.position.set(spawnX, elev + camH, spawnZ + camZ);
      this.camera.lookAt(spawnX, elev + 0.75, spawnZ - 0.6);
    }
    this.renderer.render(this.scene, this.camera);
  }

  private buildTerrainTiles(map: MapDefinition) {
    // Extended outdoor skirt + pixel-art sunset mountain horizon backdrop so outdoor maps never float in a void
    if (map.isOutdoor) {
      const skirtKey: PixelTileKey = map.id === 'worldmap_ignas' ? 'water' : 'grass';
      const skirtGeo = new THREE.PlaneGeometry(map.width + 60, map.depth + 60);
      skirtGeo.rotateX(-Math.PI / 2);
      const skirtTex = PixelTextureFactory.getTexture(skirtKey, 24, 24);
      const skirtMat = new THREE.MeshStandardMaterial({
        map: skirtTex,
        color: 0xffffff,
        roughness: 0.9,
      });
      const skirt = new THREE.Mesh(skirtGeo, skirtMat);
      skirt.position.set(map.width / 2, -0.35, map.depth / 2);
      skirt.receiveShadow = true;
      this.mapGroup.add(skirt);

      // Distant Pixel-Art Sunset Mountain Horizon Vista along the northern sky
      const skyTex = PixelTextureFactory.getPropTexture('backdrop_ignas.jpg');
      const skyMat = new THREE.MeshBasicMaterial({
        map: skyTex,
        fog: false,
        depthWrite: false,
      });
      const skyPlane = new THREE.Mesh(new THREE.PlaneGeometry(map.width + 44, 24), skyMat);
      skyPlane.position.set(map.width / 2, 10.2, -16.5);
      this.mapGroup.add(skyPlane);
    }

    // Group tiles by type + elevation for crisp modular 3D block geometry
    const tileBuckets = new Map<string, Array<{ x: number; z: number; h: number; tile: TileType }>>();
    for (let z = 0; z < map.depth; z++) {
      for (let x = 0; x < map.width; x++) {
        const tile = map.tiles[z][x];
        if (tile === 'void') continue;
        const h = map.heightGrid[z][x];
        const bucketKey = `${tile}:${h.toFixed(2)}`;
        const arr = tileBuckets.get(bucketKey) ?? [];
        arr.push({ x, z, h, tile });
        tileBuckets.set(bucketKey, arr);
      }
    }

    const dummy = new THREE.Object3D();

    tileBuckets.forEach((cells, key) => {
      const tile = key.split(':')[0] as TileType;
      const sampleH = cells[0].h;

      if (tile === 'stair_n' || tile === 'stair_s') {
        // Real 3D stepped stair mesh (4 steps per 1u tile)
        const tex = PixelTextureFactory.getTexture('stone_plaza');
        const mat = new THREE.MeshStandardMaterial({ map: tex, color: 0xffffff, roughness: 0.85 });
        for (const c of cells) {
          const stairGroup = new THREE.Group();
          for (let s = 0; s < 4; s++) {
            const stepGeo = new THREE.BoxGeometry(1, 0.16 + s * 0.14, 0.26);
            const stepMesh = new THREE.Mesh(stepGeo, mat);
            const zOff = tile === 'stair_n' ? 0.37 - s * 0.25 : -0.37 + s * 0.25;
            stepMesh.position.set(0, (0.16 + s * 0.14) / 2, zOff);
            stepMesh.receiveShadow = true;
            stepMesh.castShadow = true;
            stairGroup.add(stepMesh);
          }
          stairGroup.position.set(c.x, Math.max(0, c.h - 0.3), c.z);
          this.mapGroup.add(stairGroup);
        }
        return;
      }

      if (tile === 'bridge') {
        // Arched wooden 3D bridge planks + side handrails
        const plankTex = PixelTextureFactory.getTexture('bridge');
        const plankMat = new THREE.MeshStandardMaterial({ map: plankTex, color: 0xffffff, roughness: 0.85 });
        const railMat = new THREE.MeshStandardMaterial({ color: 0x5c3e26, roughness: 0.88 });
        for (const c of cells) {
          const deck = new THREE.Mesh(new THREE.BoxGeometry(1.02, 0.22, 1.02), plankMat);
          deck.position.set(c.x, c.h - 0.08, c.z);
          deck.receiveShadow = true;
          deck.castShadow = true;
          this.mapGroup.add(deck);

          // Add wooden bridge posts on outer edges
          if (c.x === 14) {
            const rail = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.55, 1.0), railMat);
            rail.position.set(c.x - 0.44, c.h + 0.22, c.z);
            this.mapGroup.add(rail);
          }
          if (c.x === 15) {
            const rail = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.55, 1.0), railMat);
            rail.position.set(c.x + 0.44, c.h + 0.22, c.z);
            this.mapGroup.add(rail);
          }
        }
        return;
      }

      if (tile === 'wall_stone' || tile === 'wall_wood' || tile === 'wall_zeboim') {
        const texKey: PixelTileKey =
          tile === 'wall_wood' ? 'wall_wood' : tile === 'wall_zeboim' ? 'wall_zeboim' : 'wall_stone';
        const mat = new THREE.MeshStandardMaterial({
          map: PixelTextureFactory.getTexture(texKey, 1, 2),
          bumpMap: PixelTextureFactory.getBumpMap(texKey),
          bumpScale: 0.03,
          color: 0xffffff,
          roughness: tile === 'wall_zeboim' ? 0.65 : 0.85,
          metalness: tile === 'wall_zeboim' ? 0.18 : 0.04,
        });

        // For Zeboim dungeon walls that sit immediately south of walkable chambers, cut away to a low parapet (0.62u)
        // so the fixed-tilt south camera never gets occluded by foreground partitions!
        const fullCells: typeof cells = [];
        const cutawayCells: typeof cells = [];
        for (const c of cells) {
          const isSouthPartition =
            tile === 'wall_zeboim' &&
            ((c.z >= 1 && map.tiles[c.z - 1][c.x] === 'zeboim_floor') ||
              (c.z >= 2 && map.tiles[c.z - 2][c.x] === 'zeboim_floor'));
          if (isSouthPartition) cutawayCells.push(c);
          else fullCells.push(c);
        }

        if (fullCells.length > 0) {
          const wallH = tile === 'wall_zeboim' ? 2.4 : 3.2;
          const geo = new THREE.BoxGeometry(1, wallH, 1);
          const inst = new THREE.InstancedMesh(geo, mat, fullCells.length);
          inst.castShadow = true;
          inst.receiveShadow = true;
          fullCells.forEach((c, idx) => {
            dummy.position.set(c.x, c.h + wallH * 0.5, c.z);
            dummy.rotation.set(0, 0, 0);
            dummy.scale.set(1, 1, 1);
            dummy.updateMatrix();
            inst.setMatrixAt(idx, dummy.matrix);
          });
          inst.instanceMatrix.needsUpdate = true;
          inst.computeBoundingSphere();
          this.mapGroup.add(inst);
        }

        if (cutawayCells.length > 0) {
          const cutH = 0.62;
          const geo = new THREE.BoxGeometry(1, cutH, 1);
          const cutMat = mat.clone();
          cutMat.map = PixelTextureFactory.getTexture(texKey, 1, 1);
          const inst = new THREE.InstancedMesh(geo, cutMat, cutawayCells.length);
          inst.castShadow = true;
          inst.receiveShadow = true;
          cutawayCells.forEach((c, idx) => {
            dummy.position.set(c.x, c.h + cutH * 0.5, c.z);
            dummy.rotation.set(0, 0, 0);
            dummy.scale.set(1, 1, 1);
            dummy.updateMatrix();
            inst.setMatrixAt(idx, dummy.matrix);
          });
          inst.instanceMatrix.needsUpdate = true;
          inst.computeBoundingSphere();
          this.mapGroup.add(inst);
        }
        return;
      }

      if (tile === 'mountain') {
        // Composite stepped pixel mountain peaks on World Map
        const tex = PixelTextureFactory.getTexture('mountain');
        const mat = new THREE.MeshStandardMaterial({ map: tex, color: 0xffffff, roughness: 0.92 });
        const geo = new THREE.ConeGeometry(0.75, 1.65, 4);
        const inst = new THREE.InstancedMesh(geo, mat, cells.length);
        inst.castShadow = true;
        inst.receiveShadow = true;
        cells.forEach((c, idx) => {
          const s = 0.85 + ((c.x * 7 + c.z * 13) % 5) * 0.08;
          dummy.position.set(c.x, 0.85 * s, c.z);
          dummy.rotation.set(0, Math.PI * 0.25, 0);
          dummy.scale.set(s, s, s);
          dummy.updateMatrix();
          inst.setMatrixAt(idx, dummy.matrix);
        });
        inst.instanceMatrix.needsUpdate = true;
        inst.computeBoundingSphere();
        this.mapGroup.add(inst);
        return;
      }

      const texKeyMap: Record<string, PixelTileKey> = {
        grass: 'grass',
        cobble: 'cobble',
        stone_plaza: 'stone_plaza',
        water: 'water',
        sand: 'sand',
        forest: 'forest',
        wood_floor: 'wood_floor',
        marble_checker: 'marble_checker',
        rug_red: 'rug_red',
        zeboim_floor: 'zeboim_floor',
      };
      const texKey = texKeyMap[tile] ?? 'grass';
      const tex = PixelTextureFactory.getTexture(texKey);
      const isWater = tile === 'water';
      const blockHeight = Math.max(0.32, sampleH + 0.35);
      const geo = new THREE.BoxGeometry(1, blockHeight, 1);
      const matParams: THREE.MeshStandardMaterialParameters = {
        map: tex,
        color: 0xffffff,
        roughness: isWater ? 0.25 : 0.86,
        metalness: isWater ? 0.22 : 0.02,
      };
      if (!isWater) {
        matParams.bumpMap = PixelTextureFactory.getBumpMap(texKey);
        matParams.bumpScale = 0.02;
      }
      const mat = new THREE.MeshStandardMaterial(matParams);

      const inst = new THREE.InstancedMesh(geo, mat, cells.length);
      inst.receiveShadow = true;
      inst.castShadow = sampleH > 0.3;
      cells.forEach((c, idx) => {
        dummy.position.set(c.x, c.h - blockHeight * 0.5, c.z);
        dummy.rotation.set(0, 0, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        inst.setMatrixAt(idx, dummy.matrix);
      });
      inst.instanceMatrix.needsUpdate = true;
      inst.computeBoundingSphere();
      this.mapGroup.add(inst);
      if (isWater) {
        this.waterMeshes.push(inst as unknown as THREE.Mesh);
      }
    });
  }

  private buildBuildings(map: MapDefinition) {
    for (const b of map.buildings) {
      this.mapGroup.add(this.createModularBuilding(map, b));
    }
  }

  private createModularBuilding(map: MapDefinition, b: Building3DSpec): THREE.Group {
    const group = new THREE.Group();
    const baseElev = getElevationAt(map, b.x + Math.floor(b.width / 2), b.z + b.depth);
    const centerX = b.x + b.width / 2 - 0.5;
    const centerZ = b.z + b.depth / 2 - 0.5;

    const wallTexKey: PixelTileKey =
      b.wallStyle === 'cathedral'
        ? 'wall_cathedral'
        : b.wallStyle === 'stucco'
          ? 'wall_stucco'
          : b.wallStyle === 'zeboim'
            ? 'wall_zeboim'
            : 'wall_stone';

    const wallMat = new THREE.MeshStandardMaterial({
      map: PixelTextureFactory.getTexture(wallTexKey, Math.max(1, Math.round(b.width / 2)), Math.max(1, Math.round(b.height / 2))),
      bumpMap: PixelTextureFactory.getBumpMap(wallTexKey),
      bumpScale: 0.03,
      color: 0xffffff,
      roughness: 0.82,
    });

    const wallHeight = b.height * 0.65;

    // 1. Stone foundation plinth
    const plinthMat = new THREE.MeshStandardMaterial({
      map: PixelTextureFactory.getTexture('wall_stone', Math.round(b.width), 1),
      color: 0xffffff,
      roughness: 0.9,
    });
    const plinth = new THREE.Mesh(
      new THREE.BoxGeometry(b.width + 0.2, 0.45, b.depth + 0.2),
      plinthMat
    );
    plinth.position.set(centerX, baseElev + 0.22, centerZ);
    plinth.castShadow = true;
    plinth.receiveShadow = true;
    group.add(plinth);

    // 2. Main 3D Building Body (split around real recessed doorway on south facade!)
    const mainBody = new THREE.Mesh(
      new THREE.BoxGeometry(b.width, wallHeight, b.depth - 0.45),
      wallMat
    );
    mainBody.position.set(centerX, baseElev + 0.45 + wallHeight / 2, centerZ - 0.22);
    mainBody.castShadow = true;
    mainBody.receiveShadow = true;
    group.add(mainBody);

    // Real recessed doorway frame & dark walkable interior portal
    if (b.doorTile) {
      const doorX = b.doorTile.x;
      const frontZ = b.z + b.depth - 0.5;
      const frameMat = new THREE.MeshStandardMaterial({ color: 0x4b3624, roughness: 0.85 });
      const recessMat = new THREE.MeshBasicMaterial({ color: 0x090b12 });

      // Left & right solid jambs framing the recessed entrance
      const jambL = new THREE.Mesh(new THREE.BoxGeometry(0.28, 1.9, 0.55), frameMat);
      jambL.position.set(doorX - 0.62, baseElev + 0.95, frontZ);
      const jambR = new THREE.Mesh(new THREE.BoxGeometry(0.28, 1.9, 0.55), frameMat);
      jambR.position.set(doorX + 0.62, baseElev + 0.95, frontZ);
      const lintel = new THREE.Mesh(new THREE.BoxGeometry(1.56, 0.28, 0.62), frameMat);
      lintel.position.set(doorX, baseElev + 1.96, frontZ);
      const recess = new THREE.Mesh(new THREE.PlaneGeometry(1.02, 1.78), recessMat);
      recess.position.set(doorX, baseElev + 0.92, frontZ - 0.16);
      // Warm interior spill glow above threshold
      const glowMat = new THREE.MeshBasicMaterial({
        color: 0xffc875,
        transparent: true,
        opacity: 0.35,
      });
      const glow = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.35), glowMat);
      glow.rotation.x = -Math.PI / 2;
      glow.position.set(doorX, baseElev + 0.03, frontZ + 0.25);

      group.add(jambL, jambR, lintel, recess, glow);
    }

    // 3. Warm glowing leaded-glass windows on south facade
    const winCount = b.windowCount ?? 2;
    const winMat = new THREE.MeshStandardMaterial({
      color: 0xffe2a8,
      emissive: 0xffb85c,
      emissiveIntensity: 0.85,
      roughness: 0.25,
    });
    const mullionMat = new THREE.MeshStandardMaterial({ color: 0x3b2c20, roughness: 0.9 });
    for (let i = 0; i < winCount; i++) {
      const wx = b.x + ((i + 1) / (winCount + 1)) * (b.width - 1);
      if (b.doorTile && Math.abs(wx - b.doorTile.x) < 1.2) continue;
      const wz = b.z + b.depth - 0.52;
      const wy = baseElev + 1.95;
      const pane = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.15, 0.1), winMat);
      pane.position.set(wx, wy, wz);
      const sill = new THREE.Mesh(new THREE.BoxGeometry(1.08, 0.14, 0.22), mullionMat);
      sill.position.set(wx, wy - 0.62, wz + 0.04);
      const header = new THREE.Mesh(new THREE.BoxGeometry(1.04, 0.1, 0.16), mullionMat);
      header.position.set(wx, wy + 0.6, wz + 0.03);
      const vBar = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.15, 0.14), mullionMat);
      vBar.position.set(wx, wy, wz + 0.02);
      const hBar = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.08, 0.14), mullionMat);
      hBar.position.set(wx, wy + 0.04, wz + 0.02);
      group.add(pane, sill, header, vBar, hBar);
    }

    // 4. Extruded Pitched Roof Prism (never flat billboards!)
    const roofTexKey: PixelTileKey =
      b.roofStyle === 'pitched_clay' ? 'roof_clay' : 'roof_slate';
    const roofMat = new THREE.MeshStandardMaterial({
      map: PixelTextureFactory.getTexture(roofTexKey, Math.round(b.width / 2), 2),
      color: 0xffffff,
      roughness: 0.78,
    });
    const roofHeight = b.height * 0.38;
    const overhang = 0.45;
    const halfD = b.depth / 2 + overhang;
    const roofShape = new THREE.Shape();
    roofShape.moveTo(-halfD, 0);
    roofShape.lineTo(0, roofHeight);
    roofShape.lineTo(halfD, 0);
    roofShape.closePath();

    const extrudeGeo = new THREE.ExtrudeGeometry(roofShape, {
      depth: b.width + overhang * 2,
      bevelEnabled: false,
    });
    // Rotate so gable runs along X
    extrudeGeo.rotateY(Math.PI / 2);
    extrudeGeo.translate(-(b.width + overhang * 2) / 2, 0, 0);

    const roofMesh = new THREE.Mesh(extrudeGeo, roofMat);
    roofMesh.position.set(centerX, baseElev + 0.45 + wallHeight, centerZ);
    roofMesh.castShadow = true;
    roofMesh.receiveShadow = true;
    group.add(roofMesh);

    // 5. Cathedral Belfry Spire & Stained Glass Rose Window for Nisan Cathedral
    if (b.roofStyle === 'cathedral_spire') {
      const spireBase = new THREE.Mesh(
        new THREE.BoxGeometry(2.6, 2.8, 2.6),
        wallMat
      );
      spireBase.position.set(centerX, baseElev + 0.45 + wallHeight + roofHeight * 0.6, centerZ - 1.2);
      spireBase.castShadow = true;
      const spireCone = new THREE.Mesh(
        new THREE.ConeGeometry(1.9, 3.4, 4),
        roofMat
      );
      spireCone.rotation.y = Math.PI / 4;
      spireCone.position.set(centerX, baseElev + 0.45 + wallHeight + roofHeight * 0.6 + 3.05, centerZ - 1.2);
      spireCone.castShadow = true;

      // Golden Nisan Sanctuary Crest above spire
      const crestMat = new THREE.MeshStandardMaterial({
        color: 0xe8c474,
        metalness: 0.85,
        roughness: 0.22,
      });
      const crest = new THREE.Mesh(new THREE.OctahedronGeometry(0.42, 0), crestMat);
      crest.position.set(centerX, spireCone.position.y + 2.0, centerZ - 1.2);

      // Rose Stained-Glass Medallion on front facade
      const roseMat = new THREE.MeshStandardMaterial({
        map: PixelTextureFactory.getTexture('stained_glass'),
        emissive: 0x8bbef5,
        emissiveIntensity: 0.55,
        roughness: 0.3,
      });
      const rose = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, 0.16, 16), roseMat);
      rose.rotation.x = Math.PI / 2;
      rose.position.set(centerX, baseElev + 4.3, b.z + b.depth - 0.52);

      group.add(spireBase, spireCone, crest, rose);
    }

    return group;
  }

  private createPropBillboard(
    filename: string,
    width: number,
    height: number,
    emissiveHex = 0x000000,
    emissiveIntensity = 0
  ): THREE.Group {
    const g = new THREE.Group();
    const tex = PixelTextureFactory.getPropTexture(filename);
    const mat = new THREE.MeshStandardMaterial({
      map: tex,
      transparent: true,
      alphaTest: 0.45,
      side: THREE.DoubleSide,
      roughness: 0.78,
      emissive: emissiveHex,
      emissiveIntensity,
    });
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, height), mat);
    mesh.position.y = height * 0.5;
    mesh.castShadow = true;
    mesh.receiveShadow = false;
    mesh.customDepthMaterial = new THREE.MeshDepthMaterial({
      depthPacking: THREE.RGBADepthPacking,
      map: tex,
      alphaTest: 0.45,
    });

    const shGeo = new THREE.CircleGeometry(width * 0.34, 14);
    shGeo.rotateX(-Math.PI / 2);
    const sh = new THREE.Mesh(
      shGeo,
      new THREE.MeshBasicMaterial({ color: 0x060a10, transparent: true, opacity: 0.36, depthWrite: false })
    );
    sh.position.y = 0.02;
    g.add(sh, mesh);
    return g;
  }

  private buildProps(map: MapDefinition) {
    let activePointLights = 0;
    const maxPointLights = this.quality === 'low' ? 3 : 5;

    for (const p of map.props) {
      const y = getElevationAt(map, p.x, p.z);
      const scale = p.scale ?? 1;

      switch (p.type) {
        case 'lantern': {
          const g = new THREE.Group();
          const lanTex = PixelTextureFactory.getPropTexture('wooden_lantern.png');
          const lanMat = new THREE.MeshStandardMaterial({
            map: lanTex,
            transparent: true,
            alphaTest: 0.5,
            side: THREE.DoubleSide,
            roughness: 0.8,
            emissive: 0xffb85c,
            emissiveIntensity: 0.22,
          });
          const lanMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.15, 2.05), lanMat);
          lanMesh.position.y = 1.02;
          lanMesh.castShadow = true;
          lanMesh.customDepthMaterial = new THREE.MeshDepthMaterial({
            depthPacking: THREE.RGBADepthPacking,
            map: lanTex,
            alphaTest: 0.5,
          });
          g.add(lanMesh);
          if (activePointLights < maxPointLights) {
            const pt = new THREE.PointLight(0xffb45c, 2.4, 7.5, 1.6);
            pt.position.y = 1.65;
            g.add(pt);
            this.flickerLights.push({ light: pt, baseIntensity: 2.4, phase: p.x * 1.3 + p.z });
            activePointLights++;
          }
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'tree_pine':
        case 'tree_oak': {
          const g = new THREE.Group();
          const isLanternTree = p.type === 'tree_oak';
          const treeTex = PixelTextureFactory.getPropTexture(
            isLanternTree ? 'pine_lantern_tree.png' : 'pine_cluster.png'
          );
          const treeW = isLanternTree ? 2.75 : 2.15;
          const treeH = isLanternTree ? 3.15 : 3.25;
          const treeMat = new THREE.MeshStandardMaterial({
            map: treeTex,
            transparent: true,
            alphaTest: 0.5,
            side: THREE.DoubleSide,
            roughness: 0.85,
            emissive: isLanternTree ? 0xffb85c : 0x000000,
            emissiveIntensity: isLanternTree ? 0.12 : 0,
          });
          const treeMesh = new THREE.Mesh(new THREE.PlaneGeometry(treeW, treeH), treeMat);
          treeMesh.position.y = treeH * 0.5;
          treeMesh.castShadow = true;
          treeMesh.customDepthMaterial = new THREE.MeshDepthMaterial({
            depthPacking: THREE.RGBADepthPacking,
            map: treeTex,
            alphaTest: 0.5,
          });
          // Soft contact shadow disc on ground
          const shGeo = new THREE.CircleGeometry(treeW * 0.34, 16);
          shGeo.rotateX(-Math.PI / 2);
          const sh = new THREE.Mesh(
            shGeo,
            new THREE.MeshBasicMaterial({ color: 0x060a10, transparent: true, opacity: 0.38, depthWrite: false })
          );
          sh.position.y = 0.02;
          g.add(sh, treeMesh);
          g.scale.setScalar(scale);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'stained_glass': {
          const g = new THREE.Group();
          const glassMat = new THREE.MeshStandardMaterial({
            map: PixelTextureFactory.getTexture('stained_glass'),
            emissive: 0x8cc2ff,
            emissiveIntensity: 0.9,
            roughness: 0.2,
          });
          const win = new THREE.Mesh(new THREE.BoxGeometry(1.7, 2.7, 0.14), glassMat);
          win.position.set(0, 2.1, 0);
          g.add(win);

          // Additive Volumetric Stained-Glass Sunbeam Shaft!
          const beamGeo = new THREE.PlaneGeometry(1.85, 6.2);
          const beamCanvas = document.createElement('canvas');
          beamCanvas.width = 32;
          beamCanvas.height = 64;
          const bctx = beamCanvas.getContext('2d')!;
          const grad = bctx.createLinearGradient(0, 0, 0, 64);
          grad.addColorStop(0, 'rgba(255, 232, 178, 0.42)');
          grad.addColorStop(0.55, 'rgba(176, 214, 255, 0.16)');
          grad.addColorStop(1, 'rgba(176, 214, 255, 0.0)');
          bctx.fillStyle = grad;
          bctx.fillRect(0, 0, 32, 64);
          const beamTex = new THREE.CanvasTexture(beamCanvas);
          beamTex.colorSpace = THREE.SRGBColorSpace;
          const beamMat = new THREE.MeshBasicMaterial({
            map: beamTex,
            transparent: true,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            side: THREE.DoubleSide,
          });
          const beam = new THREE.Mesh(beamGeo, beamMat);
          beam.position.set(0, 1.35, 2.25);
          beam.rotation.x = -Math.PI * 0.34;
          g.add(beam);

          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'altar_sophia': {
          const g = this.createPropBillboard('prop_altar.png', 2.4, 3.1, 0xffd27a, 0.14);
          // Iconic hand-drawn portrait of Sophia above the altar
          const canvasMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(1.65, 1.9),
            new THREE.MeshStandardMaterial({
              map: PixelTextureFactory.getTexture('sophia_portrait'),
              emissive: 0xffe4b0,
              emissiveIntensity: 0.14,
              roughness: 0.6,
            })
          );
          canvasMesh.position.set(0, 3.65, -0.25);
          g.add(canvasMesh);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'pew': {
          const pewFile = p.x < 8 ? 'prop_pew_left.png' : 'prop_pew_right.png';
          const g = this.createPropBillboard(pewFile, 2.3, 1.45);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'easel': {
          const g = this.createPropBillboard('prop_easel.png', 1.15, 1.75);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'paint_table':
        case 'tavern_table': {
          const g = this.createPropBillboard('prop_table_chairs.png', 1.95, 1.55);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'tavern_counter': {
          const g = this.createPropBillboard('prop_shop_counter.png', 2.6, 1.75);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'bed': {
          const g = this.createPropBillboard('prop_bed.png', 1.9, 1.45);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'bookshelf': {
          const g = this.createPropBillboard('prop_bookshelf.png', 1.55, 2.25);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'fireplace': {
          const g = this.createPropBillboard('prop_fireplace.png', 1.95, 2.55, 0xff8e42, 0.25);
          if (activePointLights < maxPointLights) {
            const pt = new THREE.PointLight(0xff8e42, 2.8, 9, 1.5);
            pt.position.set(0, 0.75, 0.8);
            g.add(pt);
            this.flickerLights.push({ light: pt, baseIntensity: 2.8, phase: 2.2 });
            activePointLights++;
          }
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'zeboim_pillar': {
          const g = new THREE.Group();
          const concrete = new THREE.MeshStandardMaterial({
            map: PixelTextureFactory.getTexture('wall_zeboim'),
            color: 0xffffff,
            roughness: 0.78,
          });
          const base = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.32, 0.95), concrete);
          base.position.y = 0.16;
          const shaftH = 2.0 + ((p.x * 3 + p.z) % 3) * 0.35;
          const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.4, shaftH, 8), concrete);
          shaft.position.y = 0.32 + shaftH * 0.5;
          shaft.castShadow = true;
          g.add(base, shaft);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'ether_conduit': {
          const g = new THREE.Group();
          const metal = new THREE.MeshStandardMaterial({ color: 0x2d3a4d, metalness: 0.75, roughness: 0.35 });
          const glow = new THREE.MeshStandardMaterial({
            color: 0x80e3ff,
            emissive: 0x3dbaff,
            emissiveIntensity: 1.9,
            roughness: 0.2,
          });
          const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.42, 0.4, 8), metal);
          ped.position.y = 0.2;
          const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 2.2, 8), glow);
          tube.position.y = 1.3;
          const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.25, 8), metal);
          cap.position.y = 2.45;
          g.add(ped, tube, cap);
          if (activePointLights < maxPointLights) {
            const pt = new THREE.PointLight(0x4fc3ff, 2.5, 8.5, 1.5);
            pt.position.y = 1.5;
            g.add(pt);
            this.flickerLights.push({ light: pt, baseIntensity: 2.5, phase: p.x + p.z * 0.7 });
            activePointLights++;
          }
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'omnigear_relic': {
          const g = this.createPropBillboard('prop_zeboim_console.png', 2.4, 2.75, 0x52c4ff, 0.25);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'world_nisan': {
          const g = this.createPropBillboard('landmark_nisan.png', 3.4, 3.6);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'world_zeboim': {
          const g = this.createPropBillboard('landmark_zeboim.png', 3.4, 3.0, 0x3eb8ff, 0.22);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'world_aveh': {
          const g = this.createPropBillboard('landmark_aveh.png', 3.2, 3.1);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'stone_arch': {
          const g = new THREE.Group();
          const stone = new THREE.MeshStandardMaterial({
            map: PixelTextureFactory.getTexture('wall_stone'),
            color: 0xffffff,
            roughness: 0.88,
          });
          const pilL = new THREE.Mesh(new THREE.BoxGeometry(0.65, 2.8, 0.65), stone);
          pilL.position.set(-1.35, 1.4, 0);
          const pilR = new THREE.Mesh(new THREE.BoxGeometry(0.65, 2.8, 0.65), stone);
          pilR.position.set(1.35, 1.4, 0);
          const arch = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.6, 0.75), stone);
          arch.position.set(0, 2.9, 0);
          g.add(pilL, pilR, arch);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'well': {
          const g = new THREE.Group();
          const stone = new THREE.MeshStandardMaterial({
            map: PixelTextureFactory.getTexture('wall_stone'),
            color: 0xffffff,
            roughness: 0.88,
          });
          const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.64, 0.72, 10), stone);
          ring.position.y = 0.36;
          const water = new THREE.Mesh(
            new THREE.CircleGeometry(0.48, 10),
            new THREE.MeshStandardMaterial({ color: 0x35749c, roughness: 0.2 })
          );
          water.rotation.x = -Math.PI / 2;
          water.position.y = 0.62;
          const roof = new THREE.Mesh(
            new THREE.ConeGeometry(0.76, 0.55, 4),
            new THREE.MeshStandardMaterial({ map: PixelTextureFactory.getTexture('roof_clay'), roughness: 0.8 })
          );
          roof.rotation.y = Math.PI / 4;
          roof.position.y = 1.65;
          const postL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.0, 0.1), new THREE.MeshStandardMaterial({ color: 0x5c3e26 }));
          postL.position.set(-0.46, 1.1, 0);
          const postR = postL.clone();
          postR.position.x = 0.46;
          g.add(ring, water, roof, postL, postR);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'crate_stack': {
          const g = new THREE.Group();
          const crateTex = PixelTextureFactory.getPropTexture('crate_stack.png');
          const crateMat = new THREE.MeshStandardMaterial({
            map: crateTex,
            transparent: true,
            alphaTest: 0.5,
            side: THREE.DoubleSide,
            roughness: 0.85,
          });
          const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1.35, 1.45), crateMat);
          mesh.position.y = 0.72;
          mesh.castShadow = true;
          mesh.customDepthMaterial = new THREE.MeshDepthMaterial({
            depthPacking: THREE.RGBADepthPacking,
            map: crateTex,
            alphaTest: 0.5,
          });
          g.add(mesh);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }

        case 'banner': {
          const g = new THREE.Group();
          const pole = new THREE.Mesh(
            new THREE.CylinderGeometry(0.05, 0.05, 2.6, 6),
            new THREE.MeshStandardMaterial({ color: 0xc8a45c, metalness: 0.8, roughness: 0.25 })
          );
          pole.position.y = 1.3;
          const cloth = new THREE.Mesh(
            new THREE.BoxGeometry(0.65, 1.45, 0.05),
            new THREE.MeshStandardMaterial({ map: PixelTextureFactory.getTexture('rug_red'), roughness: 0.82 })
          );
          cloth.position.set(0, 1.65, 0.06);
          g.add(pole, cloth);
          g.position.set(p.x, y, p.z);
          this.mapGroup.add(g);
          break;
        }
      }
    }
  }

  private buildChests(map: MapDefinition) {
    const closedTex = PixelTextureFactory.getPropTexture('prop_chest_closed.png');
    const openTex = PixelTextureFactory.getPropTexture('prop_chest_open.png');

    for (const c of map.chests) {
      const y = getElevationAt(map, c.x, c.z);
      const group = new THREE.Group();
      const closedMat = new THREE.MeshStandardMaterial({
        map: closedTex,
        transparent: true,
        alphaTest: 0.45,
        side: THREE.DoubleSide,
        roughness: 0.75,
      });
      const openMat = new THREE.MeshStandardMaterial({
        map: openTex,
        transparent: true,
        alphaTest: 0.45,
        side: THREE.DoubleSide,
        roughness: 0.75,
      });

      const closedMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.95, 0.95), closedMat);
      closedMesh.position.y = 0.48;
      closedMesh.castShadow = true;

      const openMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.05, 1.05), openMat);
      openMesh.position.y = 0.52;
      openMesh.castShadow = true;

      const isOpen = this.openedChests.includes(c.id);
      closedMesh.visible = !isOpen;
      openMesh.visible = isOpen;

      group.add(closedMesh, openMesh);
      group.position.set(c.x, y, c.z);
      this.mapGroup.add(group);
      this.chests.set(c.id, { id: c.id, closedMesh, openMesh, opened: isOpen });
    }
  }

  private buildSavePoints(map: MapDefinition) {
    const pedMat = new THREE.MeshStandardMaterial({
      color: 0x3b4152,
      metalness: 0.6,
      roughness: 0.35,
    });
    const monoTex = PixelTextureFactory.getPropTexture('memory_cube_monolith.png');
    const monoMat = new THREE.MeshStandardMaterial({
      map: monoTex,
      transparent: true,
      alphaTest: 0.5,
      side: THREE.DoubleSide,
      emissive: 0xe6b655,
      emissiveIntensity: 0.32,
      roughness: 0.4,
    });

    for (const sp of map.savePoints) {
      const y = getElevationAt(map, sp.x, sp.z);
      const g = new THREE.Group();
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.58, 0.18, 8), pedMat);
      ped.position.y = 0.09;
      const monolith = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.85), monoMat);
      monolith.position.y = 1.08;
      monolith.castShadow = true;
      monolith.customDepthMaterial = new THREE.MeshDepthMaterial({
        depthPacking: THREE.RGBADepthPacking,
        map: monoTex,
        alphaTest: 0.5,
      });
      g.add(ped, monolith);
      g.position.set(sp.x, y, sp.z);
      this.mapGroup.add(g);
      this.memoryCubes.push(monolith);
    }
  }

  private buildSwitchesAndGates(map: MapDefinition) {
    if (!map.switches) return;
    for (const sw of map.switches) {
      const unlocked = Boolean(this.questFlags[sw.flagId]);
      const y = getElevationAt(map, sw.x, sw.z);
      const padMat = new THREE.MeshStandardMaterial({
        color: 0x70d6ff,
        emissive: unlocked ? 0x3ae096 : 0x4dbbff,
        emissiveIntensity: 1.4,
        roughness: 0.3,
      });
      const pad = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.14, 0.84), padMat);
      pad.position.set(sw.x, y + 0.07, sw.z);
      this.mapGroup.add(pad);
      this.switchPads.set(sw.id, pad);

      // Ancient bulkhead laser/stone gate blocking corridor until switch activated
      const gateMat = new THREE.MeshStandardMaterial({
        color: 0x456080,
        emissive: 0x2b7cb5,
        emissiveIntensity: 0.7,
        metalness: 0.7,
        roughness: 0.3,
      });
      for (const gt of sw.gateTiles) {
        const gy = getElevationAt(map, gt.x, gt.z);
        const gate = new THREE.Mesh(new THREE.BoxGeometry(1.0, 2.3, 0.45), gateMat);
        gate.position.set(gt.x, gy + 1.15, gt.z);
        gate.userData.switchFlag = sw.flagId;
        gate.visible = !unlocked;
        this.mapGroup.add(gate);
        this.gateMeshes.push(gate);
      }
    }
  }

  private buildNpcs(map: MapDefinition) {
    for (const npc of map.npcs) {
      const anim = new ChibiSpriteAnimator(npc.spriteId, 'overworld', CHIBI_HEIGHT);
      const y = getElevationAt(map, npc.x, npc.z);
      anim.group.position.set(npc.x, y, npc.z);
      anim.updateOverworld(npc.facing, false, 0);
      if (npc.questFlagCondition) {
        const cur = Boolean(this.questFlags[npc.questFlagCondition.flag]);
        anim.group.visible = cur === npc.questFlagCondition.expected;
      }
      this.dynamicGroup.add(anim.group);
      this.npcs.push({
        id: npc.id,
        def: npc,
        animator: anim,
        x: npc.x,
        z: npc.z,
        facing: npc.facing,
        waypointIdx: 0,
        pauseTimer: 1.2 + Math.random() * 1.5,
      });
    }
  }

  private buildPartyTrain(map: MapDefinition) {
    // World Map shows leader only (classic JRPG overworld scale); Town/Interior/Dungeon show 4-member Octopath train!
    const members =
      map.id === 'worldmap_ignas' ? this.activeParty.slice(0, 1) : this.activeParty;
    const height = map.id === 'worldmap_ignas' ? 0.98 : CHIBI_HEIGHT;
    for (let i = 0; i < members.length; i++) {
      const anim = new ChibiSpriteAnimator(members[i].spriteId, 'overworld', height);
      const sample = i === 0 ? null : sampleBreadcrumb(this.trail, i, 0.85);
      const sx = sample ? sample.x : this.playerX;
      const sz = sample ? sample.z : this.playerZ;
      const y = getElevationAt(map, sx, sz);
      anim.group.position.set(sx, y, sz);
      anim.updateOverworld(this.playerFacing, false, 0);
      this.dynamicGroup.add(anim.group);
      this.partyAnimators.push(anim);
    }
  }

  private buildDustMotes(map: MapDefinition) {
    const count = this.quality === 'low' ? 35 : this.quality === 'medium' ? 75 : 130;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = Math.random() * map.width;
      positions[i * 3 + 1] = 0.6 + Math.random() * 4.5;
      positions[i * 3 + 2] = Math.random() * map.depth;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: map.id === 'dungeon_zeboim_ruins' ? 0x8be2ff : 0xffe6b3,
      size: 0.11,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    });
    this.dustPoints = new THREE.Points(geo, mat);
    this.mapGroup.add(this.dustPoints);
  }

  public start() {
    if (this.running) return;
    this.running = true;
    this.lastTime = performance.now();
    this.scheduleNextTick();
  }

  public stop() {
    this.running = false;
    window.cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (!this.running) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private scheduleNextTick() {
    if (!this.running) return;
    if (this.isSoftwareGl) {
      this.afterDraw(() => this.tick());
    } else {
      this.frameId = window.requestAnimationFrame(() => this.tick());
    }
  }

  private tick() {
    if (!this.running) return;
    const now = performance.now();
    const dt = Math.min(0.05, Math.max(0.001, (now - this.lastTime) / 1000));
    this.lastTime = now;

    if (this.hiddenPaused) return;
    if (this.currentMap) {
      this.updateSimulation(dt, now * 0.001);
      if (this.composer) {
        this.composer.render();
      } else {
        this.renderer.render(this.scene, this.camera);
      }
    }

    this.scheduleNextTick();
  }

  private updateSimulation(dt: number, elapsedSec: number) {
    const map = this.currentMap!;

    // Flicker warm lanterns & ether conduits gently
    for (const fl of this.flickerLights) {
      fl.light.intensity = fl.baseIntensity + Math.sin(elapsedSec * 5.2 + fl.phase) * 0.25;
    }

    // Gently hover golden Zohar Memory Cube monoliths (keep camera-facing billboard orientation)
    for (const cube of this.memoryCubes) {
      cube.position.y = 1.08 + Math.sin(elapsedSec * 2.4) * 0.08;
    }

    // Drift dust motes
    if (this.dustPoints) {
      this.dustPoints.position.y = Math.sin(elapsedSec * 0.6) * 0.18;
      this.dustPoints.position.x = Math.cos(elapsedSec * 0.35) * 0.22;
    }

    // Animate water shimmer UV gently
    if (this.waterMeshes.length > 0) {
      const mat = this.waterMeshes[0].material as THREE.MeshStandardMaterial;
      if (mat.map) {
        mat.map.offset.x = (elapsedSec * 0.08) % 1;
      }
    }

    // Update Living NPCs
    this.updateNpcs(map, dt);

    if (this.mode === 'title_tour') {
      this.tourAngle += dt * 0.14;
      const cx = map.width * 0.5;
      const cz = map.depth * 0.46;
      this.camera.position.set(
        cx + Math.sin(this.tourAngle) * 7.2,
        7.4 + Math.sin(this.tourAngle * 0.7) * 0.5,
        cz + 17.5 + Math.cos(this.tourAngle) * 2.2
      );
      this.camera.lookAt(cx, 2.6, cz - 3.6);
      return;
    }

    if (this.mode === 'gameplay') {
      this.updatePlayerMovement(map, dt);
    }

    // Smooth Octopath Fixed-Tilt Follow Camera (angle ~28° downward, subtle left/right parallax, NO disorienting indoor spin)
    const damp = 1 - Math.exp(-7.5 * dt);
    const targetParallax = this.input.moveX * 0.65;
    this.parallaxX += (targetParallax - this.parallaxX) * (1 - Math.exp(-4.0 * dt));

    const elev = getElevationAt(map, this.playerX, this.playerZ);
    const camHeight = map.isOutdoor ? 8.2 : 7.2;
    const camDistZ = map.isOutdoor ? 12.2 : 10.6;
    _camDesired.set(
      this.playerX + this.parallaxX + this.cameraPanOffset.x,
      elev + camHeight,
      this.playerZ + camDistZ + this.cameraPanOffset.z
    );
    this.camera.position.lerp(_camDesired, damp);
    _camTarget.set(
      this.playerX + this.parallaxX * 0.35 + this.cameraPanOffset.x,
      elev + 0.75,
      this.playerZ - 0.6 + this.cameraPanOffset.z
    );
    _lookVec.copy(_camTarget);
    this.camera.lookAt(_lookVec);
  }

  private updateNpcs(map: MapDefinition, dt: number) {
    const dirs: Direction[] = ['S', 'W', 'E', 'N'];
    for (const npc of this.npcs) {
      if (!npc.animator.group.visible) continue;

      if (npc.def.behavior === 'LOOK_AROUND') {
        npc.pauseTimer -= dt;
        if (npc.pauseTimer <= 0) {
          npc.pauseTimer = 2.4 + Math.random() * 2.5;
          npc.facing = dirs[Math.floor(Math.random() * dirs.length)];
          npc.animator.updateOverworld(npc.facing, false, dt);
        }
        continue;
      }

      if (npc.def.behavior === 'PATROL_WAYPOINTS' && npc.def.waypoints && npc.def.waypoints.length > 1) {
        if (npc.pauseTimer > 0) {
          npc.pauseTimer -= dt;
          npc.animator.updateOverworld(npc.facing, false, dt);
          continue;
        }
        const target = npc.def.waypoints[npc.waypointIdx];
        const dx = target.x - npc.x;
        const dz = target.z - npc.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 0.08) {
          npc.waypointIdx = (npc.waypointIdx + 1) % npc.def.waypoints.length;
          npc.pauseTimer = 1.6 + Math.random() * 1.4;
          npc.animator.updateOverworld(npc.facing, false, dt);
        } else {
          const speed = 1.55;
          const step = Math.min(dist, speed * dt);
          const nx = npc.x + (dx / dist) * step;
          const nz = npc.z + (dz / dist) * step;
          // Pause gracefully if player is blocking path
          if (Math.hypot(nx - this.playerX, nz - this.playerZ) > 0.75) {
            npc.x = nx;
            npc.z = nz;
            npc.facing = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? 'E' : 'W') : dz > 0 ? 'S' : 'N';
            const ny = getElevationAt(map, npc.x, npc.z);
            npc.animator.group.position.set(npc.x, ny, npc.z);
            npc.animator.updateOverworld(npc.facing, true, dt);
          } else {
            npc.animator.updateOverworld(npc.facing, false, dt);
          }
        }
      }
    }
  }

  private updatePlayerMovement(map: MapDefinition, dt: number) {
    if (this.warpCooldown > 0) this.warpCooldown = Math.max(0, this.warpCooldown - dt);

    const mx = this.input.moveX;
    const mz = this.input.moveZ;
    const mag = Math.hypot(mx, mz);
    let movedDist = 0;

    if (mag > 0.08) {
      const nx = mx / Math.max(1, mag);
      const nz = mz / Math.max(1, mag);
      const baseSpeed = map.id === 'worldmap_ignas' ? 4.4 : 4.2;
      const speed = this.input.sprint ? baseSpeed * 1.48 : baseSpeed;

      // Update facing direction
      if (Math.abs(nx) > Math.abs(nz)) {
        this.playerFacing = nx > 0 ? 'E' : 'W';
      } else {
        this.playerFacing = nz > 0 ? 'S' : 'N';
      }

      const tryX = this.playerX + nx * speed * dt;
      const tryZ = this.playerZ + nz * speed * dt;

      let nextX = this.playerX;
      let nextZ = this.playerZ;
      if (canStepTo(map, this.playerX, this.playerZ, tryX, this.playerZ, this.questFlags)) {
        nextX = tryX;
      }
      if (canStepTo(map, nextX, this.playerZ, nextX, tryZ, this.questFlags)) {
        nextZ = tryZ;
      }

      movedDist = Math.hypot(nextX - this.playerX, nextZ - this.playerZ);
      this.playerX = nextX;
      this.playerZ = nextZ;

      if (movedDist > 0.001) {
        this.trail = pushBreadcrumb(this.trail, this.playerX, this.playerZ, this.playerFacing);
      }
    }

    // Position Leader & Follow-the-Leader Party Train
    const isMoving = movedDist > 0.002;
    const leaderY = getElevationAt(map, this.playerX, this.playerZ);
    if (this.partyAnimators[0]) {
      this.partyAnimators[0].group.position.set(this.playerX, leaderY, this.playerZ);
      this.partyAnimators[0].updateOverworld(this.playerFacing, isMoving, dt, this.input.sprint);
    }
    for (let i = 1; i < this.partyAnimators.length; i++) {
      const sample = sampleBreadcrumb(this.trail, i, 0.85);
      if (sample) {
        const fy = getElevationAt(map, sample.x, sample.z);
        this.partyAnimators[i].group.position.set(sample.x, fy, sample.z);
        this.partyAnimators[i].updateOverworld(
          isMoving ? sample.facing : this.playerFacing,
          isMoving,
          dt,
          this.input.sprint
        );
      }
    }

    // Throttle position callback to React (<= 4Hz)
    this.posReportAccum += dt;
    if (this.posReportAccum >= 0.25) {
      this.posReportAccum = 0;
      this.callbacks.onPositionSample(this.playerX, this.playerZ, this.playerFacing);
    }

    // Check Warp Zones
    if (this.warpCooldown <= 0) {
      const warp = findTriggeredWarp(map, this.playerX, this.playerZ);
      if (warp) {
        this.warpCooldown = 1.0;
        this.callbacks.onWarp(warp.targetMap, warp.targetX, warp.targetZ, warp.targetFacing);
        return;
      }
    }

    // Check Step-Counter Random Encounters (World Map & Dungeon only)
    if (movedDist > 0) {
      this.stepAccum += movedDist;
      const enc = checkEncounterStep(
        map,
        this.playerX,
        this.playerZ,
        this.stepAccum,
        this.stepThreshold
      );
      if (enc.triggered) {
        this.stepAccum = 0;
        this.stepThreshold = enc.nextThreshold;
        this.callbacks.onEncounter(enc.enemyIds, enc.arenaTheme);
        return;
      }
    }

    // Update Nearest Interactable + Floating Pixel Speech Bubble
    const npcPosMap: Record<string, { x: number; z: number }> = {};
    for (const n of this.npcs) {
      npcPosMap[n.id] = { x: n.x, z: n.z };
    }
    const prompt = findNearestInteractable(
      map,
      this.playerX,
      this.playerZ,
      this.playerFacing,
      this.openedChests,
      this.questFlags,
      npcPosMap
    );

    if (prompt) {
      const py = getElevationAt(map, prompt.x, prompt.z);
      this.speechBubbleMesh.visible = true;
      this.speechBubbleMesh.position.set(
        prompt.x,
        py + 1.55 + Math.sin(performance.now() * 0.006) * 0.08,
        prompt.z
      );
    } else {
      this.speechBubbleMesh.visible = false;
    }

    const promptKey = prompt ? `${prompt.type}:${prompt.id}` : '';
    if (promptKey !== this.lastPromptKey) {
      this.lastPromptKey = promptKey;
      this.callbacks.onPromptChange(prompt);
    }
  }

  private disposeMapScene() {
    this.flickerLights = [];
    this.waterMeshes = [];
    this.memoryCubes = [];
    this.gateMeshes = [];
    this.switchPads.clear();
    this.chests.clear();

    this.npcs.forEach((n) => n.animator.dispose());
    this.npcs = [];
    this.partyAnimators.forEach((p) => p.dispose());
    this.partyAnimators = [];

    if (this.dustPoints) {
      this.dustPoints.geometry.dispose();
      (this.dustPoints.material as THREE.Material).dispose();
      this.dustPoints = null;
    }

    const disposeMat = (mat: THREE.Material) => {
      const std = mat as THREE.MeshStandardMaterial;
      if (std.map) PixelTextureFactory.releaseClone(std.map);
      if (std.bumpMap) PixelTextureFactory.releaseClone(std.bumpMap);
      mat.dispose();
    };
    const clearGroup = (g: THREE.Group) => {
      g.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const m = obj as THREE.Mesh;
          m.geometry.dispose();
          if (Array.isArray(m.material)) {
            m.material.forEach(disposeMat);
          } else {
            disposeMat(m.material);
          }
          if (m.customDepthMaterial) {
            m.customDepthMaterial.dispose();
          }
        }
      });
      while (g.children.length > 0) {
        g.remove(g.children[0]);
      }
    };
    clearGroup(this.mapGroup);
    clearGroup(this.dynamicGroup);
  }

  public dispose() {
    this.stop();
    document.removeEventListener('visibilitychange', this.onVisibilityChange);
    this.resizeObserver?.disconnect();
    this.disposeMapScene();
    this.speechBubbleMesh.material.map?.dispose();
    this.speechBubbleMesh.material.dispose();
    this.composer?.dispose();
    if (this.scene.environment) {
      this.scene.environment.dispose();
    }
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
