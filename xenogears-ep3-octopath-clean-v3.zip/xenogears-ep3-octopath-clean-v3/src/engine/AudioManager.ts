import { AudioConfig, OSTTrackId } from '../types/rpg';

export interface OSTSlotInfo {
  id: OSTTrackId;
  filename: string;
  altFilename: string;
  label: string;
  status: 'loaded' | 'custom_file' | 'slot_empty';
  resolvedUrl: string | null;
}

export const OST_TRACK_LIST: Array<{ id: OSTTrackId; filename: string; altFilename: string; label: string }> = [
  { id: 'title', filename: 'title.mp3', altFilename: 'title.ogg', label: 'Title Theme' },
  { id: 'worldmap', filename: 'worldmap.mp3', altFilename: 'worldmap.ogg', label: 'Ignas World Map' },
  { id: 'town_nisan', filename: 'town_nisan.mp3', altFilename: 'town_nisan.ogg', label: 'Town of Nisan' },
  { id: 'interior_peaceful', filename: 'interior_peaceful.mp3', altFilename: 'interior_peaceful.ogg', label: 'Sanctuary & Interiors' },
  { id: 'dungeon_zeboim', filename: 'dungeon_zeboim.mp3', altFilename: 'dungeon_zeboim.ogg', label: 'Zeboim Ruins' },
  { id: 'battle_normal', filename: 'battle_normal.mp3', altFilename: 'battle_normal.ogg', label: 'Battle Theme' },
  { id: 'battle_boss', filename: 'battle_boss.mp3', altFilename: 'battle_boss.ogg', label: 'Boss Battle' },
  { id: 'cutscene_tragic', filename: 'cutscene_tragic.mp3', altFilename: 'cutscene_tragic.ogg', label: 'Story Cutscene' },
];

export type UISfxName =
  | 'cursor'
  | 'confirm'
  | 'cancel'
  | 'door'
  | 'chest'
  | 'save'
  | 'switch'
  | 'rest'
  | 'attack'
  | 'break'
  | 'ether'
  | 'hurt'
  | 'victory'
  | 'voice';

const CROSSFADE_SECONDS = 1.2;

class AudioManagerImpl {
  private ctx: AudioContext | null = null;
  private config: AudioConfig = { bgmVolume: 0.75, sfxVolume: 0.8, muted: false };
  private backgroundMuted = false;
  private manifestChecked = false;
  private availableFiles = new Set<string>();
  private customObjectUrls = new Map<OSTTrackId, string>();
  private activeTrackId: OSTTrackId | null = null;
  private activeAudio: HTMLAudioElement | null = null;
  private activeGain: GainNode | null = null;
  private fadingAudio: HTMLAudioElement | null = null;
  private fadeTimer: number | null = null;
  private listeners = new Set<() => void>();

  constructor() {
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', () => {
        this.setBackgroundPaused(document.visibilityState === 'hidden');
      });
    }
  }

  public subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit() {
    this.listeners.forEach((fn) => fn());
  }

  public async initManifest(): Promise<void> {
    if (this.manifestChecked || typeof fetch === 'undefined') return;
    this.manifestChecked = true;
    try {
      const res = await fetch('/audio/ost/manifest.json', { cache: 'no-store' });
      if (res.ok) {
        const json = (await res.json()) as { available?: string[] };
        if (Array.isArray(json.available)) {
          json.available.forEach((f) => this.availableFiles.add(f.toLowerCase()));
        }
      }
    } catch {
      // Fail silently with zero console errors
    }
    this.emit();
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (Ctx) {
        try {
          this.ctx = new Ctx();
        } catch {
          return null;
        }
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setConfig(next: AudioConfig) {
    this.config = { ...next };
    this.applyVolumeToActive();
    this.emit();
  }

  public getConfig(): AudioConfig {
    return { ...this.config };
  }

  public setBackgroundPaused(paused: boolean) {
    this.backgroundMuted = paused;
    if (this.activeAudio) {
      if (paused) {
        this.activeAudio.pause();
      } else if (!this.config.muted) {
        this.activeAudio.play().catch(() => {});
      }
    }
    this.applyVolumeToActive();
  }

  public getActiveTrackId(): OSTTrackId | null {
    return this.activeTrackId;
  }

  public getActiveSlotLabel(): string {
    if (!this.activeTrackId) return 'None';
    const spec = OST_TRACK_LIST.find((t) => t.id === this.activeTrackId);
    return spec ? spec.filename : this.activeTrackId;
  }

  public getSlotStatuses(): OSTSlotInfo[] {
    return OST_TRACK_LIST.map((t) => {
      const customUrl = this.customObjectUrls.get(t.id);
      if (customUrl) {
        return {
          ...t,
          status: 'custom_file',
          resolvedUrl: customUrl,
        };
      }
      if (this.availableFiles.has(t.filename.toLowerCase())) {
        return {
          ...t,
          status: 'loaded',
          resolvedUrl: `/audio/ost/${t.filename}`,
        };
      }
      if (this.availableFiles.has(t.altFilename.toLowerCase())) {
        return {
          ...t,
          status: 'loaded',
          resolvedUrl: `/audio/ost/${t.altFilename}`,
        };
      }
      return {
        ...t,
        status: 'slot_empty',
        resolvedUrl: null,
      };
    });
  }

  public registerCustomTrackFile(trackId: OSTTrackId, file: File): void {
    const prev = this.customObjectUrls.get(trackId);
    if (prev) URL.revokeObjectURL(prev);
    const url = URL.createObjectURL(file);
    this.customObjectUrls.set(trackId, url);
    this.emit();
    if (this.activeTrackId === trackId) {
      this.activeTrackId = null;
      void this.playTrack(trackId);
    }
  }

  private getEffectiveBgmVolume(): number {
    if (this.config.muted || this.backgroundMuted) return 0;
    return Math.min(1, Math.max(0, this.config.bgmVolume));
  }

  private applyVolumeToActive() {
    const vol = this.getEffectiveBgmVolume();
    if (this.activeGain && this.ctx) {
      this.activeGain.gain.setTargetAtTime(vol, this.ctx.currentTime, 0.08);
    } else if (this.activeAudio) {
      this.activeAudio.volume = vol;
    }
  }

  public async playTrack(trackId: OSTTrackId): Promise<void> {
    if (!this.manifestChecked) {
      await this.initManifest();
    }
    if (this.activeTrackId === trackId) return;
    this.activeTrackId = trackId;
    this.emit();

    const slot = this.getSlotStatuses().find((s) => s.id === trackId);
    const url = slot?.resolvedUrl ?? null;

    // Crossfade out previous track cleanly over 1.2s
    const oldAudio = this.activeAudio;
    const oldGain = this.activeGain;
    this.activeAudio = null;
    this.activeGain = null;

    if (this.fadeTimer !== null) {
      window.clearTimeout(this.fadeTimer);
      this.fadeTimer = null;
    }
    if (this.fadingAudio) {
      this.fadingAudio.pause();
      this.fadingAudio = null;
    }

    if (oldAudio) {
      this.fadingAudio = oldAudio;
      if (oldGain && this.ctx) {
        const now = this.ctx.currentTime;
        oldGain.gain.cancelScheduledValues(now);
        oldGain.gain.setValueAtTime(oldGain.gain.value, now);
        oldGain.gain.linearRampToValueAtTime(0, now + CROSSFADE_SECONDS);
      } else {
        oldAudio.volume = 0;
      }
      this.fadeTimer = window.setTimeout(() => {
        if (this.fadingAudio === oldAudio) {
          oldAudio.pause();
          this.fadingAudio = null;
        }
      }, CROSSFADE_SECONDS * 1000 + 80);
    }

    // If user hasn't dropped in an OST file yet, fail silently with ZERO console errors
    if (!url || typeof Audio === 'undefined') {
      return;
    }

    try {
      const nextAudio = new Audio(url);
      nextAudio.loop = true;
      nextAudio.crossOrigin = 'anonymous';
      const ctx = this.ensureContext();
      if (ctx) {
        const source = ctx.createMediaElementSource(nextAudio);
        const gain = ctx.createGain();
        const now = ctx.currentTime;
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.linearRampToValueAtTime(
          Math.max(0.0001, this.getEffectiveBgmVolume()),
          now + CROSSFADE_SECONDS
        );
        source.connect(gain);
        gain.connect(ctx.destination);
        this.activeGain = gain;
      } else {
        nextAudio.volume = this.getEffectiveBgmVolume();
      }
      this.activeAudio = nextAudio;
      if (!this.backgroundMuted) {
        nextAudio.play().catch(() => {
          // Autoplay blocked until first user interaction; ignore silently
        });
      }
    } catch {
      // Fail silently
    }
  }

  public playSfx(name: UISfxName, pitchScale = 1): void {
    if (this.config.muted || this.backgroundMuted || this.config.sfxVolume <= 0.01) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const gainMaster = Math.min(0.32, this.config.sfxVolume * 0.25);

    const playTone = (
      freq: number,
      endFreq: number,
      dur: number,
      type: OscillatorType,
      offset = 0,
      volScale = 1
    ) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq * pitchScale, now + offset);
      if (endFreq !== freq) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq * pitchScale), now + offset + dur);
      }
      gain.gain.setValueAtTime(0.0001, now + offset);
      gain.gain.linearRampToValueAtTime(gainMaster * volScale, now + offset + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + offset);
      osc.stop(now + offset + dur + 0.02);
    };

    switch (name) {
      case 'cursor':
        playTone(680, 760, 0.055, 'triangle', 0, 0.55);
        break;
      case 'confirm':
        playTone(587.33, 587.33, 0.08, 'triangle', 0, 0.75);
        playTone(880, 880, 0.14, 'sine', 0.05, 0.65);
        break;
      case 'cancel':
        playTone(440, 290, 0.11, 'triangle', 0, 0.65);
        break;
      case 'door':
        playTone(210, 120, 0.16, 'sine', 0, 0.7);
        playTone(320, 480, 0.14, 'triangle', 0.06, 0.35);
        break;
      case 'chest':
        playTone(523.25, 523.25, 0.11, 'triangle', 0, 0.75);
        playTone(659.25, 659.25, 0.11, 'triangle', 0.09, 0.75);
        playTone(783.99, 783.99, 0.14, 'triangle', 0.18, 0.8);
        playTone(1046.5, 1046.5, 0.28, 'sine', 0.27, 0.85);
        break;
      case 'save':
        playTone(440, 440, 0.18, 'sine', 0, 0.6);
        playTone(659.25, 659.25, 0.22, 'sine', 0.1, 0.6);
        playTone(880, 880, 0.36, 'triangle', 0.2, 0.7);
        break;
      case 'switch':
        playTone(180, 340, 0.15, 'square', 0, 0.35);
        playTone(520, 660, 0.2, 'triangle', 0.12, 0.55);
        break;
      case 'rest':
        playTone(392, 392, 0.18, 'sine', 0, 0.6);
        playTone(493.88, 493.88, 0.18, 'sine', 0.16, 0.6);
        playTone(587.33, 587.33, 0.24, 'sine', 0.32, 0.65);
        playTone(783.99, 783.99, 0.42, 'sine', 0.48, 0.7);
        break;
      case 'attack':
        playTone(260, 95, 0.11, 'sawtooth', 0, 0.55);
        break;
      case 'break':
        playTone(720, 140, 0.24, 'sawtooth', 0, 0.85);
        playTone(1240, 480, 0.26, 'triangle', 0.04, 0.7);
        break;
      case 'ether':
        playTone(520, 980, 0.22, 'sine', 0, 0.6);
        playTone(780, 1320, 0.26, 'triangle', 0.08, 0.45);
        break;
      case 'hurt':
        playTone(170, 75, 0.14, 'sawtooth', 0, 0.65);
        break;
      case 'victory':
        playTone(523.25, 523.25, 0.12, 'triangle', 0, 0.7);
        playTone(659.25, 659.25, 0.12, 'triangle', 0.11, 0.7);
        playTone(783.99, 783.99, 0.15, 'triangle', 0.22, 0.75);
        playTone(1046.5, 1046.5, 0.42, 'sine', 0.34, 0.85);
        break;
      case 'voice':
        playTone(420, 460, 0.035, 'triangle', 0, 0.26);
        break;
    }
  }
}

export const AudioManager = new AudioManagerImpl();
