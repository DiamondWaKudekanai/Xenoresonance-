import { CutsceneScript, CutsceneStep, DialogueLine, Direction, MapId } from '../types/rpg';
import { AudioManager } from './AudioManager';

export interface EventDirectorCallbacks {
  onShowDialogue: (lines: DialogueLine[], onDone: () => void) => void;
  onEmote: (actorId: string, emote: '!' | '?' | '...') => void;
  onFaceActor: (actorId: string, facing: Direction) => void;
  onMoveActor: (actorId: string, path: Array<{ x: number; z: number }>) => Promise<void>;
  onCameraPan: (dx: number, dz: number, durationMs: number) => Promise<void>;
  onFade: (direction: 'out' | 'in', durationMs: number) => Promise<void>;
  onFlash: (color: string, durationMs: number) => Promise<void>;
  onSetFlag: (flag: string, value: boolean) => void;
  onJoinParty: (memberId: 'lacan' | 'sophia' | 'krelian' | 'roni') => void;
  onStartBattle: (step: Extract<CutsceneStep, { type: 'start_battle' }>) => void;
  onWarp: (mapId: MapId, x: number, z: number, facing: Direction) => void;
  onComplete: () => void;
}

export class EventDirector {
  private cancelled = false;

  public cancel() {
    this.cancelled = true;
  }

  public async runScript(
    script: CutsceneScript,
    cb: EventDirectorCallbacks
  ): Promise<void> {
    this.cancelled = false;
    if (script.ostTrack) {
      void AudioManager.playTrack(script.ostTrack);
    }

    for (const step of script.steps) {
      if (this.cancelled) return;

      switch (step.type) {
        case 'dialogue':
          await new Promise<void>((resolve) => {
            cb.onShowDialogue(step.lines, resolve);
          });
          break;
        case 'emote':
          cb.onEmote(step.actorId, step.emote);
          await this.sleep(360);
          break;
        case 'face':
          cb.onFaceActor(step.actorId, step.facing);
          break;
        case 'move':
          await cb.onMoveActor(step.actorId, step.path);
          break;
        case 'camera_pan':
          await cb.onCameraPan(step.dx, step.dz, step.durationMs);
          break;
        case 'fade':
          await cb.onFade(step.direction, step.durationMs);
          break;
        case 'flash':
          await cb.onFlash(step.color, step.durationMs);
          break;
        case 'set_flag':
          cb.onSetFlag(step.flag, step.value);
          break;
        case 'join_party':
          cb.onJoinParty(step.memberId);
          break;
        case 'sfx':
          AudioManager.playSfx(step.sound as never);
          break;
        case 'warp':
          cb.onWarp(step.mapId, step.x, step.z, step.facing);
          break;
        case 'start_battle':
          cb.onStartBattle(step);
          return; // Battle takes over control
      }
    }

    if (!this.cancelled) {
      cb.onComplete();
    }
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }
}
