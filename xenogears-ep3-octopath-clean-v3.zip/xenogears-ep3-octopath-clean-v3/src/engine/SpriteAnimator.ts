import * as THREE from 'three';
import { SPRITE_MANIFEST } from '../data/spriteManifest';
import { Direction, SpriteId } from '../types/rpg';

interface ChibiPalette {
  hair: string;
  hairShade: string;
  skin: string;
  skinShade: string;
  tunic: string;
  tunicShade: string;
  accent: string;
  boots: string;
  hairStyle: 'ponytail' | 'long' | 'parted' | 'spiky' | 'hood' | 'helmet' | 'bob';
  isGear?: boolean;
  isHologram?: boolean;
  isMonster?: boolean;
}

const PALETTES: Record<SpriteId, ChibiPalette> = {
  lacan: {
    hair: '#5a3a26',
    hairShade: '#3b2416',
    skin: '#f2d3b5',
    skinShade: '#d9b18f',
    tunic: '#4a5d7a',
    tunicShade: '#334259',
    accent: '#c95346', // crimson painter scarf
    boots: '#3d2a1f',
    hairStyle: 'ponytail',
  },
  sophia: {
    hair: '#a6383e',
    hairShade: '#732127',
    skin: '#f7dec7',
    skinShade: '#dfc0a4',
    tunic: '#ece6d9',
    tunicShade: '#cfc6b5',
    accent: '#d4b06a', // Nisan gold trim
    boots: '#7c6548',
    hairStyle: 'long',
  },
  krelian: {
    hair: '#d5d0be',
    hairShade: '#9e9988',
    skin: '#f0d7c0',
    skinShade: '#d4b89e',
    tunic: '#2d3f68',
    tunicShade: '#1d2a47',
    accent: '#d8b66c', // Guard gold cape/epaulets
    boots: '#242936',
    hairStyle: 'parted',
  },
  roni: {
    hair: '#e0b34c',
    hairShade: '#a87d28',
    skin: '#ebc8a3',
    skinShade: '#cca37c',
    tunic: '#2f658f',
    tunicShade: '#1f4766',
    accent: '#e3be68', // Aveh gold sash
    boots: '#4a3321',
    hairStyle: 'spiky',
  },
  npc_monk: {
    hair: '#82786d',
    hairShade: '#575049',
    skin: '#eed0b4',
    skinShade: '#cfa988',
    tunic: '#dcd4c4',
    tunicShade: '#b5ab98',
    accent: '#b8944f',
    boots: '#4f4032',
    hairStyle: 'hood',
  },
  npc_villager: {
    hair: '#694a36',
    hairShade: '#473022',
    skin: '#efd1b4',
    skinShade: '#d4b08e',
    tunic: '#5c7a56',
    tunicShade: '#42593e',
    accent: '#c7a467',
    boots: '#4a3728',
    hairStyle: 'bob',
  },
  npc_merchant: {
    hair: '#4a3525',
    hairShade: '#2e2015',
    skin: '#ecc9a8',
    skinShade: '#cc9f7a',
    tunic: '#8a4638',
    tunicShade: '#612d23',
    accent: '#dfba65',
    boots: '#3d281c',
    hairStyle: 'parted',
  },
  npc_child: {
    hair: '#9c6838',
    hairShade: '#6e4522',
    skin: '#f4d8bc',
    skinShade: '#d9b898',
    tunic: '#528099',
    tunicShade: '#395d70',
    accent: '#e0c068',
    boots: '#4a3525',
    hairStyle: 'spiky',
  },
  npc_solaris: {
    hair: '#3e4756',
    hairShade: '#252b36',
    skin: '#ebd0b8',
    skinShade: '#c9a98e',
    tunic: '#4a3846',
    tunicShade: '#2e212b',
    accent: '#cf5353',
    boots: '#242029',
    hairStyle: 'helmet',
  },
  npc_hologram: {
    hair: '#9be7ff',
    hairShade: '#48a4cc',
    skin: '#c4f2ff',
    skinShade: '#76ccf0',
    tunic: '#42a7d4',
    tunicShade: '#226b8f',
    accent: '#d4f7ff',
    boots: '#297ca3',
    hairStyle: 'parted',
    isHologram: true,
  },
  gear_amon: {
    hair: '#c94338',
    hairShade: '#85241d',
    skin: '#e0d6c5',
    skinShade: '#9e9585',
    tunic: '#a63329',
    tunicShade: '#6b1d17',
    accent: '#e3be68',
    boots: '#363b47',
    hairStyle: 'helmet',
    isGear: true,
  },
  gear_elregrs: {
    hair: '#ebe5d8',
    hairShade: '#b3aa98',
    skin: '#d9d4c7',
    skinShade: '#999384',
    tunic: '#dad2c3',
    tunicShade: '#9e9484',
    accent: '#d8b062',
    boots: '#454a57',
    hairStyle: 'helmet',
    isGear: true,
  },
  gear_andvari: {
    hair: '#326da3',
    hairShade: '#1d466b',
    skin: '#d6dce6',
    skinShade: '#8d97a8',
    tunic: '#295b8a',
    tunicShade: '#1a3b5c',
    accent: '#e5bf5e',
    boots: '#2c3442',
    hairStyle: 'helmet',
    isGear: true,
  },
  gear_solaris: {
    hair: '#5a6378',
    hairShade: '#363c4a',
    skin: '#c4ccd9',
    skinShade: '#7f899c',
    tunic: '#475066',
    tunicShade: '#2b3140',
    accent: '#e05858',
    boots: '#232733',
    hairStyle: 'helmet',
    isGear: true,
  },
  enemy_trooper: {
    hair: '#3b4252',
    hairShade: '#232833',
    skin: '#d9c6b4',
    skinShade: '#b09a86',
    tunic: '#4c3e4d',
    tunicShade: '#2f2530',
    accent: '#de4e4e',
    boots: '#1f2229',
    hairStyle: 'helmet',
  },
  enemy_automaton: {
    hair: '#547a96',
    hairShade: '#334c5e',
    skin: '#88c9e8',
    skinShade: '#4a8aad',
    tunic: '#495a6e',
    tunicShade: '#2b3642',
    accent: '#63d8ff',
    boots: '#242d38',
    hairStyle: 'helmet',
    isGear: true,
  },
  enemy_sandworm: {
    hair: '#b88346',
    hairShade: '#805528',
    skin: '#d9aa6a',
    skinShade: '#9e723d',
    tunic: '#a6743d',
    tunicShade: '#6e4921',
    accent: '#e85b3f',
    boots: '#593b1d',
    hairStyle: 'hood',
    isMonster: true,
  },
  boss_diabolos: {
    hair: '#b82534',
    hairShade: '#6e101a',
    skin: '#f5d27a',
    skinShade: '#ad822b',
    tunic: '#302938',
    tunicShade: '#191421',
    accent: '#ff4f5e',
    boots: '#1b1724',
    hairStyle: 'helmet',
    isGear: true,
  },
};

function px(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string
) {
  ctx.fillStyle = color;
  ctx.fillRect(ox + x, oy + y, w, h);
}

/**
 * Draws a crisp 32x32 16-bit SNES/Octopath 2.5-head-tall chibi sprite cell.
 * Includes 1px dark outline, expressive 2px eyes, distinct hair silhouette, and swinging walk feet.
 */
function drawChibi32(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  pal: ChibiPalette,
  dirRow: number, // 0=S, 1=W, 2=E, 3=N
  frameCol: number, // 0=idle, 1=left-step, 2=idle, 3=right-step
  battlePose?: 'idle' | 'strike' | 'finisher' | 'ether' | 'guard' | 'hurt' | 'kneel' | 'victory' | 'ko'
) {
  const outline = pal.isHologram ? '#164d6b' : '#14131c';
  const stepLeft = frameCol === 1;
  const stepRight = frameCol === 3;
  const bob =
    battlePose === 'idle'
      ? frameCol % 2 === 1
        ? 1
        : 0
      : stepLeft || stepRight
        ? -1
        : 0;
  const kneelOffset = battlePose === 'kneel' ? 3 : 0;
  const hurtShift = battlePose === 'hurt' ? 2 : 0;
  const strikeShift = battlePose === 'strike' || battlePose === 'finisher' ? -3 : 0;

  const cx = ox + hurtShift + strikeShift;
  const cy = oy + bob + kneelOffset;

  if (battlePose === 'ko') {
    // Collapsed horizontal pose
    px(ctx, ox, oy, 5, 22, 22, 7, outline);
    px(ctx, ox, oy, 6, 23, 8, 5, pal.hair);
    px(ctx, ox, oy, 14, 23, 9, 5, pal.tunic);
    px(ctx, ox, oy, 23, 24, 3, 4, pal.boots);
    return;
  }

  // Ground subtle feet
  const leftFootY = stepLeft ? 26 : 27;
  const rightFootY = stepRight ? 26 : 27;
  const leftFootX = stepLeft ? 10 : 11;
  const rightFootX = stepRight ? 18 : 17;

  // Outline body & head silhouette
  px(ctx, cx, cy, 9, 4, 14, 13, outline); // head outline
  px(ctx, cx, cy, 10, 16, 12, 11, outline); // torso outline
  px(ctx, cx, cy, leftFootX - 1, leftFootY - 1, 5, 4, outline);
  px(ctx, cx, cy, rightFootX - 1, rightFootY - 1, 5, 4, outline);

  // Boots
  px(ctx, cx, cy, leftFootX, leftFootY, 3, 2, pal.boots);
  px(ctx, cx, cy, rightFootX, rightFootY, 3, 2, pal.boots);

  // Torso / Tunic
  px(ctx, cx, cy, 11, 17, 10, 9, pal.tunic);
  px(ctx, cx, cy, 11, 23, 10, 3, pal.tunicShade);
  // Accent scarf / sash / trim
  px(ctx, cx, cy, 11, 17, 10, 2, pal.accent);
  px(ctx, cx, cy, 15, 19, 2, 6, pal.accent);

  // Arms
  if (battlePose === 'victory') {
    px(ctx, cx, cy, 7, 11, 3, 7, outline);
    px(ctx, cx, cy, 8, 12, 2, 5, pal.tunic);
    px(ctx, cx, cy, 22, 11, 3, 7, outline);
    px(ctx, cx, cy, 22, 12, 2, 5, pal.tunic);
  } else if (battlePose === 'strike' || battlePose === 'finisher') {
    // Extended blade/strike arm to left
    px(ctx, cx, cy, 3, 16, 9, 3, '#e8edf5');
    px(ctx, cx, cy, 4, 17, 7, 1, battlePose === 'finisher' ? '#f5cb5c' : '#a8c2dc');
    px(ctx, cx, cy, 8, 17, 3, 5, pal.tunic);
    px(ctx, cx, cy, 21, 18, 3, 5, pal.tunicShade);
  } else if (battlePose === 'ether') {
    // Glowing ether halo above hands
    px(ctx, cx, cy, 6, 14, 4, 4, '#6de0ff');
    px(ctx, cx, cy, 7, 15, 2, 2, '#ffffff');
    px(ctx, cx, cy, 8, 18, 3, 4, pal.tunic);
    px(ctx, cx, cy, 21, 18, 3, 4, pal.tunic);
  } else if (battlePose === 'guard') {
    px(ctx, cx, cy, 7, 16, 4, 9, '#d4b06a');
    px(ctx, cx, cy, 8, 17, 2, 7, '#647696');
  } else {
    const swing = stepLeft ? -1 : stepRight ? 1 : 0;
    px(ctx, cx, cy, 8, 17 + swing, 3, 6, outline);
    px(ctx, cx, cy, 9, 18 + swing, 2, 4, pal.tunicShade);
    px(ctx, cx, cy, 21, 17 - swing, 3, 6, outline);
    px(ctx, cx, cy, 21, 18 - swing, 2, 4, pal.tunicShade);
  }

  // Head base
  px(ctx, cx, cy, 10, 5, 12, 11, pal.skin);
  px(ctx, cx, cy, 10, 14, 12, 2, pal.skinShade);

  // Hair & Directional Face
  if (dirRow === 3) {
    // Facing North (back of head)
    px(ctx, cx, cy, 10, 5, 12, 11, pal.hair);
    px(ctx, cx, cy, 10, 12, 12, 4, pal.hairShade);
    if (pal.hairStyle === 'long') {
      px(ctx, cx, cy, 10, 15, 12, 7, pal.hair);
      px(ctx, cx, cy, 11, 19, 10, 3, pal.hairShade);
    } else if (pal.hairStyle === 'ponytail') {
      px(ctx, cx, cy, 14, 14, 4, 6, pal.hairShade);
      px(ctx, cx, cy, 15, 15, 2, 4, pal.hair);
    }
  } else {
    // Top hair crown
    px(ctx, cx, cy, 10, 4, 12, 5, pal.hair);
    px(ctx, cx, cy, 10, 4, 12, 2, pal.hairShade);
    if (pal.hairStyle === 'spiky') {
      px(ctx, cx, cy, 9, 2, 3, 3, pal.hair);
      px(ctx, cx, cy, 14, 1, 4, 4, pal.hair);
      px(ctx, cx, cy, 20, 2, 3, 3, pal.hair);
    } else if (pal.hairStyle === 'long') {
      px(ctx, cx, cy, 9, 8, 2, 12, pal.hair);
      px(ctx, cx, cy, 21, 8, 2, 12, pal.hair);
    } else if (pal.hairStyle === 'ponytail') {
      px(ctx, cx, cy, 21, 8, 3, 8, pal.hairShade);
    } else if (pal.hairStyle === 'helmet') {
      px(ctx, cx, cy, 9, 4, 14, 6, pal.tunic);
      px(ctx, cx, cy, 11, 8, 10, 2, pal.accent);
    }

    // Expressive 2px eyes
    const eyeCol = pal.isHologram ? '#ffffff' : '#1b1d2b';
    if (dirRow === 0) {
      // South
      px(ctx, cx, cy, 12, 10, 2, 3, eyeCol);
      px(ctx, cx, cy, 18, 10, 2, 3, eyeCol);
      px(ctx, cx, cy, 12, 10, 1, 1, '#ffffff');
      px(ctx, cx, cy, 18, 10, 1, 1, '#ffffff');
    } else if (dirRow === 1) {
      // West
      px(ctx, cx, cy, 11, 10, 2, 3, eyeCol);
      px(ctx, cx, cy, 11, 10, 1, 1, '#ffffff');
      px(ctx, cx, cy, 17, 7, 5, 8, pal.hair);
    } else if (dirRow === 2) {
      // East
      px(ctx, cx, cy, 19, 10, 2, 3, eyeCol);
      px(ctx, cx, cy, 20, 10, 1, 1, '#ffffff');
      px(ctx, cx, cy, 10, 7, 5, 8, pal.hair);
    }
  }
}

/**
 * Draws a crisp 64x64 Gear or Boss mecha pixel-art cell with articulated silhouette.
 */
function drawGear64(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  pal: ChibiPalette,
  frameCol: number,
  battlePose?: string
) {
  const bob = frameCol % 2 === 1 ? 1 : 0;
  const shift = battlePose === 'strike' || battlePose === 'finisher' ? -5 : battlePose === 'hurt' ? 4 : 0;
  const cx = ox + shift;
  const cy = oy + bob;
  const outline = '#0f111a';

  if (battlePose === 'ko') {
    px(ctx, ox, oy, 10, 44, 44, 14, outline);
    px(ctx, ox, oy, 12, 46, 40, 10, pal.tunicShade);
    px(ctx, ox, oy, 26, 48, 12, 4, pal.accent);
    return;
  }

  // Wings / Thruster pack
  px(ctx, cx, cy, 8, 14, 14, 20, outline);
  px(ctx, cx, cy, 10, 16, 10, 16, pal.tunicShade);
  px(ctx, cx, cy, 42, 14, 14, 20, outline);
  px(ctx, cx, cy, 44, 16, 10, 16, pal.tunicShade);
  px(ctx, cx, cy, 12, 18, 6, 4, pal.accent);
  px(ctx, cx, cy, 46, 18, 6, 4, pal.accent);

  // Heavy Legs
  px(ctx, cx, cy, 17, 40, 12, 18, outline);
  px(ctx, cx, cy, 19, 41, 8, 15, pal.boots);
  px(ctx, cx, cy, 35, 40, 12, 18, outline);
  px(ctx, cx, cy, 37, 41, 8, 15, pal.boots);
  px(ctx, cx, cy, 20, 44, 6, 4, pal.tunic);
  px(ctx, cx, cy, 38, 44, 6, 4, pal.tunic);

  // Armored Torso & Cockpit Core
  px(ctx, cx, cy, 18, 18, 28, 24, outline);
  px(ctx, cx, cy, 20, 20, 24, 20, pal.tunic);
  px(ctx, cx, cy, 22, 22, 20, 6, pal.hair);
  // Glowing Ether Core
  px(ctx, cx, cy, 28, 26, 8, 8, pal.accent);
  px(ctx, cx, cy, 30, 28, 4, 4, '#fff4cf');

  // Shoulder Pauldrons
  px(ctx, cx, cy, 11, 18, 10, 12, outline);
  px(ctx, cx, cy, 13, 20, 6, 8, pal.hair);
  px(ctx, cx, cy, 43, 18, 10, 12, outline);
  px(ctx, cx, cy, 45, 20, 6, 8, pal.hair);

  // Mecha Head & Visor
  px(ctx, cx, cy, 24, 7, 16, 12, outline);
  px(ctx, cx, cy, 26, 9, 12, 9, pal.skin);
  px(ctx, cx, cy, 27, 12, 10, 3, pal.accent);
  // Crest antennae
  px(ctx, cx, cy, 22, 4, 3, 6, pal.accent);
  px(ctx, cx, cy, 39, 4, 3, 6, pal.accent);

  // Weapon burst on strike/finisher
  if (battlePose === 'strike' || battlePose === 'finisher') {
    px(ctx, cx, cy, 2, 25, 16, 6, '#ffe28a');
    px(ctx, cx, cy, 4, 27, 12, 2, '#ffffff');
  }
}

function drawMonster48(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  pal: ChibiPalette,
  frameCol: number,
  battlePose?: string
) {
  const bob = frameCol % 2 === 1 ? 2 : 0;
  const cx = ox;
  const cy = oy + bob;
  const outline = '#121018';
  if (battlePose === 'ko') {
    px(ctx, ox, oy, 8, 34, 32, 8, outline);
    px(ctx, ox, oy, 10, 36, 28, 4, pal.tunicShade);
    return;
  }
  // Segmented Ignas Dune Stalker carapace
  px(ctx, cx, cy, 10, 14, 28, 24, outline);
  px(ctx, cx, cy, 12, 16, 24, 20, pal.tunic);
  px(ctx, cx, cy, 14, 18, 20, 6, pal.hair);
  px(ctx, cx, cy, 14, 26, 20, 5, pal.tunicShade);
  // Glowing eyes / mandibles
  px(ctx, cx, cy, 16, 20, 4, 3, pal.accent);
  px(ctx, cx, cy, 28, 20, 4, 3, pal.accent);
  px(ctx, cx, cy, 14, 35, 5, 6, pal.skin);
  px(ctx, cx, cy, 29, 35, 5, 6, pal.skin);
}

const BUNDLED_SPRITE_FILES = [
  'boss_diabolos_battle.png',
  'enemy_automaton_battle.png',
  'enemy_sandworm_battle.png',
  'enemy_trooper_battle.png',
  'gear_amon_battle.png',
  'gear_andvari_battle.png',
  'gear_elregrs_battle.png',
  'gear_solaris_battle.png',
  'krelian_battle.png',
  'krelian_walk.png',
  'lacan_battle.png',
  'lacan_walk.png',
  'npc_child_walk.png',
  'npc_hologram_walk.png',
  'npc_merchant_walk.png',
  'npc_monk_walk.png',
  'npc_solaris_walk.png',
  'npc_villager_walk.png',
  'roni_battle.png',
  'roni_walk.png',
  'sophia_battle.png',
  'sophia_walk.png',
];

const HIGHRES_PORTRAITS: Partial<Record<SpriteId, string>> = {
  lacan: '/assets/portraits/lacan.png',
  sophia: '/assets/portraits/sophia.png',
  krelian: '/assets/portraits/krelian.png',
  roni: '/assets/portraits/roni.png',
  npc_solaris: '/assets/portraits/solaris_inquisitor.png',
  enemy_trooper: '/assets/portraits/solaris_inquisitor.png',
  boss_diabolos: '/assets/portraits/solaris_inquisitor.png',
};

class SpriteSheetRegistryImpl {
  private walkSheets = new Map<SpriteId, THREE.Texture>();
  private battleSheets = new Map<SpriteId, THREE.Texture>();
  private liveClones = new Map<THREE.Texture, Set<THREE.Texture>>();
  private portraitUrls = new Map<SpriteId, string>();
  private availableFiles = new Set<string>(BUNDLED_SPRITE_FILES);
  private customFiles = new Map<string, string>();
  private manifestLoaded = false;

  public async initManifest(): Promise<void> {
    if (this.manifestLoaded || typeof fetch === 'undefined') return;
    this.manifestLoaded = true;
    try {
      const res = await fetch('/assets/sprites/manifest.json', { cache: 'no-store' });
      if (res.ok) {
        const data = (await res.json()) as { available?: string[] };
        if (Array.isArray(data.available)) {
          data.available.forEach((f) => this.availableFiles.add(f.toLowerCase()));
        }
      }
    } catch {
      // Fail silently
    }
  }

  public getOverrideStatus(filename: string): 'custom_png' | 'procedural_fallback' {
    const lower = filename.toLowerCase();
    if (this.customFiles.has(lower) || this.availableFiles.has(lower)) {
      return 'custom_png';
    }
    return 'procedural_fallback';
  }

  public registerCustomSprite(filename: string, file: File): void {
    const lower = filename.toLowerCase();
    const prev = this.customFiles.get(lower);
    if (prev) URL.revokeObjectURL(prev);
    const url = URL.createObjectURL(file);
    this.customFiles.set(lower, url);

    // Reload any cached sheet matching this filename
    for (const [id, spec] of Object.entries(SPRITE_MANIFEST)) {
      if (spec.walkFile.toLowerCase() === lower) {
        const tex = this.walkSheets.get(id as SpriteId);
        if (tex) this.applyExternalImage(tex, url);
      }
      if (spec.battleFile?.toLowerCase() === lower) {
        const tex = this.battleSheets.get(id as SpriteId);
        if (tex) this.applyExternalImage(tex, url);
      }
    }
  }

  private trackClone(base: THREE.Texture, clone: THREE.Texture) {
    let set = this.liveClones.get(base);
    if (!set) {
      set = new Set();
      this.liveClones.set(base, set);
    }
    set.add(clone);
  }

  public releaseClone(clone: THREE.Texture) {
    this.liveClones.forEach((set) => set.delete(clone));
  }

  private applyExternalImage(tex: THREE.Texture, url: string) {
    if (typeof Image === 'undefined') return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const SourceCtor =
        (THREE as unknown as { TextureSource?: typeof THREE.Source }).TextureSource ?? THREE.Source;
      const newSource = new SourceCtor(img);
      tex.dispose();
      tex.source = newSource;
      tex.needsUpdate = true;
      const clones = this.liveClones.get(tex);
      if (clones) {
        clones.forEach((c) => {
          c.dispose();
          c.source = newSource;
          c.needsUpdate = true;
        });
      }
    };
    img.src = url;
  }

  public getWalkTexture(id: SpriteId): THREE.Texture {
    const existing = this.walkSheets.get(id);
    if (existing) {
      const clone = existing.clone();
      clone.needsUpdate = true;
      clone.magFilter = THREE.NearestFilter;
      clone.minFilter = THREE.NearestFilter;
      clone.generateMipmaps = false;
      clone.colorSpace = THREE.SRGBColorSpace;
      clone.repeat.set(1 / 4, 1 / 4);
      clone.offset.set(0, 3 / 4);
      this.trackClone(existing, clone);
      return clone;
    }

    const spec = SPRITE_MANIFEST[id];
    const pal = PALETTES[id];
    const cell = spec.cellSize;
    const canvas = document.createElement('canvas');
    canvas.width = cell * 4;
    canvas.height = cell * 4;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 4; col++) {
        if (pal.isGear && cell === 64) {
          drawGear64(ctx, col * cell, row * cell, pal, col);
        } else if (pal.isMonster && cell === 48) {
          drawMonster48(ctx, col * cell, row * cell, pal, col);
        } else {
          // Scale cleanly if cell is 48
          if (cell !== 32) {
            ctx.save();
            ctx.translate(col * cell, row * cell);
            ctx.scale(cell / 32, cell / 32);
            drawChibi32(ctx, 0, 0, pal, row, col);
            ctx.restore();
          } else {
            drawChibi32(ctx, col * 32, row * 32, pal, row, col);
          }
        }
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.repeat.set(1 / 4, 1 / 4);
    tex.offset.set(0, 3 / 4);

    const fileLower = spec.walkFile.toLowerCase();
    const overrideUrl =
      this.customFiles.get(fileLower) ||
      (this.availableFiles.has(fileLower) ? `/assets/sprites/${spec.walkFile}` : null);
    if (overrideUrl) this.applyExternalImage(tex, overrideUrl);

    this.walkSheets.set(id, tex);
    return this.getWalkTexture(id);
  }

  public getBattleTexture(id: SpriteId): THREE.Texture {
    const existing = this.battleSheets.get(id);
    if (existing) {
      const clone = existing.clone();
      clone.needsUpdate = true;
      clone.magFilter = THREE.NearestFilter;
      clone.minFilter = THREE.NearestFilter;
      clone.generateMipmaps = false;
      clone.colorSpace = THREE.SRGBColorSpace;
      clone.repeat.set(1 / 4, 1 / 3);
      clone.offset.set(0, 2 / 3);
      this.trackClone(existing, clone);
      return clone;
    }

    const spec = SPRITE_MANIFEST[id];
    const pal = PALETTES[id];
    const cell = spec.cellSize;
    const canvas = document.createElement('canvas');
    canvas.width = cell * 4;
    canvas.height = cell * 3;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    const rowPoses: Array<Array<'idle' | 'strike' | 'finisher' | 'ether' | 'guard' | 'hurt' | 'kneel' | 'victory' | 'ko'>> = [
      ['idle', 'idle', 'idle', 'idle'],
      ['strike', 'finisher', 'ether', 'guard'],
      ['hurt', 'kneel', 'victory', 'ko'],
    ];

    // Party faces West (left toward enemies); Enemies face East (right toward party)
    const dirRow = spec.category === 'enemy' ? 2 : 1;

    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 4; col++) {
        const pose = rowPoses[row][col];
        if (pal.isGear && cell === 64) {
          drawGear64(ctx, col * cell, row * cell, pal, col, pose);
        } else if (pal.isMonster && cell === 48) {
          drawMonster48(ctx, col * cell, row * cell, pal, col, pose);
        } else if (cell !== 32) {
          ctx.save();
          ctx.translate(col * cell, row * cell);
          ctx.scale(cell / 32, cell / 32);
          drawChibi32(ctx, 0, 0, pal, dirRow, col, pose);
          ctx.restore();
        } else {
          drawChibi32(ctx, col * 32, row * 32, pal, dirRow, col, pose);
        }
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.repeat.set(1 / 4, 1 / 3);
    tex.offset.set(0, 2 / 3);

    if (spec.battleFile) {
      const fileLower = spec.battleFile.toLowerCase();
      const overrideUrl =
        this.customFiles.get(fileLower) ||
        (this.availableFiles.has(fileLower) ? `/assets/sprites/${spec.battleFile}` : null);
      if (overrideUrl) this.applyExternalImage(tex, overrideUrl);
    }

    this.battleSheets.set(id, tex);
    return this.getBattleTexture(id);
  }

  public getPortraitDataUrl(id: SpriteId): string {
    const hiRes = HIGHRES_PORTRAITS[id];
    if (hiRes) return hiRes;
    const cached = this.portraitUrls.get(id);
    if (cached) return cached;
    if (typeof document === 'undefined') return '';
    const pal = PALETTES[id];
    const spec = SPRITE_MANIFEST[id];
    const canvas = document.createElement('canvas');
    canvas.width = 48;
    canvas.height = 48;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    // Rich dark slate backdrop inside portrait
    ctx.fillStyle = '#141a2b';
    ctx.fillRect(0, 0, 48, 48);
    if (pal.isGear && spec.cellSize === 64) {
      ctx.save();
      ctx.scale(48 / 64, 48 / 64);
      drawGear64(ctx, 0, 0, pal, 0);
      ctx.restore();
    } else if (pal.isMonster) {
      drawMonster48(ctx, 0, 0, pal, 0);
    } else {
      ctx.save();
      ctx.scale(1.5, 1.5);
      drawChibi32(ctx, 0, 2, pal, 0, 0);
      ctx.restore();
    }
    const url = canvas.toDataURL();
    this.portraitUrls.set(id, url);
    return url;
  }
}

export const SpriteSheetRegistry = new SpriteSheetRegistryImpl();

const DIRECTION_ROW: Record<Direction, number> = {
  S: 0, // Row 0: Facing Down
  W: 1, // Row 1: Facing Left
  E: 2, // Row 2: Facing Right
  N: 3, // Row 3: Facing Up
};

/**
 * GPU UV-offset sprite animator for 4x4 overworld sheets and 4x3 battle sheets.
 * Zero per-frame canvas allocations; crisp pixel shadows via customDepthMaterial.
 */
export class ChibiSpriteAnimator {
  public readonly group: THREE.Group;
  public readonly mesh: THREE.Mesh;
  public readonly texture: THREE.Texture;
  private readonly cols: number;
  private readonly rows: number;
  private animClock = 0;
  private currentFrame = 0;
  private currentRow = 0;

  constructor(
    spriteId: SpriteId,
    mode: 'overworld' | 'battle',
    heightUnits = 1.15
  ) {
    this.group = new THREE.Group();
    this.cols = 4;
    this.rows = mode === 'overworld' ? 4 : 3;
    this.texture =
      mode === 'overworld'
        ? SpriteSheetRegistry.getWalkTexture(spriteId)
        : SpriteSheetRegistry.getBattleTexture(spriteId);

    const widthUnits = heightUnits;
    const geo = new THREE.PlaneGeometry(widthUnits, heightUnits);
    // Pivot at bottom-center so sprite stands flush on floor height
    geo.translate(0, heightUnits * 0.5, 0);

    const mat = new THREE.MeshStandardMaterial({
      map: this.texture,
      transparent: true,
      alphaTest: 0.5,
      side: THREE.DoubleSide,
      roughness: 0.85,
      metalness: 0.0,
    });

    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = false;
    // Matching MeshDepthMaterial for crisp pixel-silhouette shadows
    this.mesh.customDepthMaterial = new THREE.MeshDepthMaterial({
      depthPacking: THREE.RGBADepthPacking,
      map: this.texture,
      alphaTest: 0.5,
    });

    // Soft radial contact shadow disc grounded just above floor
    const shadowGeo = new THREE.CircleGeometry(heightUnits * 0.34, 16);
    shadowGeo.rotateX(-Math.PI / 2);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x05070e,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
    });
    const shadowDisc = new THREE.Mesh(shadowGeo, shadowMat);
    shadowDisc.position.y = 0.02;

    this.group.add(shadowDisc);
    this.group.add(this.mesh);
    this.setUV(0, 0);
  }

  public setUV(col: number, row: number) {
    this.currentFrame = col % this.cols;
    this.currentRow = row % this.rows;
    this.texture.repeat.set(1 / this.cols, 1 / this.rows);
    this.texture.offset.set(
      this.currentFrame / this.cols,
      1 - (this.currentRow + 1) / this.rows
    );
  }

  public updateOverworld(facing: Direction, isMoving: boolean, dt: number, sprinting = false) {
    const row = DIRECTION_ROW[facing];
    if (!isMoving) {
      this.animClock = 0;
      this.setUV(0, row);
      return;
    }
    const fps = sprinting ? 11 : 7.5;
    this.animClock += dt * fps;
    const col = Math.floor(this.animClock) % 4;
    this.setUV(col, row);
  }

  public updateBattle(
    pose: 'idle' | 'strike' | 'finisher' | 'ether' | 'guard' | 'hurt' | 'kneel' | 'victory' | 'ko',
    dt: number
  ) {
    if (pose === 'idle') {
      this.animClock += dt * 4.5;
      this.setUV(Math.floor(this.animClock) % 4, 0);
      return;
    }
    switch (pose) {
      case 'strike':
        this.setUV(0, 1);
        break;
      case 'finisher':
        this.setUV(1, 1);
        break;
      case 'ether':
        this.setUV(2, 1);
        break;
      case 'guard':
        this.setUV(3, 1);
        break;
      case 'hurt':
        this.setUV(0, 2);
        break;
      case 'kneel':
        this.setUV(1, 2);
        break;
      case 'victory':
        this.setUV(2, 2);
        break;
      case 'ko':
        this.setUV(3, 2);
        break;
    }
  }

  public dispose() {
    this.group.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const m = obj as THREE.Mesh;
        m.geometry.dispose();
        if (Array.isArray(m.material)) {
          m.material.forEach((mat) => mat.dispose());
        } else {
          m.material.dispose();
        }
        if (m.customDepthMaterial) {
          m.customDepthMaterial.dispose();
        }
      }
    });
    SpriteSheetRegistry.releaseClone(this.texture);
    this.texture.dispose();
  }
}
