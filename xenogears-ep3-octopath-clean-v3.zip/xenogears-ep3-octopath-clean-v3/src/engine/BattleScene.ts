import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { BattleEnemyInstance, GraphicsQuality, PartyMember } from '../types/rpg';
import { detectSoftwareWebGL } from './HD2DWorldEngine';
import { PixelTextureFactory } from './PixelTextureFactory';
import { ChibiSpriteAnimator } from './SpriteAnimator';

interface PartyActorVis {
  memberId: string;
  baseX: number;
  baseZ: number;
  animator: ChibiSpriteAnimator;
  gearAnimator: ChibiSpriteAnimator | null;
  inGear: boolean;
  pose: 'idle' | 'strike' | 'finisher' | 'ether' | 'guard' | 'hurt' | 'kneel' | 'victory' | 'ko';
  stepForward: number;
  etherRing: THREE.Mesh;
}

interface EnemyActorVis {
  uid: string;
  baseX: number;
  baseZ: number;
  animator: ChibiSpriteAnimator;
  pose: 'idle' | 'strike' | 'hurt' | 'ko';
  flashTimer: number;
  lunge: number;
}

export class BattleSceneEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private partyVis = new Map<string, PartyActorVis>();
  private enemyVis = new Map<string, EnemyActorVis>();
  private arenaGroup: THREE.Group;

  private running = false;
  private frameId = 0;
  private lastTime = 0;
  private hitStopTimer = 0;
  private trauma = 0;
  private baseCamPos = new THREE.Vector3(0, 3.8, 10.6);
  private resizeObserver: ResizeObserver | null = null;
  private onVisibilityChange: () => void;
  private hiddenPaused = false;

  constructor(
    container: HTMLElement,
    arenaTheme: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps',
    party: PartyMember[],
    enemies: BattleEnemyInstance[],
    _quality: GraphicsQuality
  ) {
    this.container = container;
    this.isSoftwareGl = detectSoftwareWebGL();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 1.5)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.style.display = 'block';
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    const w = Math.max(1, container.clientWidth);
    const h = Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(34, w / h, 0.2, 80);
    this.camera.position.copy(this.baseCamPos);
    this.camera.lookAt(0, 1.15, 0);

    this.arenaGroup = new THREE.Group();
    this.scene.add(this.arenaGroup);

    this.buildArenaDiorama(arenaTheme);
    this.buildCombatants(party, enemies);
    this.handleResize();
    this.renderer.render(this.scene, this.camera);

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);
    this.onVisibilityChange = () => {
      this.hiddenPaused = document.visibilityState === 'hidden';
      if (this.hiddenPaused) {
        window.cancelAnimationFrame(this.frameId);
        window.clearTimeout(this.frameId);
        this.frameId = 0;
      } else if (this.running) {
        this.lastTime = performance.now();
        this.scheduleNextTick();
      }
    };
    document.addEventListener('visibilitychange', this.onVisibilityChange);
  }

  private buildArenaDiorama(theme: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps') {
    const isZeboim = theme === 'zeboim_ruins';
    const isCathedral = theme === 'cathedral_steps';

    const bg = isZeboim ? '#0c1524' : isCathedral ? '#242e48' : '#4a6080';
    this.scene.background = new THREE.Color(bg);
    this.scene.fog = new THREE.Fog(bg, 12, 34);

    const hemi = new THREE.HemisphereLight(
      isZeboim ? 0x6ea8e0 : 0x9ec0ea,
      isZeboim ? 0x1e2a3b : 0x5c4b39,
      0.92
    );
    this.scene.add(hemi);

    const sun = new THREE.DirectionalLight(isZeboim ? 0xa3d2ff : 0xffd59c, 2.0);
    sun.position.set(8, 14, 10);
    sun.castShadow = !this.isSoftwareGl;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.bias = -0.0005;
    this.scene.add(sun);

    // Diorama floor
    const floorTex = PixelTextureFactory.getTexture(
      isZeboim ? 'zeboim_floor' : isCathedral ? 'stone_plaza' : 'sand',
      14,
      8
    );
    const floor = new THREE.Mesh(
      new THREE.BoxGeometry(22, 0.5, 14),
      new THREE.MeshStandardMaterial({ map: floorTex, color: 0xffffff, roughness: 0.86 })
    );
    floor.position.y = -0.25;
    floor.receiveShadow = true;
    this.arenaGroup.add(floor);

    // Panoramic HD-2D hand-drawn battle backdrop matching zone
    const backdropFile = isZeboim
      ? 'battle_bg_zeboim_ruins.jpg'
      : isCathedral
        ? 'battle_bg_nisan_cathedral.jpg'
        : 'backdrop_ignas.jpg';
    const skyTex = PixelTextureFactory.getPropTexture(backdropFile);
    const skyPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(28, 14.5),
      new THREE.MeshBasicMaterial({ map: skyTex, fog: false, depthWrite: false })
    );
    skyPlane.position.set(0, 5.4, -9.8);
    this.arenaGroup.add(skyPlane);

    if (isZeboim) {
      const pt = new THREE.PointLight(0x52c4ff, 2.8, 18);
      pt.position.set(-2, 3.4, -2);
      this.arenaGroup.add(pt);
    } else if (isCathedral) {
      const pt = new THREE.PointLight(0xffcf88, 2.6, 18);
      pt.position.set(0, 3.8, -2);
      this.arenaGroup.add(pt);
    }
  }

  private buildCombatants(party: PartyMember[], enemies: BattleEnemyInstance[]) {
    const joined = party.filter((p) => p.joined);
    // Right Side: 4 chibi party members lined up in Octopath staggered diagonal formation
    joined.forEach((m, idx) => {
      const baseX = 1.55 + idx * 0.42;
      const baseZ = -1.55 + idx * 1.02;
      const animator = new ChibiSpriteAnimator(m.spriteId, 'battle', 1.35);
      animator.group.position.set(baseX, 0, baseZ);
      this.scene.add(animator.group);

      let gearAnimator: ChibiSpriteAnimator | null = null;
      if (m.gear) {
        gearAnimator = new ChibiSpriteAnimator(m.gear.spriteId, 'battle', 2.25);
        gearAnimator.group.position.set(baseX, 0, baseZ);
        gearAnimator.group.visible = false;
        this.scene.add(gearAnimator.group);
      }

      // Glowing Ether casting circle beneath party member
      const ringGeo = new THREE.RingGeometry(0.45, 0.72, 24);
      ringGeo.rotateX(-Math.PI / 2);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x76d9ff,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const etherRing = new THREE.Mesh(ringGeo, ringMat);
      etherRing.position.set(baseX, 0.04, baseZ);
      this.scene.add(etherRing);

      this.partyVis.set(m.id, {
        memberId: m.id,
        baseX,
        baseZ,
        animator,
        gearAnimator,
        inGear: false,
        pose: m.hp <= 0 ? 'ko' : 'idle',
        stepForward: 0,
        etherRing,
      });
    });

    // Left Side: Large high-detail HD-2D enemies & Boss sprites
    enemies.forEach((e, idx) => {
      const baseX = e.isBoss ? -3.0 : -2.6 - (idx % 2) * 0.9;
      const baseZ = enemies.length === 1 ? 0 : -1.2 + idx * 1.85;
      const height = e.isBoss ? 2.85 : e.scale * 1.25;
      const animator = new ChibiSpriteAnimator(e.spriteId, 'battle', height);
      animator.group.position.set(baseX, 0, baseZ);
      this.scene.add(animator.group);
      this.enemyVis.set(e.uid, {
        uid: e.uid,
        baseX,
        baseZ,
        animator,
        pose: 'idle',
        flashTimer: 0,
        lunge: 0,
      });
    });
  }

  public syncStates(
    party: PartyMember[],
    enemies: BattleEnemyInstance[],
    boardedGears: Record<string, boolean>,
    activeUid: string | null
  ) {
    for (const m of party) {
      const vis = this.partyVis.get(m.id);
      if (!vis) continue;
      vis.inGear = Boolean(boardedGears[m.id] && vis.gearAnimator);
      vis.animator.group.visible = !vis.inGear;
      if (vis.gearAnimator) vis.gearAnimator.group.visible = vis.inGear;

      if (m.hp <= 0) {
        vis.pose = 'ko';
      } else if (vis.pose === 'idle' || vis.pose === 'kneel') {
        vis.pose = m.hp < m.maxHp * 0.25 ? 'kneel' : 'idle';
      }
      vis.stepForward = activeUid === m.id ? 0.65 : 0;
    }

    for (const e of enemies) {
      const vis = this.enemyVis.get(e.uid);
      if (!vis) continue;
      if (e.hp <= 0) {
        vis.pose = 'ko';
      }
    }
  }

  public triggerPartyAction(
    memberId: string,
    pose: 'strike' | 'finisher' | 'ether' | 'guard' | 'victory'
  ) {
    const vis = this.partyVis.get(memberId);
    if (!vis) return;
    vis.pose = pose;
    vis.stepForward = pose === 'strike' || pose === 'finisher' ? 1.5 : 0.75;
    if (pose === 'ether') {
      (vis.etherRing.material as THREE.MeshBasicMaterial).opacity = 0.85;
    }
    window.setTimeout(() => {
      if (vis.pose === pose && pose !== 'victory') {
        vis.pose = 'idle';
        vis.stepForward = 0;
      }
      (vis.etherRing.material as THREE.MeshBasicMaterial).opacity = 0;
    }, 520);
  }

  public triggerEnemyHit(enemyUid: string, isBreak: boolean) {
    const vis = this.enemyVis.get(enemyUid);
    if (!vis) return;
    vis.pose = 'hurt';
    vis.flashTimer = isBreak ? 0.28 : 0.14;
    if (isBreak) {
      this.hitStopTimer = 0.08; // 80ms Octopath BREAK hit-stop!
      this.trauma = 0.85;
    } else {
      this.trauma = Math.max(this.trauma, 0.35);
    }
    window.setTimeout(() => {
      if (vis.pose === 'hurt') vis.pose = 'idle';
    }, 340);
  }

  public triggerEnemyAttack(enemyUid: string, targetMemberId?: string) {
    const vis = this.enemyVis.get(enemyUid);
    if (vis) {
      vis.pose = 'strike';
      vis.lunge = 1.25;
      window.setTimeout(() => {
        if (vis.pose === 'strike') vis.pose = 'idle';
        vis.lunge = 0;
      }, 420);
    }
    if (targetMemberId) {
      const pv = this.partyVis.get(targetMemberId);
      if (pv && pv.pose !== 'ko') {
        pv.pose = 'hurt';
        this.trauma = Math.max(this.trauma, 0.35);
        window.setTimeout(() => {
          if (pv.pose === 'hurt') pv.pose = 'idle';
        }, 340);
      }
    }
  }

  private handleResize() {
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  public start() {
    if (this.running) return;
    this.running = true;
    this.lastTime = performance.now();
    this.scheduleNextTick();
  }

  public stop() {
    this.running = false;
    window.cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (!this.running) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private scheduleNextTick() {
    if (!this.running) return;
    if (this.isSoftwareGl) {
      this.afterDraw(() => this.tick());
    } else {
      this.frameId = window.requestAnimationFrame(() => this.tick());
    }
  }

  private tick() {
    if (!this.running) return;
    const now = performance.now();
    const rawDt = Math.min(0.05, Math.max(0.001, (now - this.lastTime) / 1000));
    this.lastTime = now;

    if (!this.hiddenPaused) {
      const simDt = this.hitStopTimer > 0 ? 0 : rawDt;
      if (this.hitStopTimer > 0) this.hitStopTimer = Math.max(0, this.hitStopTimer - rawDt);

      // Update Party Sprites
      const damp = 1 - Math.exp(-9 * rawDt);
      this.partyVis.forEach((v) => {
        const targetX = v.baseX - v.stepForward;
        v.animator.group.position.x += (targetX - v.animator.group.position.x) * damp;
        v.animator.updateBattle(v.pose, simDt);
        if (v.gearAnimator) {
          v.gearAnimator.group.position.x = v.animator.group.position.x;
          v.gearAnimator.updateBattle(v.pose, simDt);
        }
        v.etherRing.position.x = v.animator.group.position.x;
        v.etherRing.rotation.z += rawDt * 2.5;
      });

      // Update Enemy Sprites + Hit Flash
      this.enemyVis.forEach((e) => {
        const targetX = e.baseX + e.lunge;
        e.animator.group.position.x += (targetX - e.animator.group.position.x) * damp;
        e.animator.updateBattle(e.pose, simDt);
        const mat = e.animator.mesh.material as THREE.MeshStandardMaterial;
        if (e.flashTimer > 0) {
          e.flashTimer = Math.max(0, e.flashTimer - rawDt);
          mat.emissive.setHex(0xffffff);
          mat.emissiveIntensity = 1.6;
        } else {
          mat.emissive.setHex(0x000000);
          mat.emissiveIntensity = 0;
        }
      });

      // Camera subtle drift + decaying trauma^2 shake
      if (this.trauma > 0) {
        this.trauma = Math.max(0, this.trauma - rawDt * 2.4);
      }
      const shake = this.trauma * this.trauma;
      this.camera.position.set(
        this.baseCamPos.x + Math.sin(now * 0.0005) * 0.25 + (Math.random() - 0.5) * shake * 0.6,
        this.baseCamPos.y + (Math.random() - 0.5) * shake * 0.45,
        this.baseCamPos.z
      );
      this.camera.lookAt(0, 1.1, 0);

      this.renderer.render(this.scene, this.camera);
    }

    if (!this.hiddenPaused) {
      this.scheduleNextTick();
    }
  }

  public dispose() {
    this.stop();
    document.removeEventListener('visibilitychange', this.onVisibilityChange);
    this.resizeObserver?.disconnect();
    this.partyVis.forEach((v) => {
      v.animator.dispose();
      v.gearAnimator?.dispose();
      v.etherRing.geometry.dispose();
      (v.etherRing.material as THREE.Material).dispose();
    });
    this.enemyVis.forEach((e) => e.animator.dispose());
    const disposeMat = (mt: THREE.Material) => {
      const std = mt as THREE.MeshStandardMaterial;
      if (std.map) PixelTextureFactory.releaseClone(std.map);
      if (std.bumpMap) PixelTextureFactory.releaseClone(std.bumpMap);
      mt.dispose();
    };
    this.arenaGroup.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const m = obj as THREE.Mesh;
        m.geometry.dispose();
        if (Array.isArray(m.material)) m.material.forEach(disposeMat);
        else disposeMat(m.material);
        if (m.customDepthMaterial) m.customDepthMaterial.dispose();
      }
    });
    if (this.scene.environment) this.scene.environment.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
