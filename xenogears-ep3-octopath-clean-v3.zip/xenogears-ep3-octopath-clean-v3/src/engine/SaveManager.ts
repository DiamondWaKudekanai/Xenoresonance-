import { AppConfig, SaveSlotData } from '../types/rpg';

const SAVE_SLOT_PREFIX = 'xeno_ep3_save_slot_';
const CONFIG_STORAGE_KEY = 'xeno_ep3_config_v1';
export const SAVE_FORMAT_VERSION = 1;

export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

function getDefaultStorage(): StorageLike | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage;
    }
  } catch {
    return null;
  }
  return null;
}

export const DEFAULT_APP_CONFIG: AppConfig = {
  audio: {
    bgmVolume: 0.75,
    sfxVolume: 0.8,
    muted: false,
  },
  graphicsQuality: 'medium',
  showTouchControls: true,
};

export function formatPlaytime(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const hours = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function validateSaveSlotData(raw: unknown): raw is SaveSlotData {
  if (!raw || typeof raw !== 'object') return false;
  const obj = raw as Record<string, unknown>;
  const validSlot = obj.slotId === 1 || obj.slotId === 2 || obj.slotId === 3;
  const validMap = typeof obj.mapId === 'string' && obj.mapId.length > 0;
  const validPos =
    typeof obj.playerX === 'number' &&
    Number.isFinite(obj.playerX) &&
    typeof obj.playerZ === 'number' &&
    Number.isFinite(obj.playerZ);
  const validParty = Array.isArray(obj.party) && obj.party.length > 0;
  const validGil = typeof obj.gil === 'number' && Number.isFinite(obj.gil) && obj.gil >= 0;
  return validSlot && validMap && validPos && validParty && validGil;
}

export function saveSlot(
  slotId: 1 | 2 | 3,
  data: Omit<SaveSlotData, 'slotId' | 'version' | 'savedAt'>,
  storage: StorageLike | null = getDefaultStorage()
): SaveSlotData {
  const record: SaveSlotData = {
    ...data,
    slotId,
    version: SAVE_FORMAT_VERSION,
    savedAt: new Date().toISOString(),
  };
  if (storage) {
    try {
      storage.setItem(`${SAVE_SLOT_PREFIX}${slotId}`, JSON.stringify(record));
    } catch {
      // Ignore storage quota errors gracefully
    }
  }
  return record;
}

export function loadSlot(
  slotId: 1 | 2 | 3,
  storage: StorageLike | null = getDefaultStorage()
): SaveSlotData | null {
  if (!storage) return null;
  try {
    const raw = storage.getItem(`${SAVE_SLOT_PREFIX}${slotId}`);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!validateSaveSlotData(parsed)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function loadAllSlots(
  storage: StorageLike | null = getDefaultStorage()
): Array<SaveSlotData | null> {
  return [loadSlot(1, storage), loadSlot(2, storage), loadSlot(3, storage)];
}

export function deleteSlot(
  slotId: 1 | 2 | 3,
  storage: StorageLike | null = getDefaultStorage()
): void {
  if (!storage) return;
  try {
    storage.removeItem(`${SAVE_SLOT_PREFIX}${slotId}`);
  } catch {
    // Ignore
  }
}

export function exportSaveToJson(slot: SaveSlotData): string {
  return JSON.stringify(slot, null, 2);
}

export function importSaveFromJson(
  jsonText: string,
  targetSlotId: 1 | 2 | 3,
  storage: StorageLike | null = getDefaultStorage()
): { ok: true; data: SaveSlotData } | { ok: false; error: string } {
  try {
    const parsed: unknown = JSON.parse(jsonText);
    if (!parsed || typeof parsed !== 'object') {
      return { ok: false, error: 'JSON root must be an object.' };
    }
    const candidate = { ...(parsed as Record<string, unknown>), slotId: targetSlotId };
    if (!validateSaveSlotData(candidate)) {
      return {
        ok: false,
        error: 'Save JSON is missing required fields (mapId, coordinates, party, or Gil).',
      };
    }
    const saved = saveSlot(
      targetSlotId,
      {
        mapId: candidate.mapId,
        locationName: candidate.locationName || 'Unknown Sector',
        playerX: candidate.playerX,
        playerZ: candidate.playerZ,
        facing: candidate.facing || 'S',
        playtimeSeconds: Number(candidate.playtimeSeconds) || 0,
        gil: candidate.gil,
        party: candidate.party,
        inventory: Array.isArray(candidate.inventory) ? candidate.inventory : [],
        openedChests: Array.isArray(candidate.openedChests) ? candidate.openedChests : [],
        questFlags:
          candidate.questFlags && typeof candidate.questFlags === 'object'
            ? candidate.questFlags
            : {},
        visitedMaps: Array.isArray(candidate.visitedMaps)
          ? candidate.visitedMaps
          : [candidate.mapId],
      },
      storage
    );
    return { ok: true, data: saved };
  } catch {
    return { ok: false, error: 'Invalid JSON syntax.' };
  }
}

export function loadAppConfig(
  storage: StorageLike | null = getDefaultStorage()
): AppConfig {
  if (!storage) return { ...DEFAULT_APP_CONFIG, audio: { ...DEFAULT_APP_CONFIG.audio } };
  try {
    const raw = storage.getItem(CONFIG_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_APP_CONFIG, audio: { ...DEFAULT_APP_CONFIG.audio } };
    const parsed = JSON.parse(raw) as Partial<AppConfig>;
    return {
      audio: {
        bgmVolume:
          typeof parsed.audio?.bgmVolume === 'number'
            ? Math.min(1, Math.max(0, parsed.audio.bgmVolume))
            : DEFAULT_APP_CONFIG.audio.bgmVolume,
        sfxVolume:
          typeof parsed.audio?.sfxVolume === 'number'
            ? Math.min(1, Math.max(0, parsed.audio.sfxVolume))
            : DEFAULT_APP_CONFIG.audio.sfxVolume,
        muted: Boolean(parsed.audio?.muted),
      },
      graphicsQuality:
        parsed.graphicsQuality === 'low' ||
        parsed.graphicsQuality === 'medium' ||
        parsed.graphicsQuality === 'high'
          ? parsed.graphicsQuality
          : DEFAULT_APP_CONFIG.graphicsQuality,
      showTouchControls:
        typeof parsed.showTouchControls === 'boolean'
          ? parsed.showTouchControls
          : DEFAULT_APP_CONFIG.showTouchControls,
    };
  } catch {
    return { ...DEFAULT_APP_CONFIG, audio: { ...DEFAULT_APP_CONFIG.audio } };
  }
}

export function saveAppConfig(
  config: AppConfig,
  storage: StorageLike | null = getDefaultStorage()
): void {
  if (!storage) return;
  try {
    storage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config));
  } catch {
    // Ignore
  }
}
