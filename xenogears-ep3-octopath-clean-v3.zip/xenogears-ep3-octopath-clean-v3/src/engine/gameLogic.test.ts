import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialInventory, createInitialParty, ENEMY_TEMPLATES } from '../data/initialParty';
import { getMapById, MAP_REGISTRY } from '../data/maps/mapRegistry';
import {
  awardMemberXp,
  computeTurnTimeline,
  getSequenceApCost,
  matchDeathblow,
  resolveGearAttack,
  resolveOnFootCombo,
} from './CombatRules';
import {
  canStepTo,
  checkEncounterStep,
  findNearestInteractable,
  findTriggeredWarp,
  isTileWalkable,
  pushBreadcrumb,
  sampleBreadcrumb,
} from './MapPhysics';
import {
  deleteSlot,
  exportSaveToJson,
  formatPlaytime,
  importSaveFromJson,
  loadAllSlots,
  saveSlot,
  StorageLike,
} from './SaveManager';
import { BattleEnemyInstance } from '../types/rpg';

function createMemoryStorage(): StorageLike {
  const map = new Map<string, string>();
  return {
    getItem: (k) => map.get(k) ?? null,
    setItem: (k, v) => {
      map.set(k, v);
    },
    removeItem: (k) => {
      map.delete(k);
    },
  };
}

test('SaveManager persists 3 slots and round-trips JSON export/import with validation', () => {
  const storage = createMemoryStorage();
  const party = createInitialParty();
  const saved = saveSlot(
    1,
    {
      mapId: 'town_nisan',
      locationName: 'Town of Nisan',
      playerX: 15,
      playerZ: 17,
      facing: 'N',
      playtimeSeconds: 3665,
      gil: 920,
      party,
      inventory: createInitialInventory(),
      openedChests: ['chest_nisan_east_plaza'],
      questFlags: { cathedral_summit_done: true },
      visitedMaps: ['town_nisan', 'interior_cathedral'],
    },
    storage
  );

  assert.equal(formatPlaytime(saved.playtimeSeconds), '01:01:05');
  const slots = loadAllSlots(storage);
  assert.equal(slots[0]?.gil, 920);
  assert.equal(slots[1], null);
  assert.equal(slots[2], null);

  const exported = exportSaveToJson(saved);
  const imported = importSaveFromJson(exported, 3, storage);
  assert.equal(imported.ok, true);
  assert.equal(loadAllSlots(storage)[2]?.slotId, 3);
  assert.equal(loadAllSlots(storage)[2]?.openedChests.includes('chest_nisan_east_plaza'), true);

  // Reject malformed JSON
  const bad = importSaveFromJson('{"foo":"bar"}', 2, storage);
  assert.equal(bad.ok, false);

  deleteSlot(1, storage);
  assert.equal(loadAllSlots(storage)[0], null);
});

test('MapRegistry has all 6 interconnected maps, 14+ living town/interior NPCs, and zero town encounters', () => {
  const mapIds = Object.keys(MAP_REGISTRY);
  assert.equal(mapIds.length, 6);

  const townAndInteriors = [
    getMapById('town_nisan'),
    getMapById('interior_cathedral'),
    getMapById('interior_atelier'),
    getMapById('interior_inn_shop'),
  ];
  const totalTownInteriorNpcs = townAndInteriors.reduce((sum, m) => sum + m.npcs.length, 0);
  assert.ok(totalTownInteriorNpcs >= 14, `Expected >= 14 NPCs, got ${totalTownInteriorNpcs}`);

  // Zero random encounters in towns & interiors
  for (const m of townAndInteriors) {
    const enc = checkEncounterStep(m, m.defaultSpawn.x, m.defaultSpawn.z, 999, 5);
    assert.equal(enc.triggered, false);
  }

  // World map triggers encounters after step threshold
  const wm = getMapById('worldmap_ignas');
  const wmEnc = checkEncounterStep(wm, 12, 12, 25, 15, () => 0.1);
  assert.equal(wmEnc.triggered, true);
  assert.ok(wmEnc.enemyIds.length >= 1);
});

test('MapPhysics enforces floor-switch gate puzzle, warps, and breadcrumb party trail', () => {
  const dungeon = getMapById('dungeon_zeboim_ruins');
  // Gate at (11, 9) is blocked before switch flag is set
  assert.equal(isTileWalkable(dungeon, 11, 9, {}), false);
  assert.equal(isTileWalkable(dungeon, 11, 9, { zeboim_gate_unlocked: true }), true);

  // Nisan Cathedral recessed doorway warps to interior_cathedral
  const nisan = getMapById('town_nisan');
  assert.equal(canStepTo(nisan, 15, 11, 15, 10, {}), true);
  const warp = findTriggeredWarp(nisan, 15, 10);
  assert.equal(warp?.targetMap, 'interior_cathedral');

  // Nearest interactable detects chest within 1.5 tiles
  const chestPrompt = findNearestInteractable(nisan, 25, 11, 'N', [], {});
  assert.equal(chestPrompt?.type, 'chest');
  assert.equal(chestPrompt?.id, 'chest_nisan_east_plaza');

  // Breadcrumb party train spaces followers cleanly behind leader
  let trail = pushBreadcrumb([], 10, 10, 'N');
  for (let i = 1; i <= 15; i++) {
    trail = pushBreadcrumb(trail, 10, 10 - i * 0.2, 'N');
  }
  const follower1 = sampleBreadcrumb(trail, 1, 0.8);
  assert.ok(follower1 !== null);
  assert.ok(follower1.z > 7.2);
});

test('CombatRules resolves AP Deathblows, Octopath Shield Break 2x damage, Gears, Timeline, and Level-Up', () => {
  const party = createInitialParty();
  const lacan = party[0];

  // Deathblow sequence matching
  assert.equal(getSequenceApCost(['T', 'X']), 4);
  assert.equal(matchDeathblow(['T', 'X'], 4)?.name, 'Raijin');
  assert.equal(matchDeathblow(['T', 'T', 'X'], 4)?.name, 'Senretsu');
  assert.equal(matchDeathblow(['S', 'T', 'X'], 4)?.name, 'Tenbu');
  assert.equal(matchDeathblow(['S', 'S', 'X'], 4)?.name, 'Kishin');

  const tpl = ENEMY_TEMPLATES.zeboim_automaton;
  const enemy: BattleEnemyInstance = {
    uid: 'e1',
    templateId: tpl.id,
    name: tpl.name,
    spriteId: tpl.spriteId,
    isBoss: false,
    isGearScale: false,
    hp: tpl.maxHp,
    maxHp: tpl.maxHp,
    atk: tpl.atk,
    def: tpl.def,
    spd: tpl.spd,
    shield: 2,
    maxShield: 4,
    brokenTurns: 0,
    weaknesses: ['LIGHTNING', 'ETHER', 'SWORD'],
    revealedWeaknesses: ['LIGHTNING'],
    xpReward: tpl.xpReward,
    gilReward: tpl.gilReward,
    scale: tpl.scale,
    animState: 'idle',
  };

  // Raijin (LIGHTNING) hits weakness and breaks 2 shields!
  const res = resolveOnFootCombo(lacan, enemy, ['T', 'X'], false);
  assert.equal(res.deathblowUsed?.id, 'raijin');
  assert.equal(res.hitWeakness, true);
  assert.equal(res.newShield, 0);
  assert.equal(res.triggeredBreak, true);
  assert.equal(res.bankedAp, 3); // 7 - 4 AP banked into Boost!
  assert.ok(res.damage > 80);

  // Gear Attack consumes Fuel & scales damage
  const gearRes = resolveGearAttack(lacan, enemy, 2, true);
  assert.equal(gearRes.fuelCost, 160);
  assert.ok(gearRes.damage > res.damage);

  // 8-slot Turn Order Timeline
  const timeline = computeTurnTimeline(party, [enemy], lacan.id, 8);
  assert.equal(timeline.length, 8);
  assert.equal(timeline[0].uid, lacan.id);

  // XP & Level-Up progression
  const lvl = awardMemberXp(lacan, 200, 'raijin');
  assert.equal(lvl.leveledUp, true);
  assert.equal(lvl.newLevel, lacan.level + 1);
  assert.ok(lvl.updatedMember.deathblowMastery.raijin > lacan.deathblowMastery.raijin);
});
