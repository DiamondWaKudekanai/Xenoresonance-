import React, { useEffect, useRef, useState } from 'react';
import { PROLOGUE_TIMELINE } from '../data/storyEpisode3';
import { AudioManager } from '../engine/AudioManager';
import { useGameState } from '../engine/GameStateContext';

export const BootAndPrologue: React.FC = () => {
  const { gameState, setGameState } = useGameState();
  const [beatIdx, setBeatIdx] = useState(0);
  const starCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Auto-advance BOOT_LOGO -> PROLOGUE_INTRO cleanly
  useEffect(() => {
    if (gameState !== 'BOOT_LOGO') return;
    const t = window.setTimeout(() => {
      setGameState('PROLOGUE_INTRO');
    }, 1800);
    return () => window.clearTimeout(t);
  }, [gameState, setGameState]);

  // Starfield animation for PROLOGUE_INTRO (lightweight 2D canvas)
  useEffect(() => {
    if (gameState !== 'PROLOGUE_INTRO') return;
    const canvas = starCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const stars = Array.from({ length: 120 }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      r: 0.7 + Math.random() * 1.6,
      s: 0.15 + Math.random() * 0.45,
      a: 0.35 + Math.random() * 0.65,
    }));

    let raf = 0;
    const draw = () => {
      ctx.fillStyle = '#070a12';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Subtle golden Eldridge nebula glow at horizon
      const grad = ctx.createRadialGradient(
        canvas.width * 0.5,
        canvas.height * 0.85,
        10,
        canvas.width * 0.5,
        canvas.height * 0.85,
        canvas.width * 0.55
      );
      grad.addColorStop(0, 'rgba(212, 176, 106, 0.18)');
      grad.addColorStop(0.5, 'rgba(60, 104, 168, 0.08)');
      grad.addColorStop(1, 'rgba(7, 10, 18, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      for (const st of stars) {
        st.y -= st.s;
        if (st.y < 0) {
          st.y = canvas.height;
          st.x = Math.random() * canvas.width;
        }
        ctx.fillStyle = `rgba(244, 232, 200, ${st.a})`;
        ctx.fillRect(st.x, st.y, st.r, st.r);
      }
      raf = window.requestAnimationFrame(draw);
    };
    raf = window.requestAnimationFrame(draw);
    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, [gameState]);

  // Keyboard skip/advance
  useEffect(() => {
    if (gameState !== 'BOOT_LOGO' && gameState !== 'PROLOGUE_INTRO') return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        AudioManager.playSfx('confirm');
        setGameState('TITLE_SCREEN');
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        AudioManager.playSfx('confirm');
        if (gameState === 'BOOT_LOGO') {
          setGameState('PROLOGUE_INTRO');
        } else if (beatIdx + 1 < PROLOGUE_TIMELINE.length) {
          setBeatIdx((i) => i + 1);
        } else {
          setGameState('TITLE_SCREEN');
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [gameState, beatIdx, setGameState]);

  if (gameState === 'BOOT_LOGO') {
    return (
      <div
        className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#070a12] safe-pad"
        onClick={() => setGameState('PROLOGUE_INTRO')}
      >
        <div className="flex flex-col items-center gap-4 animate-prologue-line">
          <svg
            viewBox="0 0 120 120"
            className="w-20 h-20 text-[#d4b06a]"
            aria-hidden="true"
          >
            <polygon
              points="60,8 94,60 60,112 26,60"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
            />
            <polygon
              points="60,22 82,60 60,98 38,60"
              fill="rgba(212,176,106,0.12)"
              stroke="#f2dca6"
              strokeWidth="1.2"
            />
            <circle cx="60" cy="60" r="9" fill="#f2dca6" />
          </svg>
          <p className="font-display text-sm tracking-[0.35em] text-[#d4b06a]">
            PERFECT WORKS ARCHIVE
          </p>
          <p className="font-serif-jp text-xs tracking-[0.22em] text-[#a9b3c7]">
            EPISODE III · HD-2D ENGINE
          </p>
        </div>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setGameState('TITLE_SCREEN');
          }}
          className="mt-8 px-4 py-1.5 text-xs tracking-wider text-[#b6a688] hover:text-[#f2dca6] transition-colors"
        >
          Skip Intro
        </button>
      </div>
    );
  }

  if (gameState !== 'PROLOGUE_INTRO') return null;

  const beat = PROLOGUE_TIMELINE[beatIdx];

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-[#070a12] safe-pad overflow-hidden">
      <canvas ref={starCanvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />
      <img
        src="/assets/props/backdrop_ignas.jpg"
        alt=""
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 w-full h-[58%] object-cover object-bottom opacity-30 pointer-events-none select-none"
        style={{
          imageRendering: 'pixelated',
          maskImage: 'linear-gradient(to top, rgba(0,0,0,0.95) 35%, transparent 100%)',
          WebkitMaskImage: 'linear-gradient(to top, rgba(0,0,0,0.95) 35%, transparent 100%)',
        }}
      />

      {/* Top Timeline Rail */}
      <div className="relative z-10 w-full max-w-3xl flex items-center justify-between pt-2">
        <div className="flex items-center gap-3 text-xs font-mono-num text-[#c9b285]">
          {PROLOGUE_TIMELINE.map((b, i) => (
            <button
              key={b.year}
              type="button"
              onClick={() => {
                AudioManager.playSfx('cursor');
                setBeatIdx(i);
              }}
              className={`px-2.5 py-1 border transition-colors whitespace-nowrap ${
                i === beatIdx
                  ? 'border-[#d4b06a] bg-[#1a2236] text-[#f5e3ba]'
                  : 'border-transparent text-[#818ca3] hover:text-[#d4b06a]'
              }`}
            >
              {b.year}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => {
            AudioManager.playSfx('confirm');
            setGameState('TITLE_SCREEN');
          }}
          className="jrpg-window-subtle px-4 py-1.5 text-xs tracking-widest uppercase text-[#e6d3a7] hover:text-white transition-colors whitespace-nowrap"
        >
          Skip Prologue
        </button>
      </div>

      {/* Narrative Centerpiece */}
      <div
        key={beat.year}
        className="relative z-10 max-w-2xl px-6 text-center animate-prologue-line"
      >
        <p className="font-mono-num text-xs tracking-[0.28em] text-[#d4b06a] mb-2">
          {beat.era}
        </p>
        <h2 className="font-display text-2xl sm:text-3xl text-[#f5ead4] tracking-wide mb-4">
          {beat.title}
        </h2>
        <div className="w-28 h-[1px] bg-[#d4b06a]/55 mx-auto mb-5" />
        <p className="font-serif-jp text-lg sm:text-xl leading-relaxed text-[#ddd4c3]">
          {beat.body}
        </p>
      </div>

      {/* Bottom Advance Bar */}
      <div className="relative z-10 flex items-center gap-4 pb-2">
        <button
          type="button"
          onClick={() => {
            AudioManager.playSfx('confirm');
            if (beatIdx + 1 < PROLOGUE_TIMELINE.length) {
              setBeatIdx((i) => i + 1);
            } else {
              setGameState('TITLE_SCREEN');
            }
          }}
          className="jrpg-window px-7 py-2.5 font-display text-sm tracking-[0.2em] text-[#f5e3ba] hover:border-[#f2dca6] transition-colors whitespace-nowrap"
        >
          {beatIdx + 1 < PROLOGUE_TIMELINE.length ? 'Next Chronicle' : 'Proceed to Title'}
        </button>
      </div>
    </div>
  );
};
