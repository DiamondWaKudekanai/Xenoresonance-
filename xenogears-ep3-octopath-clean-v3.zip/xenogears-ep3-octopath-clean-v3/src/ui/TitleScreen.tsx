import React, { useEffect } from 'react';
import { AudioManager } from '../engine/AudioManager';
import { useGameState } from '../engine/GameStateContext';
import { formatPlaytime } from '../engine/SaveManager';

export const TitleScreen: React.FC = () => {
  const {
    gameState,
    startNewGame,
    continueFromSlot,
    saveSlots,
    activeOverlay,
    setActiveOverlay,
    setGameState,
  } = useGameState();

  const hasAnySave = saveSlots.some((s) => s !== null);

  // Enter / Space starts New Game directly when on Title Screen with no modal open
  useEffect(() => {
    if (gameState !== 'TITLE_SCREEN' || activeOverlay !== null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        startNewGame(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [gameState, activeOverlay, startNewGame]);

  if (gameState !== 'TITLE_SCREEN') return null;

  return (
    <div className="fixed inset-0 z-30 pointer-events-none flex flex-col justify-between safe-pad">
      {/* Subtle atmospheric top/bottom gradient scrim keeping center 3D Nisan diorama crisp */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#070b14]/70 via-transparent to-[#070b14]/85 pointer-events-none" />

      {/* Top Emblem Lockup */}
      <div className="relative z-10 flex flex-col items-center pt-3 sm:pt-6">
        <svg
          viewBox="0 0 560 128"
          className="w-[340px] sm:w-[480px] md:w-[540px] h-auto drop-shadow-[0_6px_18px_rgba(0,0,0,0.85)]"
          role="img"
          aria-label="Xenogears Episode III: Cradle of Nisan"
        >
          {/* Decorative Zohar Crest behind Title */}
          <g transform="translate(280, 56)" opacity="0.9">
            <polygon
              points="0,-46 28,0 0,46 -28,0"
              fill="rgba(12, 17, 30, 0.55)"
              stroke="#d4b06a"
              strokeWidth="1.5"
            />
            <polygon
              points="0,-34 18,0 0,34 -18,0"
              fill="none"
              stroke="#f2dca6"
              strokeWidth="0.9"
              opacity="0.7"
            />
            <line x1="-180" y1="0" x2="-38" y2="0" stroke="#d4b06a" strokeWidth="1" opacity="0.65" />
            <line x1="38" y1="0" x2="180" y2="0" stroke="#d4b06a" strokeWidth="1" opacity="0.65" />
          </g>
          <text
            x="280"
            y="50"
            textAnchor="middle"
            fill="#f7ecd4"
            fontFamily="Cinzel, Georgia, serif"
            fontSize="36"
            fontWeight="700"
            letterSpacing="9"
          >
            XENOGEARS
          </text>
          <text
            x="280"
            y="84"
            textAnchor="middle"
            fill="#e3c078"
            fontFamily="Cinzel, Georgia, serif"
            fontSize="15"
            fontWeight="600"
            letterSpacing="5.5"
          >
            EPISODE III · CRADLE OF NISAN
          </text>
          <text
            x="280"
            y="108"
            textAnchor="middle"
            fill="#c3ccd9"
            fontFamily="Cormorant Garamond, Georgia, serif"
            fontSize="14"
            fontStyle="italic"
            letterSpacing="2.2"
          >
            Year 9499 — Five Hundred Years Before the Awakening
          </text>
        </svg>
      </div>

      {/* Bottom Command Menu over calm lower safe region */}
      <div className="relative z-10 flex flex-col items-center gap-3 pb-2 pointer-events-auto">
        <div className="jrpg-window px-5 py-3.5 flex flex-wrap items-center justify-center gap-3 sm:gap-5">
          <button
            type="button"
            data-start="true"
            onClick={() => startNewGame(false)}
            className="px-6 py-2 bg-[#d4b06a]/20 border border-[#e3c078] text-[#fff6e0] font-display text-sm tracking-[0.18em] hover:bg-[#d4b06a]/35 transition-colors whitespace-nowrap"
          >
            New Game
          </button>

          <button
            type="button"
            onClick={() => {
              AudioManager.playSfx('confirm');
              setActiveOverlay('continue_modal');
            }}
            className={`px-5 py-2 border font-display text-sm tracking-[0.16em] transition-colors whitespace-nowrap ${
              hasAnySave
                ? 'border-[#d4b06a]/70 text-[#f2e4c7] hover:bg-[#d4b06a]/20'
                : 'border-[#5a6275]/60 text-[#9aa4b8] hover:border-[#d4b06a]/60 hover:text-[#e6d6b5]'
            }`}
          >
            Continue
          </button>

          <button
            type="button"
            onClick={() => {
              AudioManager.playSfx('confirm');
              setActiveOverlay('config_modal');
            }}
            className="px-5 py-2 border border-[#d4b06a]/60 text-[#e6d8bc] font-display text-sm tracking-[0.16em] hover:bg-[#d4b06a]/20 transition-colors whitespace-nowrap"
          >
            Config
          </button>

          <button
            type="button"
            onClick={() => {
              AudioManager.playSfx('cursor');
              setGameState('PROLOGUE_INTRO');
            }}
            className="px-4 py-2 text-xs font-display tracking-[0.15em] text-[#b4bfd4] hover:text-[#f2dca6] transition-colors whitespace-nowrap"
          >
            Prologue
          </button>
        </div>

        <p className="text-[11px] tracking-[0.14em] text-[#b5c0d4]/90 text-center">
          WASD / D-Pad Move · Enter / [A] Interact · Shift / [B] Sprint · M / [X] Menu · Q / [Y] Map
        </p>
      </div>

      {/* Continue (3 Save Slots) Modal */}
      {activeOverlay === 'continue_modal' && (
        <div className="fixed inset-0 z-40 bg-black/75 flex items-center justify-center p-4 pointer-events-auto">
          <div className="jrpg-window w-full max-w-xl p-5 flex flex-col gap-3 max-h-[85dvh] overflow-y-auto jrpg-scroll">
            <div className="flex items-center justify-between border-b border-[#d4b06a]/35 pb-2.5">
              <h3 className="font-display text-base tracking-[0.2em] text-[#f2dca6]">
                CONTINUE JOURNEY — 3 ARCHIVE SLOTS
              </h3>
              <button
                type="button"
                onClick={() => {
                  AudioManager.playSfx('cancel');
                  setActiveOverlay(null);
                }}
                className="px-3 py-1 text-xs border border-[#d4b06a]/50 text-[#e6d5b2] hover:bg-[#d4b06a]/20"
              >
                Close
              </button>
            </div>

            <div className="flex flex-col gap-2.5">
              {([1, 2, 3] as const).map((slotId) => {
                const slot = saveSlots[slotId - 1];
                return (
                  <button
                    key={slotId}
                    type="button"
                    disabled={!slot}
                    onClick={() => slot && continueFromSlot(slotId)}
                    className={`w-full text-left p-3.5 border transition-colors ${
                      slot
                        ? 'border-[#d4b06a]/65 bg-[#141c2e] hover:bg-[#1d2842] cursor-pointer'
                        : 'border-[#333c52] bg-[#0d1220]/70 opacity-65 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-display text-sm text-[#f2dca6]">
                        Slot {slotId} — {slot ? slot.locationName : 'Empty Archive'}
                      </span>
                      {slot && (
                        <span className="font-mono-num text-xs text-[#c8d2e6]">
                          {formatPlaytime(slot.playtimeSeconds)} · {slot.gil} G
                        </span>
                      )}
                    </div>
                    {slot ? (
                      <div className="mt-1.5 flex items-center justify-between text-xs text-[#a9b6cf]">
                        <span>
                          Party: {slot.party.filter((p) => p.joined).map((p) => `${p.name} Lv.${p.level}`).join(' · ')}
                        </span>
                        <span className="font-mono-num text-[11px] text-[#8d9cb8]">
                          Tile ({Math.round(slot.playerX)}, {Math.round(slot.playerZ)})
                        </span>
                      </div>
                    ) : (
                      <p className="mt-1 text-xs text-[#79859e]">
                        Record progress at a Memory Cube or Main Menu to populate this slot.
                      </p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
