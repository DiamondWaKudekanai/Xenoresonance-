import React, { useEffect, useState } from 'react';
import { AudioManager } from '../engine/AudioManager';
import { useGameState } from '../engine/GameStateContext';
import { SpriteSheetRegistry } from '../engine/SpriteAnimator';

export const DialogueOverlay: React.FC = () => {
  const { activeDialogue, advanceDialogue } = useGameState();
  const [revealedChars, setRevealedChars] = useState(0);

  const currentLine = activeDialogue ? activeDialogue.lines[activeDialogue.index] : null;
  const fullText = currentLine?.text ?? '';
  const isFinished = revealedChars >= fullText.length;

  useEffect(() => {
    if (!currentLine) return;
    setRevealedChars(0);
    let idx = 0;
    const timer = window.setInterval(() => {
      idx += 2;
      setRevealedChars(idx);
      if (idx % 6 === 0 && idx < currentLine.text.length) {
        AudioManager.playSfx('voice', currentLine.voicePitch ?? 1.0);
      }
      if (idx >= currentLine.text.length) {
        window.clearInterval(timer);
      }
    }, 24);
    return () => window.clearInterval(timer);
  }, [currentLine]);

  if (!activeDialogue || !currentLine) return null;

  const portraitUrl = currentLine.spriteId
    ? SpriteSheetRegistry.getPortraitDataUrl(currentLine.spriteId)
    : null;

  const handleTap = () => {
    if (!isFinished) {
      setRevealedChars(fullText.length);
      return;
    }
    advanceDialogue();
  };

  return (
    <div
      className="fixed inset-0 z-40 flex flex-col justify-end items-center safe-pad pb-4 sm:pb-6 bg-black/25"
      onClick={handleTap}
    >
      <div className="jrpg-window w-full max-w-3xl p-4 sm:p-5 flex items-start gap-4 pointer-events-auto">
        {portraitUrl && (
          <div className="shrink-0 w-16 h-16 sm:w-20 sm:h-20 border border-[#d4b06a]/70 bg-[#0d121f] p-1 relative">
            <img
              src={portraitUrl}
              alt={currentLine.speaker}
              className="w-full h-full object-contain"
              style={{ imageRendering: 'pixelated' }}
            />
            {currentLine.emote && (
              <span className="absolute -top-2.5 -right-2.5 px-1.5 py-0.5 bg-[#121929] border border-[#f2dca6] font-mono-num text-xs font-bold text-[#f2dca6]">
                {currentLine.emote}
              </span>
            )}
          </div>
        )}

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1.5 border-b border-[#d4b06a]/30 pb-1">
            <span
              className="font-display text-sm sm:text-base tracking-[0.14em]"
              style={{ color: currentLine.accentColor ?? '#f2dca6' }}
            >
              {currentLine.speaker}
            </span>
            <span className="font-mono-num text-[11px] text-[#98a6bf]">
              {activeDialogue.index + 1} / {activeDialogue.lines.length}
            </span>
          </div>

          <p className="font-serif-jp text-base sm:text-lg leading-relaxed text-[#f2ead8] min-h-[3.2rem]">
            {fullText.slice(0, revealedChars)}
          </p>

          <div className="mt-2 flex justify-end">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleTap();
              }}
              className="min-h-[48px] px-4 py-2 text-xs font-display tracking-widest border border-[#d4b06a]/60 text-[#f2dca6] hover:bg-[#d4b06a]/20 transition-colors"
            >
              {isFinished
                ? activeDialogue.index + 1 < activeDialogue.lines.length
                  ? 'Continue [A]'
                  : 'Finish [A]'
                : 'Reveal'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
