import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ENEMY_TEMPLATES } from '../data/initialParty';
import { ITEMS } from '../data/itemsAndGear';
import { AudioManager } from '../engine/AudioManager';
import { BattleSceneEngine } from '../engine/BattleScene';
import {
  AP_COST_MAP,
  awardMemberXp,
  computeTurnTimeline,
  getMemberStats,
  getSequenceApCost,
  matchDeathblow,
  MAX_TURN_AP,
  resolveEtherSkill,
  resolveGearAttack,
  resolveOnFootCombo,
} from '../engine/CombatRules';
import { useGameState } from '../engine/GameStateContext';
import { SpriteSheetRegistry } from '../engine/SpriteAnimator';
import { APInput, BattleEnemyInstance, PartyMember, WeaknessType } from '../types/rpg';

const WEAKNESS_SHORT: Record<WeaknessType, string> = {
  PHYSICAL: 'PHY',
  SWORD: 'SWD',
  ETHER: 'ETH',
  FIRE: 'FIR',
  LIGHTNING: 'LTN',
};

interface VictorySummary {
  totalXp: number;
  totalGil: number;
  drops: string[];
  levelUps: Array<{ name: string; newLevel: number }>;
  updatedParty: PartyMember[];
}

export const BattleOverlay: React.FC = () => {
  const {
    gameState,
    battleContext,
    party: initialParty,
    inventory,
    config,
    consumeBattleItem,
    completeBattleVictory,
    completeBattleFlee,
    triggerGameOver,
  } = useGameState();

  const canvasRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<BattleSceneEngine | null>(null);

  const [battleParty, setBattleParty] = useState<PartyMember[]>([]);
  const [enemies, setEnemies] = useState<BattleEnemyInstance[]>([]);
  const [turnIndex, setTurnIndex] = useState(0);
  const [selectedEnemyUid, setSelectedEnemyUid] = useState<string>('');
  const [comboSeq, setComboSeq] = useState<APInput[]>([]);
  const [boostGauge, setBoostGauge] = useState<Record<string, number>>({});
  const [useBoost, setUseBoost] = useState(false);
  const [boardedGears, setBoardedGears] = useState<Record<string, boolean>>({});
  const [guarding, setGuarding] = useState<Record<string, boolean>>({});
  const [subMenu, setSubMenu] = useState<'none' | 'ether' | 'item'>('none');
  const [battleLog, setBattleLog] = useState('Encounter engaged! Exploit weaknesses to BREAK enemy shields.');
  const [busy, setBusy] = useState(false);
  const [breakBanner, setBreakBanner] = useState<string | null>(null);
  const [victory, setVictory] = useState<VictorySummary | null>(null);
  const usedDeathblowsRef = useRef<Record<string, string>>({});

  // Initialize battle combatants & 3D diorama once per battleContext
  useEffect(() => {
    if (gameState !== 'BATTLE' || !battleContext) return;

    const clonedParty: PartyMember[] = initialParty.map((m) => ({
      ...m,
      deathblowMastery: { ...m.deathblowMastery },
      gear: m.gear ? { ...m.gear, attackLevel: 1, boosterActive: false } : null,
    }));

    const spawnedEnemies: BattleEnemyInstance[] = battleContext.enemyIds.map((tid, idx) => {
      const tpl = ENEMY_TEMPLATES[tid] ?? ENEMY_TEMPLATES.solaris_trooper;
      return {
        uid: `${tid}_${idx}`,
        templateId: tid,
        name: battleContext.enemyIds.length > 1 && !tpl.isBoss ? `${tpl.name} ${String.fromCharCode(65 + idx)}` : tpl.name,
        spriteId: tpl.spriteId,
        isBoss: Boolean(tpl.isBoss),
        isGearScale: Boolean(tpl.isGearScale),
        hp: tpl.maxHp,
        maxHp: tpl.maxHp,
        atk: tpl.atk,
        def: tpl.def,
        spd: tpl.spd,
        shield: tpl.maxShield,
        maxShield: tpl.maxShield,
        brokenTurns: 0,
        weaknesses: [...tpl.weaknesses],
        revealedWeaknesses: [tpl.weaknesses[0]],
        xpReward: tpl.xpReward,
        gilReward: tpl.gilReward,
        dropItemId: tpl.dropItemId,
        scale: tpl.scale,
        animState: 'idle',
      };
    });

    setBattleParty(clonedParty);
    setEnemies(spawnedEnemies);
    setSelectedEnemyUid(spawnedEnemies[0]?.uid ?? '');
    setTurnIndex(0);
    setComboSeq([]);
    setBoostGauge({});
    setUseBoost(false);
    setBoardedGears({});
    setGuarding({});
    setSubMenu('none');
    setVictory(null);
    setBusy(false);
    usedDeathblowsRef.current = {};
    setBattleLog(
      battleContext.isBoss
        ? 'BOSS ENGAGED: Prototype Diabolos awakens! Board Gears or chain Deathblows to shatter its Shields!'
        : 'Hostiles spotted! Chain AP inputs for Deathblows and shatter enemy Shields.'
    );

    if (canvasRef.current) {
      engineRef.current?.dispose();
      const eng = new BattleSceneEngine(
        canvasRef.current,
        battleContext.arenaTheme,
        clonedParty,
        spawnedEnemies,
        config.graphicsQuality
      );
      eng.start();
      engineRef.current = eng;
    }

    return () => {
      engineRef.current?.dispose();
      engineRef.current = null;
    };
  }, [gameState, battleContext]);

  // Build dynamic turn order
  const livingActors = useMemo(() => {
    const list: Array<{ uid: string; side: 'party' | 'enemy'; spd: number }> = [];
    battleParty.forEach((p) => {
      if (p.joined && p.hp > 0) list.push({ uid: p.id, side: 'party', spd: getMemberStats(p).spd });
    });
    enemies.forEach((e) => {
      if (e.hp > 0) list.push({ uid: e.uid, side: 'enemy', spd: e.spd });
    });
    return list.sort((a, b) => b.spd - a.spd);
  }, [battleParty, enemies]);

  const activeActor = livingActors.length > 0 ? livingActors[turnIndex % livingActors.length] : null;
  const activeMember =
    activeActor?.side === 'party'
      ? battleParty.find((p) => p.id === activeActor.uid) ?? null
      : null;

  const timeline = useMemo(
    () => computeTurnTimeline(battleParty, enemies, activeActor?.uid ?? null, 8),
    [battleParty, enemies, activeActor?.uid]
  );

  // Sync visual states to 3D BattleScene
  useEffect(() => {
    engineRef.current?.syncStates(
      battleParty,
      enemies,
      boardedGears,
      activeActor?.uid ?? null
    );
  }, [battleParty, enemies, boardedGears, activeActor?.uid]);

  // Keep selected enemy valid
  useEffect(() => {
    const stillAlive = enemies.find((e) => e.uid === selectedEnemyUid && e.hp > 0);
    if (!stillAlive) {
      const firstAlive = enemies.find((e) => e.hp > 0);
      if (firstAlive) setSelectedEnemyUid(firstAlive.uid);
    }
  }, [enemies, selectedEnemyUid]);

  const checkBattleEnd = (nextParty: PartyMember[], nextEnemies: BattleEnemyInstance[]): boolean => {
    const allEnemiesDown = nextEnemies.length > 0 && nextEnemies.every((e) => e.hp <= 0);
    if (allEnemiesDown) {
      AudioManager.playSfx('victory');
      nextParty.forEach((m) => {
        if (m.hp > 0) engineRef.current?.triggerPartyAction(m.id, 'victory');
      });
      const totalXp = nextEnemies.reduce((s, e) => s + e.xpReward, 0);
      const totalGil = nextEnemies.reduce((s, e) => s + e.gilReward, 0);
      const drops = nextEnemies.map((e) => e.dropItemId).filter((x): x is string => Boolean(x));
      const levelUps: Array<{ name: string; newLevel: number }> = [];
      const progressedParty = nextParty.map((m) => {
        const res = awardMemberXp(m, totalXp, usedDeathblowsRef.current[m.id]);
        if (res.leveledUp) levelUps.push({ name: m.name, newLevel: res.newLevel });
        return res.updatedMember;
      });
      setVictory({ totalXp, totalGil, drops, levelUps, updatedParty: progressedParty });
      return true;
    }

    const allPartyDown = nextParty.filter((p) => p.joined).every((p) => p.hp <= 0);
    if (allPartyDown) {
      window.setTimeout(() => triggerGameOver(), 650);
      return true;
    }
    return false;
  };

  const advanceTurn = (nextParty: PartyMember[], nextEnemies: BattleEnemyInstance[]) => {
    if (checkBattleEnd(nextParty, nextEnemies)) return;
    setComboSeq([]);
    setUseBoost(false);
    setSubMenu('none');
    setTurnIndex((i) => i + 1);
    setBusy(false);
  };

  // Automatic Enemy AI Turn Execution
  useEffect(() => {
    if (gameState !== 'BATTLE' || victory || busy || !activeActor || activeActor.side !== 'enemy') {
      return;
    }
    const enemy = enemies.find((e) => e.uid === activeActor.uid);
    if (!enemy || enemy.hp <= 0) {
      setTurnIndex((i) => i + 1);
      return;
    }

    setBusy(true);
    const timer = window.setTimeout(() => {
      // Stunned / Broken recovery turn
      if (enemy.brokenTurns > 0) {
        const recovered = enemies.map((e) =>
          e.uid === enemy.uid
            ? { ...e, brokenTurns: Math.max(0, e.brokenTurns - 1), shield: e.maxShield }
            : e
        );
        setEnemies(recovered);
        setBattleLog(`${enemy.name} recovers from BREAK and restores its Shields!`);
        advanceTurn(battleParty, recovered);
        return;
      }

      const tpl = ENEMY_TEMPLATES[enemy.templateId];
      const skill = tpl.skills[Math.floor(Math.random() * tpl.skills.length)];
      const aliveParty = battleParty.filter((p) => p.joined && p.hp > 0);
      if (aliveParty.length === 0) return;

      const targets = skill.aoe
        ? aliveParty
        : [aliveParty[Math.floor(Math.random() * aliveParty.length)]];

      AudioManager.playSfx('hurt');
      engineRef.current?.triggerEnemyAttack(enemy.uid, targets[0].id);

      let totalHitText = '';
      const nextParty = battleParty.map((m) => {
        if (!targets.some((t) => t.id === m.id)) return m;
        const st = getMemberStats(m);
        const inGear = Boolean(boardedGears[m.id] && m.gear);
        const defVal = inGear ? st.gearDef : st.def;
        const guardMult = guarding[m.id] ? 0.5 : 1.0;
        const dmg = Math.max(
          8,
          Math.round((enemy.atk * 1.9 * skill.multiplier - defVal * 0.7) * guardMult)
        );
        totalHitText = `${dmg}`;
        if (inGear && m.gear) {
          const nextFrameHp = Math.max(0, m.gear.frameHp - dmg);
          if (nextFrameHp === 0) {
            setBoardedGears((prev) => ({ ...prev, [m.id]: false }));
          }
          return { ...m, gear: { ...m.gear, frameHp: nextFrameHp } };
        }
        return { ...m, hp: Math.max(0, m.hp - dmg) };
      });

      setBattleParty(nextParty);
      setBattleLog(
        skill.aoe
          ? `${enemy.name} unleashes ${skill.name} across the party!`
          : `${enemy.name} strikes ${targets[0].name} with ${skill.name} for ${totalHitText} damage!`
      );
      window.setTimeout(() => advanceTurn(nextParty, enemies), 480);
    }, 520);

    return () => window.clearTimeout(timer);
  }, [activeActor, busy, victory, gameState]);

  if (gameState !== 'BATTLE' || !battleContext) return null;

  const targetEnemy = enemies.find((e) => e.uid === selectedEnemyUid) ?? enemies[0];
  const currentApSpent = getSequenceApCost(comboSeq);
  const remainingAp = MAX_TURN_AP - currentApSpent;
  const matchedDb = activeMember ? matchDeathblow(comboSeq, activeMember.level) : null;
  const activeInGear = Boolean(activeMember && boardedGears[activeMember.id] && activeMember.gear);
  const memberBoost = activeMember ? boostGauge[activeMember.id] ?? 0 : 0;

  const flashBreak = (enemyName: string) => {
    setBreakBanner(`BREAK! ${enemyName} STUNNED — 2x DAMAGE`);
    AudioManager.playSfx('break');
    window.setTimeout(() => setBreakBanner(null), 1300);
  };

  const handleQueueAp = (input: APInput) => {
    if (busy || !activeMember) return;
    if (currentApSpent + AP_COST_MAP[input] > MAX_TURN_AP) {
      AudioManager.playSfx('cancel');
      return;
    }
    AudioManager.playSfx('cursor');
    setComboSeq((prev) => [...prev, input]);
  };

  const handleExecuteCombo = () => {
    if (busy || !activeMember || !targetEnemy || comboSeq.length === 0) return;
    setBusy(true);
    setGuarding((g) => ({ ...g, [activeMember.id]: false }));

    const res = resolveOnFootCombo(activeMember, targetEnemy, comboSeq, useBoost && memberBoost >= 3);
    if (res.deathblowUsed) {
      usedDeathblowsRef.current[activeMember.id] = res.deathblowUsed.id;
    }

    AudioManager.playSfx(res.deathblowUsed ? 'ether' : 'attack');
    engineRef.current?.triggerPartyAction(
      activeMember.id,
      res.deathblowUsed ? 'finisher' : 'strike'
    );
    engineRef.current?.triggerEnemyHit(targetEnemy.uid, res.triggeredBreak);
    if (res.triggeredBreak) flashBreak(targetEnemy.name);

    const nextBoost = useBoost && memberBoost >= 3 ? Math.max(0, memberBoost - 3) : Math.min(7, memberBoost + res.bankedAp);
    setBoostGauge((prev) => ({ ...prev, [activeMember.id]: nextBoost }));

    const nextEnemies = enemies.map((e) => {
      if (e.uid !== targetEnemy.uid) return e;
      const revealed =
        res.hitWeakness && res.deathblowUsed && !e.revealedWeaknesses.includes(res.deathblowUsed.element)
          ? [...e.revealedWeaknesses, res.deathblowUsed.element]
          : e.revealedWeaknesses;
      return {
        ...e,
        hp: res.newHp,
        shield: res.newShield,
        brokenTurns: res.triggeredBreak ? 1 : e.brokenTurns,
        revealedWeaknesses: revealed,
      };
    });

    setEnemies(nextEnemies);
    setBattleLog(
      res.deathblowUsed
        ? `${activeMember.name} unleashes Deathblow [${res.deathblowUsed.name}] on ${targetEnemy.name} for ${res.damage} DMG!${res.triggeredBreak ? ' SHIELD BROKEN!' : ''}`
        : `${activeMember.name} combos ${targetEnemy.name} for ${res.damage} DMG (+${res.bankedAp} Boost banked).`
    );

    window.setTimeout(() => advanceTurn(battleParty, nextEnemies), 520);
  };

  const handleGearAttack = (level: 1 | 2 | 3 | 4) => {
    if (busy || !activeMember || !activeMember.gear || !targetEnemy) return;
    const gear = activeMember.gear;
    const res = resolveGearAttack(activeMember, targetEnemy, level, gear.boosterActive);
    if (gear.fuel < res.fuelCost) {
      AudioManager.playSfx('cancel');
      setBattleLog(`${gear.name} has insufficient Fuel! Use Charge or a Zohar Fuel Cell.`);
      return;
    }

    setBusy(true);
    AudioManager.playSfx('ether');
    engineRef.current?.triggerPartyAction(activeMember.id, level >= 2 ? 'finisher' : 'strike');
    engineRef.current?.triggerEnemyHit(targetEnemy.uid, res.triggeredBreak);
    if (res.triggeredBreak) flashBreak(targetEnemy.name);

    const nextParty = battleParty.map((m) =>
      m.id === activeMember.id && m.gear
        ? {
            ...m,
            gear: {
              ...m.gear,
              fuel: Math.max(0, m.gear.fuel - res.fuelCost),
              attackLevel: level === 4 ? 1 : Math.min(4, m.gear.attackLevel + 1),
            },
          }
        : m
    );
    const nextEnemies = enemies.map((e) =>
      e.uid === targetEnemy.uid
        ? {
            ...e,
            hp: res.newHp,
            shield: res.newShield,
            brokenTurns: res.triggeredBreak ? 1 : e.brokenTurns,
          }
        : e
    );

    setBattleParty(nextParty);
    setEnemies(nextEnemies);
    setBattleLog(
      `${gear.name} executes Attack Lv.${level === 4 ? '∞' : level} on ${targetEnemy.name} for ${res.damage} DMG! (-${res.fuelCost} Fuel)`
    );
    window.setTimeout(() => advanceTurn(nextParty, nextEnemies), 560);
  };

  const handleGearCharge = () => {
    if (busy || !activeMember || !activeMember.gear) return;
    setBusy(true);
    AudioManager.playSfx('ether');
    const st = getMemberStats(activeMember);
    const nextParty = battleParty.map((m) =>
      m.id === activeMember.id && m.gear
        ? {
            ...m,
            gear: {
              ...m.gear,
              fuel: Math.min(st.gearMaxFuel, m.gear.fuel + 260),
            },
          }
        : m
    );
    setBattleParty(nextParty);
    setBattleLog(`${activeMember.gear.name} vents reactor coils and recovers +260 Fuel.`);
    window.setTimeout(() => advanceTurn(nextParty, enemies), 420);
  };

  const handleCastEther = (skillId: string) => {
    if (busy || !activeMember) return;
    const skill = activeMember.etherSkills.find((s) => s.id === skillId);
    if (!skill || activeMember.ep < skill.epCost) {
      AudioManager.playSfx('cancel');
      return;
    }
    setBusy(true);
    AudioManager.playSfx('ether');
    engineRef.current?.triggerPartyAction(activeMember.id, 'ether');

    const spendEpParty = battleParty.map((m) =>
      m.id === activeMember.id ? { ...m, ep: m.ep - skill.epCost } : m
    );

    if (skill.isHeal) {
      const healAmount = Math.round(getMemberStats(activeMember).ether * skill.power * 2.2);
      const healedParty = spendEpParty.map((m) => {
        if (m.hp <= 0) return m;
        const st = getMemberStats(m);
        return { ...m, hp: Math.min(st.maxHp, m.hp + healAmount) };
      });
      setBattleParty(healedParty);
      setBattleLog(`${activeMember.name} casts ${skill.name}, restoring +${healAmount} HP!`);
      window.setTimeout(() => advanceTurn(healedParty, enemies), 500);
      return;
    }

    const hitTargets =
      skill.target === 'all_enemies' ? enemies.filter((e) => e.hp > 0) : targetEnemy ? [targetEnemy] : [];
    let anyBreak = false;
    let lastDmg = 0;
    const nextEnemies = enemies.map((e) => {
      if (!hitTargets.some((t) => t.uid === e.uid)) return e;
      const res = resolveEtherSkill(
        activeMember,
        e,
        skill.power,
        skill.element,
        useBoost && memberBoost >= 3
      );
      lastDmg = res.damage;
      if (res.triggeredBreak) anyBreak = true;
      engineRef.current?.triggerEnemyHit(e.uid, res.triggeredBreak);
      return {
        ...e,
        hp: res.newHp,
        shield: res.newShield,
        brokenTurns: res.triggeredBreak ? 1 : e.brokenTurns,
        revealedWeaknesses:
          res.hitWeakness && !e.revealedWeaknesses.includes(skill.element)
            ? [...e.revealedWeaknesses, skill.element]
            : e.revealedWeaknesses,
      };
    });

    if (anyBreak) flashBreak(hitTargets[0]?.name ?? 'Enemy');
    setBattleParty(spendEpParty);
    setEnemies(nextEnemies);
    setBattleLog(
      `${activeMember.name} casts ${skill.name} (${skill.element}) for ${lastDmg} DMG!`
    );
    window.setTimeout(() => advanceTurn(spendEpParty, nextEnemies), 520);
  };

  const handleUseBattleItem = (itemId: string) => {
    if (busy || !activeMember) return;
    const def = ITEMS[itemId];
    if (!def?.effect) return;
    setBusy(true);
    AudioManager.playSfx('ether');
    consumeBattleItem(itemId);
    const nextParty = battleParty.map((m) => {
      if (!def.effect!.allParty && m.id !== activeMember.id && !(def.effect!.revive && m.hp <= 0)) {
        return m;
      }
      const st = getMemberStats(m);
      let hp = m.hp;
      let ep = m.ep;
      let gear = m.gear;
      if (def.effect!.revive && hp <= 0) hp = Math.min(st.maxHp, def.effect!.healHp ?? 120);
      else if (def.effect!.healHp && hp > 0) hp = Math.min(st.maxHp, hp + def.effect!.healHp);
      if (def.effect!.healEp) ep = Math.min(m.maxEp, ep + def.effect!.healEp);
      if (def.effect!.healFuel && gear) {
        gear = { ...gear, fuel: Math.min(st.gearMaxFuel, gear.fuel + def.effect!.healFuel) };
      }
      return { ...m, hp, ep, gear };
    });
    setBattleParty(nextParty);
    setBattleLog(`${activeMember.name} uses ${def.name}!`);
    window.setTimeout(() => advanceTurn(nextParty, enemies), 420);
  };

  const handleDefend = () => {
    if (busy || !activeMember) return;
    setBusy(true);
    AudioManager.playSfx('confirm');
    engineRef.current?.triggerPartyAction(activeMember.id, 'guard');
    setGuarding((g) => ({ ...g, [activeMember.id]: true }));
    setBoostGauge((b) => ({ ...b, [activeMember.id]: Math.min(7, (b[activeMember.id] ?? 0) + 2) }));
    setBattleLog(`${activeMember.name} takes a defensive stance (+2 Boost banked).`);
    window.setTimeout(() => advanceTurn(battleParty, enemies), 360);
  };

  const handleFlee = () => {
    if (busy || battleContext.isBoss) {
      AudioManager.playSfx('cancel');
      setBattleLog('Cannot retreat from a story boss battle!');
      return;
    }
    AudioManager.playSfx('door');
    completeBattleFlee(battleParty);
  };

  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-between overflow-hidden bg-[#080c15]">
      {/* 3D Side-View Octopath Battle Diorama */}
      <div
        ref={canvasRef}
        data-testid="battle-canvas-container"
        className="absolute inset-0 w-full h-full"
      />

      {/* Top Turn Order Timeline Bar (Next 8 Turns) */}
      <div className="relative z-10 safe-pad pb-0 flex flex-col items-center gap-1 pointer-events-none">
        <div className="jrpg-window-subtle px-2.5 py-1 flex items-center gap-1.5 pointer-events-auto max-w-full overflow-x-auto">
          <span className="font-display text-[10px] tracking-widest text-[#d4b06a] mr-1 whitespace-nowrap">
            TURN ORDER
          </span>
          {timeline.map((slot, idx) => (
            <div
              key={`${slot.uid}-${idx}`}
              className={`flex items-center gap-1 px-1.5 py-0.5 border text-[10px] whitespace-nowrap ${
                idx === 0
                  ? 'border-[#f5dfa3] bg-[#293552] text-white font-semibold'
                  : slot.side === 'enemy'
                    ? 'border-[#7a3f46] bg-[#211319] text-[#f0c2c6]'
                    : 'border-[#3a4969] bg-[#101829] text-[#cbd5e8]'
              }`}
            >
              <img
                src={SpriteSheetRegistry.getPortraitDataUrl(slot.spriteId as never)}
                alt={slot.name}
                className="w-5 h-5"
                style={{ imageRendering: 'pixelated' }}
              />
              <span className="hidden sm:inline">{slot.name.split(' ')[0]}</span>
            </div>
          ))}
        </div>

        {/* Combat Narrative Ticker */}
        <div className="jrpg-window-subtle px-3 py-0.5 text-[11px] sm:text-xs text-[#f2ead8] text-center max-w-2xl truncate">
          {battleLog}
        </div>
      </div>

      {/* Center BREAK Banner & Left Enemy Shield Plates */}
      <div className="relative z-10 flex-1 min-h-0 flex items-center justify-between px-3 sm:px-6 pointer-events-none">
        {/* Left Enemy Target Cards (Shield Points + Weakness Badges) */}
        <div className="flex flex-col gap-2 pointer-events-auto max-w-[230px] sm:max-w-[260px]">
          {enemies.map((e) => {
            const isTarget = e.uid === selectedEnemyUid;
            const dead = e.hp <= 0;
            return (
              <button
                key={e.uid}
                type="button"
                disabled={dead}
                onClick={() => {
                  AudioManager.playSfx('cursor');
                  setSelectedEnemyUid(e.uid);
                }}
                className={`text-left p-2.5 border transition-colors ${
                  dead
                    ? 'opacity-40 border-[#293040] bg-[#0a0d14]'
                    : isTarget
                      ? 'border-[#f2dca6] bg-[#182136]/95'
                      : 'border-[#4a556e] bg-[#0e1422]/90 hover:border-[#c9a86a]'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display text-xs text-[#f5e3ba] truncate">{e.name}</span>
                  <span
                    className={`font-mono-num text-[11px] px-1.5 py-0.5 border ${
                      e.brokenTurns > 0
                        ? 'border-[#ff7070] bg-[#4a181e] text-[#ffd4d4]'
                        : 'border-[#76b8e0] bg-[#10253b] text-[#bfe7ff]'
                    }`}
                  >
                    {e.brokenTurns > 0 ? 'BREAK!' : `SHD ${e.shield}`}
                  </span>
                </div>

                {/* Enemy HP Bar */}
                <div className="h-1.5 bg-[#1b2233] mt-1.5">
                  <div
                    className="h-full bg-[#c94a4a] transition-all"
                    style={{ width: `${Math.max(0, (e.hp / e.maxHp) * 100)}%` }}
                  />
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[10px] font-mono-num">
                  <div className="flex gap-1">
                    {e.weaknesses.map((w) => {
                      const known = e.revealedWeaknesses.includes(w);
                      return (
                        <span
                          key={w}
                          className={`px-1 border ${
                            known
                              ? 'border-[#d4b06a] text-[#f2dca6] bg-[#241e12]'
                              : 'border-[#333c4f] text-[#77849c]'
                          }`}
                        >
                          {known ? WEAKNESS_SHORT[w] : '?'}
                        </span>
                      );
                    })}
                  </div>
                  <span className="text-[#a9b6cf]">
                    {e.hp}/{e.maxHp}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Dramatic Octopath BREAK Overlay */}
        {breakBanner && (
          <div className="jrpg-window px-6 py-3 border-[#ff8b66] text-center animate-prologue-line">
            <div className="font-display text-lg sm:text-2xl tracking-[0.25em] text-[#ffe19c]">
              {breakBanner}
            </div>
          </div>
        )}

        {/* Right Party Mini Status Column */}
        <div className="flex flex-col gap-1 pointer-events-auto w-[158px] sm:w-[198px]">
          {battleParty
            .filter((p) => p.joined)
            .map((m) => {
              const st = getMemberStats(m);
              const isAct = activeMember?.id === m.id;
              const inGear = Boolean(boardedGears[m.id] && m.gear);
              const boost = boostGauge[m.id] ?? 0;
              return (
                <div
                  key={m.id}
                  className={`px-2 py-1 sm:p-1.5 border text-[10px] sm:text-[11px] font-mono-num ${
                    isAct
                      ? 'border-[#f5dfa3] bg-[#1c2640]/95'
                      : 'border-[#394561] bg-[#0d1322]/90'
                  }`}
                >
                  <div className="flex justify-between items-center leading-tight">
                    <span className="font-display text-[11px] sm:text-xs text-[#f5e3ba] truncate">
                      {m.name} {inGear ? `[${m.gear?.name}]` : ''}
                    </span>
                    <span className="text-[10px] text-[#e8c678] shrink-0">BST {boost}</span>
                  </div>
                  <div className="flex justify-between mt-0.5 text-[10px] leading-tight">
                    <span className="text-[#e08b8b]">
                      {inGear ? `F-HP ${m.gear?.frameHp}` : `HP ${m.hp}/${st.maxHp}`}
                    </span>
                    <span className="text-[#7ec3eb]">
                      {inGear ? `FUEL ${m.gear?.fuel}` : `EP ${m.ep}`}
                    </span>
                  </div>
                  <div className="h-1 bg-[#1b2233] mt-0.5">
                    <div
                      className="h-full bg-[#c44646]"
                      style={{
                        width: `${Math.min(
                          100,
                          inGear && m.gear
                            ? (m.gear.frameHp / st.gearMaxHp) * 100
                            : (m.hp / st.maxHp) * 100
                        )}%`,
                      }}
                    />
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      {/* Bottom Xenogears + Octopath Command Deck */}
      <div className="relative z-10 safe-pad pt-0 shrink-0">
        {activeMember && !victory ? (
          <div className="jrpg-window px-2.5 py-2 sm:p-3 flex flex-col gap-1.5 sm:gap-2 max-w-5xl mx-auto">
            {/* Active Character Status Line */}
            <div className="flex items-center justify-between gap-2 border-b border-[#d4b06a]/30 pb-1">
              <div className="flex items-center gap-2 min-w-0">
                <span className="font-display text-xs sm:text-sm tracking-wider text-[#f2dca6] whitespace-nowrap">
                  {activeMember.name}’S TURN
                </span>
                {!activeInGear ? (
                  <span className="font-mono-num text-[11px] sm:text-xs text-[#88c8eb] truncate">
                    AP: {remainingAp}/{MAX_TURN_AP} · Combo:{' '}
                    {comboSeq.length > 0 ? comboSeq.join(' + ') : 'None'}
                    {matchedDb ? ` → ★ ${matchedDb.name} (${matchedDb.element})` : ''}
                  </span>
                ) : (
                  <span className="font-mono-num text-[11px] sm:text-xs text-[#e8c678] truncate">
                    GEAR: {activeMember.gear?.name} · Fuel {activeMember.gear?.fuel} · Atk Lv.
                    {activeMember.gear?.attackLevel === 4 ? '∞' : activeMember.gear?.attackLevel}
                  </span>
                )}
              </div>
            </div>

            {/* Sub-Menus (Ether or Items) */}
            {subMenu === 'ether' && (
              <div className="flex flex-wrap gap-2 bg-[#0a0f1c] p-2 border border-[#3a4b6e]">
                {activeMember.etherSkills.map((sk) => (
                  <button
                    key={sk.id}
                    type="button"
                    disabled={activeMember.ep < sk.epCost}
                    onClick={() => handleCastEther(sk.id)}
                    className={`min-h-[48px] px-3 py-2 text-xs border text-left ${
                      activeMember.ep >= sk.epCost
                        ? 'border-[#6eb8e6] bg-[#11243b] text-[#e3f4ff] hover:bg-[#193554]'
                        : 'border-[#2f394d] text-[#6d7991] cursor-not-allowed'
                    }`}
                  >
                    <span className="font-display">{sk.name}</span>{' '}
                    <span className="font-mono-num text-[11px] text-[#88c8eb]">
                      ({sk.epCost} EP · {sk.element})
                    </span>
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setSubMenu('none')}
                  className="min-h-[48px] px-3.5 py-2 text-xs border border-[#525e78] text-[#b4bfd4]"
                >
                  Back
                </button>
              </div>
            )}

            {subMenu === 'item' && (
              <div className="flex flex-wrap gap-2 bg-[#0a0f1c] p-2 border border-[#3a4b6e]">
                {inventory
                  .filter((e) => ITEMS[e.itemId]?.category === 'consumable')
                  .map((e) => {
                    const def = ITEMS[e.itemId];
                    return (
                      <button
                        key={e.itemId}
                        type="button"
                        onClick={() => handleUseBattleItem(e.itemId)}
                        className="min-h-[48px] px-3 py-2 text-xs border border-[#d4b06a]/70 bg-[#171d2e] text-[#f5e3ba] hover:bg-[#232d47]"
                      >
                        {def.name} (x{e.quantity})
                      </button>
                    );
                  })}
                <button
                  type="button"
                  onClick={() => setSubMenu('none')}
                  className="min-h-[48px] px-3.5 py-2 text-xs border border-[#525e78] text-[#b4bfd4]"
                >
                  Back
                </button>
              </div>
            )}

            {/* Main Action Buttons: Single-Row Scrollable 48px+ Touch Deck (On-Foot OR Gear Combat) */}
            {!activeInGear ? (
              <div className="flex flex-nowrap lg:flex-wrap items-center gap-1.5 sm:gap-2 overflow-x-auto pb-0.5">
                <button
                  type="button"
                  disabled={busy || remainingAp < 1}
                  onClick={() => handleQueueAp('T')}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#6eb8e6]/80 bg-[#112238] text-[#dff2ff] hover:bg-[#1a3454] disabled:opacity-40 whitespace-nowrap"
                >
                  Weak [T · 1 AP]
                </button>
                <button
                  type="button"
                  disabled={busy || remainingAp < 2}
                  onClick={() => handleQueueAp('S')}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#d4b06a]/85 bg-[#241d11] text-[#fff0cc] hover:bg-[#382d1a] disabled:opacity-40 whitespace-nowrap"
                >
                  Med [S · 2 AP]
                </button>
                <button
                  type="button"
                  disabled={busy || remainingAp < 3}
                  onClick={() => handleQueueAp('X')}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#e06c6c]/85 bg-[#2b1318] text-[#ffe0e0] hover:bg-[#421d24] disabled:opacity-40 whitespace-nowrap"
                >
                  Strong [X · 3 AP]
                </button>

                <button
                  type="button"
                  disabled={busy || comboSeq.length === 0}
                  onClick={handleExecuteCombo}
                  className="min-h-[48px] shrink-0 px-3.5 py-2 text-xs font-display tracking-wider border border-[#f5dfa3] bg-[#d4b06a]/30 text-[#fff8e6] hover:bg-[#d4b06a]/45 disabled:opacity-40 whitespace-nowrap"
                >
                  {matchedDb ? `Unleash ${matchedDb.name}!` : 'Execute Combo'}
                </button>

                {comboSeq.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setComboSeq([])}
                    className="min-h-[48px] shrink-0 px-3 py-2 text-xs border border-[#4f5d7a] text-[#b4bfd4]"
                  >
                    Clear
                  </button>
                )}

                <button
                  type="button"
                  disabled={memberBoost < 3}
                  onClick={() => {
                    AudioManager.playSfx('confirm');
                    setUseBoost((b) => !b);
                  }}
                  className={`min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border whitespace-nowrap ${
                    useBoost
                      ? 'border-[#ffe28a] bg-[#664b17] text-white'
                      : 'border-[#5a6680] text-[#b8c4db] disabled:opacity-40'
                  }`}
                >
                  Boost {useBoost ? 'ON' : '(3 BST)'}
                </button>

                <button
                  type="button"
                  onClick={() => setSubMenu(subMenu === 'ether' ? 'none' : 'ether')}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#5a8cc4] text-[#cfe8ff] hover:bg-[#19304d] whitespace-nowrap"
                >
                  Ether
                </button>
                <button
                  type="button"
                  onClick={() => setSubMenu(subMenu === 'item' ? 'none' : 'item')}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#6ca67a] text-[#d5f5dc] hover:bg-[#1b3622] whitespace-nowrap"
                >
                  Items
                </button>
                {battleContext.allowGears && activeMember.gear && activeMember.gear.frameHp > 0 && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => {
                      AudioManager.playSfx('switch');
                      setComboSeq([]);
                      setBoardedGears((prev) => ({
                        ...prev,
                        [activeMember.id]: true,
                      }));
                    }}
                    className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#e3c078] bg-[#2a2314] text-[#ffe8ad] hover:bg-[#3d331d] whitespace-nowrap"
                  >
                    Board {activeMember.gear.name}
                  </button>
                )}
                <button
                  type="button"
                  disabled={busy}
                  onClick={handleDefend}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#4f5d7a] text-[#cbd5e8] hover:border-[#d4b06a] whitespace-nowrap"
                >
                  Defend
                </button>
                {!battleContext.isBoss && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleFlee}
                    className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#7d4949] text-[#e8b8b8] hover:bg-[#7d4949]/25 whitespace-nowrap"
                  >
                    Flee
                  </button>
                )}
              </div>
            ) : (
              <div className="flex flex-nowrap lg:flex-wrap items-center gap-1.5 sm:gap-2 overflow-x-auto pb-0.5">
                {([1, 2, 3, 4] as const).map((lvl) => {
                  const unlocked = (activeMember.gear?.attackLevel ?? 1) >= lvl;
                  return (
                    <button
                      key={lvl}
                      type="button"
                      disabled={busy || !unlocked}
                      onClick={() => handleGearAttack(lvl)}
                      className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#e3c078] bg-[#241e12] text-[#fff0cc] hover:bg-[#3b301c] disabled:opacity-35 whitespace-nowrap"
                    >
                      {lvl === 4 ? 'Infinity Mode [∞]' : `Gear Attack Lv.${lvl}`}
                    </button>
                  );
                })}
                <button
                  type="button"
                  disabled={busy}
                  onClick={handleGearCharge}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#6eb8e6] bg-[#12263d] text-[#dcf2ff] hover:bg-[#1b3859] whitespace-nowrap"
                >
                  Charge (+260 Fuel)
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    AudioManager.playSfx('switch');
                    setBattleParty((prev) =>
                      prev.map((m) =>
                        m.id === activeMember.id && m.gear
                          ? { ...m, gear: { ...m.gear, boosterActive: !m.gear.boosterActive } }
                          : m
                      )
                    );
                  }}
                  className={`min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border whitespace-nowrap ${
                    activeMember.gear?.boosterActive
                      ? 'border-[#ff9c66] bg-[#4a2216] text-[#ffe8db]'
                      : 'border-[#5a6680] text-[#b8c4db]'
                  }`}
                >
                  Booster: {activeMember.gear?.boosterActive ? 'ON' : 'OFF'}
                </button>
                <button
                  type="button"
                  onClick={() => setSubMenu(subMenu === 'item' ? 'none' : 'item')}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#6ca67a] text-[#d5f5dc] whitespace-nowrap"
                >
                  Items
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    AudioManager.playSfx('switch');
                    setComboSeq([]);
                    setBoardedGears((prev) => ({
                      ...prev,
                      [activeMember.id]: false,
                    }));
                  }}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#e3c078] bg-[#2a2314] text-[#ffe8ad] hover:bg-[#3d331d] whitespace-nowrap"
                >
                  Dismount Gear
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={handleDefend}
                  className="min-h-[48px] shrink-0 px-3 py-2 text-xs font-display border border-[#4f5d7a] text-[#cbd5e8] hover:border-[#d4b06a] whitespace-nowrap"
                >
                  Defend
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="jrpg-window-subtle max-w-md mx-auto py-2 px-4 text-center text-xs font-display tracking-widest text-[#d4b06a]">
            {victory ? 'VICTORY ACHIEVED' : 'ENEMY TURN...'}
          </div>
        )}
      </div>

      {/* Victory Summary Modal */}
      {victory && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center safe-pad">
          <div className="jrpg-window w-full max-w-lg p-5 flex flex-col gap-3.5 animate-prologue-line">
            <h2 className="font-display text-xl tracking-[0.24em] text-[#f5e3ba] text-center border-b border-[#d4b06a]/35 pb-2">
              VICTORY
            </h2>
            <div className="grid grid-cols-2 gap-3 font-mono-num text-sm">
              <div className="bg-[#0c1220] border border-[#323e57] p-3 text-center">
                <div className="text-[11px] text-[#9eb0cc]">EXPERIENCE</div>
                <div className="text-lg text-[#f2dca6]">+{victory.totalXp} XP</div>
              </div>
              <div className="bg-[#0c1220] border border-[#323e57] p-3 text-center">
                <div className="text-[11px] text-[#9eb0cc]">SPOILS</div>
                <div className="text-lg text-[#e8c678]">+{victory.totalGil} G</div>
              </div>
            </div>

            {victory.levelUps.length > 0 && (
              <div className="bg-[#18243b] border border-[#e3c078] p-2.5 text-xs text-[#fff4d8]">
                LEVEL UP!{' '}
                {victory.levelUps.map((lu) => `${lu.name} reached Lv.${lu.newLevel}`).join(' · ')}
              </div>
            )}

            {victory.drops.length > 0 && (
              <div className="text-xs text-[#c7d1e3]">
                Items Recovered:{' '}
                <span className="text-[#f2dca6]">
                  {victory.drops.map((id) => ITEMS[id]?.name ?? id).join(', ')}
                </span>
              </div>
            )}

            <button
              type="button"
              onClick={() => {
                AudioManager.playSfx('confirm');
                completeBattleVictory(
                  victory.updatedParty,
                  victory.totalGil,
                  victory.drops,
                  battleContext.victoryFlag
                );
              }}
              className="mt-1 min-h-[48px] py-2.5 font-display text-sm tracking-[0.2em] border border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df] hover:bg-[#d4b06a]/40"
            >
              Return to Field
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
