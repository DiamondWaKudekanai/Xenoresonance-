import React, { useEffect, useState } from 'react';
import { DEATHBLOWS, ITEMS } from '../data/itemsAndGear';
import { MAP_REGISTRY } from '../data/maps/mapRegistry';
import { SPRITE_MANIFEST, TILE_ASSET_SLOTS } from '../data/spriteManifest';
import { EPISODE3_QUESTS, getActiveQuest } from '../data/storyEpisode3';
import { AudioManager, OSTSlotInfo } from '../engine/AudioManager';
import { getMemberStats } from '../engine/CombatRules';
import { useGameState } from '../engine/GameStateContext';
import { PixelTextureFactory } from '../engine/PixelTextureFactory';
import { formatPlaytime } from '../engine/SaveManager';
import { SpriteSheetRegistry } from '../engine/SpriteAnimator';
import { GraphicsQuality, MapId, OSTTrackId, PartyMember } from '../types/rpg';

type MenuTab =
  | 'party'
  | 'items'
  | 'equip'
  | 'deathblows'
  | 'gears'
  | 'quests'
  | 'travel'
  | 'save'
  | 'config';

export const MainMenu: React.FC = () => {
  const {
    gameState,
    activeOverlay,
    setActiveOverlay,
    party,
    inventory,
    gil,
    playtimeSeconds,
    questFlags,
    visitedMaps,
    mapId,
    saveSlots,
    config,
    saveToSlot,
    continueFromSlot,
    deleteSaveSlot,
    exportSlotJson,
    importSlotJson,
    updateAudioConfig,
    setGraphicsQuality,
    setShowTouchControls,
    useConsumableItem,
    equipItem,
    swapPartyFormation,
    warpToMap,
    returnToTitle,
    showToast,
  } = useGameState();

  const [tab, setTab] = useState<MenuTab>('party');
  const [selectedCharIdx, setSelectedCharIdx] = useState(0);
  const [ostSlots, setOstSlots] = useState<OSTSlotInfo[]>(() => AudioManager.getSlotStatuses());
  const [activeTrackFile, setActiveTrackFile] = useState(() => AudioManager.getActiveSlotLabel());
  const [importText, setImportText] = useState('');
  const [importError, setImportError] = useState<string | null>(null);
  const [assetRefreshTick, setAssetRefreshTick] = useState(0);

  useEffect(() => {
    const unsub = AudioManager.subscribe(() => {
      setOstSlots(AudioManager.getSlotStatuses());
      setActiveTrackFile(AudioManager.getActiveSlotLabel());
    });
    return unsub;
  }, []);

  // Sync default tab when opened directly via Memory Cube or Title Config
  useEffect(() => {
    if (activeOverlay === 'save_menu') setTab('save');
    else if (activeOverlay === 'config_modal') setTab('config');
  }, [activeOverlay]);

  if (
    activeOverlay !== 'main_menu' &&
    activeOverlay !== 'save_menu' &&
    activeOverlay !== 'config_modal'
  ) {
    return null;
  }

  const isTitleConfig = gameState === 'TITLE_SCREEN' && activeOverlay === 'config_modal';
  const selectedMember: PartyMember = party[selectedCharIdx] ?? party[0];
  const activeQuest = getActiveQuest(questFlags);

  const tabs: Array<{ id: MenuTab; label: string }> = isTitleConfig
    ? [{ id: 'config', label: 'Config & Assets' }]
    : [
        { id: 'party', label: 'Party' },
        { id: 'items', label: 'Items' },
        { id: 'equip', label: 'Equip' },
        { id: 'deathblows', label: 'Deathblows' },
        { id: 'gears', label: 'Gears' },
        { id: 'quests', label: 'Quests' },
        { id: 'travel', label: 'Fast Travel' },
        { id: 'save', label: 'Save / Load' },
        { id: 'config', label: 'Config' },
      ];

  const handleDownloadJson = (slotId: 1 | 2 | 3) => {
    const json = exportSlotJson(slotId);
    if (!json) return;
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `xenogears_ep3_slot_${slotId}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Exported Slot ${slotId} JSON.`);
  };

  const handleImportSubmit = (slotId: 1 | 2 | 3) => {
    setImportError(null);
    if (!importText.trim()) {
      setImportError('Paste a valid Save JSON payload before importing.');
      return;
    }
    const res = importSlotJson(slotId, importText);
    if (!res.ok) {
      setImportError(res.error ?? 'Import failed.');
    } else {
      setImportText('');
    }
  };

  return (
    <div className="fixed inset-0 z-40 bg-black/78 flex items-center justify-center safe-pad">
      <div className="jrpg-window w-full max-w-5xl h-[90dvh] flex flex-col p-3.5 sm:p-5 gap-3">
        {/* Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#d4b06a]/35 pb-2">
          <div className="flex items-baseline gap-3">
            <h2 className="font-display text-sm sm:text-base tracking-[0.2em] text-[#f2dca6]">
              {isTitleConfig ? 'SYSTEM CONFIGURATION' : 'NISAN CHRONICLE MENU'}
            </h2>
            {!isTitleConfig && (
              <span className="font-mono-num text-xs text-[#a9b6cf]">
                {formatPlaytime(playtimeSeconds)} · {gil} G
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {!isTitleConfig && (
              <button
                type="button"
                onClick={returnToTitle}
                className="min-h-[48px] px-3.5 py-2 text-xs border border-[#8c4b4b]/70 text-[#e8b4b4] hover:bg-[#8c4b4b]/25 whitespace-nowrap"
              >
                Title Screen
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                AudioManager.playSfx('cancel');
                setActiveOverlay(null);
              }}
              className="min-h-[48px] px-4 py-2 text-xs font-display tracking-wider border border-[#d4b06a]/70 text-[#f2dca6] hover:bg-[#d4b06a]/20 whitespace-nowrap"
            >
              Close
            </button>
          </div>
        </div>

        {/* Touch-Friendly Horizontal Tabs (>= 48px hit targets) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 shrink-0">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                AudioManager.playSfx('cursor');
                setTab(t.id);
              }}
              className={`min-h-[48px] px-3.5 py-2 text-xs font-display tracking-wider border whitespace-nowrap shrink-0 transition-colors ${
                tab === t.id
                  ? 'border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df]'
                  : 'border-[#333f59] bg-[#0e1422] text-[#a9b6cf] hover:border-[#8a7246]'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Main Content Body */}
        <div className="flex-1 min-h-0 overflow-y-auto jrpg-scroll pr-1">
          {/* TAB 1: PARTY STATUS & FORMATION */}
          {tab === 'party' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {party.map((m, idx) => {
                const st = getMemberStats(m);
                const portrait = SpriteSheetRegistry.getPortraitDataUrl(m.spriteId);
                return (
                  <div
                    key={m.id}
                    className="bg-[#0d1322] border border-[#d4b06a]/40 p-3.5 flex items-start gap-3"
                  >
                    <img
                      src={portrait}
                      alt={m.name}
                      className="w-14 h-14 border border-[#d4b06a]/60 bg-[#090d17] shrink-0"
                      style={{ imageRendering: 'pixelated' }}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <span className="font-display text-sm text-[#f5e3ba]">{m.name}</span>
                          <span className="ml-2 text-[11px] text-[#9aa8c2]">{m.title}</span>
                        </div>
                        <span className="font-mono-num text-xs text-[#e3c078]">Lv.{m.level}</span>
                      </div>

                      <div className="mt-2 grid grid-cols-2 gap-2 text-xs font-mono-num">
                        <div>
                          <div className="flex justify-between text-[11px]">
                            <span className="text-[#d48b8b]">HP</span>
                            <span>
                              {m.hp}/{st.maxHp}
                            </span>
                          </div>
                          <div className="h-1.5 bg-[#1b2233] mt-0.5">
                            <div
                              className="h-full bg-[#c44646]"
                              style={{ width: `${Math.min(100, (m.hp / st.maxHp) * 100)}%` }}
                            />
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between text-[11px]">
                            <span className="text-[#82bce6]">EP</span>
                            <span>
                              {m.ep}/{m.maxEp}
                            </span>
                          </div>
                          <div className="h-1.5 bg-[#1b2233] mt-0.5">
                            <div
                              className="h-full bg-[#3c86b8]"
                              style={{ width: `${Math.min(100, (m.ep / m.maxEp) * 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono-num text-[#b4bfd4]">
                        <span>
                          ATK {st.atk} · DEF {st.def} · ETH {st.ether} · SPD {st.spd}
                        </span>
                        {idx > 0 && (
                          <button
                            type="button"
                            onClick={() => swapPartyFormation(0, idx)}
                            className="px-2 py-0.5 border border-[#d4b06a]/50 text-[#f2dca6] hover:bg-[#d4b06a]/20"
                          >
                            Make Leader
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 2: INVENTORY & HEALING */}
          {tab === 'items' && (
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              <div className="md:col-span-3 flex flex-col gap-1.5">
                {inventory.length === 0 ? (
                  <p className="text-xs text-[#9aa8c2] p-3">Inventory is empty.</p>
                ) : (
                  inventory.map((entry) => {
                    const def = ITEMS[entry.itemId];
                    if (!def) return null;
                    return (
                      <div
                        key={entry.itemId}
                        className="bg-[#0e1422] border border-[#303d57] p-2.5 flex items-center justify-between gap-2"
                      >
                        <div>
                          <div className="text-xs sm:text-sm text-[#f2ead8]">
                            {def.name}{' '}
                            <span className="font-mono-num text-xs text-[#e3c078]">
                              x{entry.quantity}
                            </span>
                          </div>
                          <div className="text-[11px] text-[#9eb0cc]">{def.description}</div>
                        </div>
                        {def.category === 'consumable' && (
                          <button
                            type="button"
                            onClick={() => useConsumableItem(def.id, selectedMember.id)}
                            className="px-3 py-1 text-xs font-display border border-[#d4b06a]/70 text-[#f2dca6] hover:bg-[#d4b06a]/20 whitespace-nowrap"
                          >
                            Use on {selectedMember.name}
                          </button>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
              <div className="md:col-span-2 bg-[#0c111e] border border-[#d4b06a]/30 p-3 flex flex-col gap-2">
                <span className="text-[11px] font-display tracking-wider text-[#d4b06a]">
                  TARGET ALLY FOR HEALING
                </span>
                {party.map((m, idx) => {
                  const st = getMemberStats(m);
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setSelectedCharIdx(idx)}
                      className={`text-left p-2 border text-xs flex justify-between font-mono-num ${
                        idx === selectedCharIdx
                          ? 'border-[#f2dca6] bg-[#1b263d] text-white'
                          : 'border-[#2f3b54] text-[#b4bfd4]'
                      }`}
                    >
                      <span>{m.name}</span>
                      <span>
                        HP {m.hp}/{st.maxHp} · EP {m.ep}/{m.maxEp}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: EQUIPMENT */}
          {tab === 'equip' && (
            <div className="flex flex-col gap-3">
              <div className="flex gap-2">
                {party.map((m, idx) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setSelectedCharIdx(idx)}
                    className={`px-3 py-1.5 text-xs font-display border ${
                      idx === selectedCharIdx
                        ? 'border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df]'
                        : 'border-[#333f59] text-[#a9b6cf]'
                    }`}
                  >
                    {m.name}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-[#0d1322] border border-[#d4b06a]/35 p-3.5 space-y-2 text-xs">
                  <h3 className="font-display text-sm text-[#f2dca6]">
                    Equipped — {selectedMember.name}
                  </h3>
                  <div className="flex justify-between py-1 border-b border-[#253047]">
                    <span className="text-[#9eb0cc]">Weapon</span>
                    <span>{selectedMember.weaponId ? ITEMS[selectedMember.weaponId]?.name : 'None'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-[#253047]">
                    <span className="text-[#9eb0cc]">Armor</span>
                    <span>{selectedMember.armorId ? ITEMS[selectedMember.armorId]?.name : 'None'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-[#253047]">
                    <span className="text-[#9eb0cc]">Accessory</span>
                    <span>
                      {selectedMember.accessoryId ? ITEMS[selectedMember.accessoryId]?.name : 'None'}
                    </span>
                  </div>
                  {(() => {
                    const st = getMemberStats(selectedMember);
                    return (
                      <div className="pt-1 font-mono-num text-[#d4b06a]">
                        ATK {st.atk} · DEF {st.def} · ETHER {st.ether} · SPD {st.spd}
                      </div>
                    );
                  })()}
                </div>

                <div className="bg-[#0d1322] border border-[#303d57] p-3.5 space-y-1.5">
                  <h3 className="font-display text-xs tracking-wider text-[#d4b06a] mb-2">
                    AVAILABLE EQUIPMENT IN BAG
                  </h3>
                  {inventory
                    .filter((e) => {
                      const c = ITEMS[e.itemId]?.category;
                      return c === 'weapon' || c === 'armor' || c === 'accessory' || c === 'gear_part';
                    })
                    .map((entry) => {
                      const def = ITEMS[entry.itemId];
                      return (
                        <div
                          key={entry.itemId}
                          className="flex items-center justify-between gap-2 p-2 border border-[#2a364f] bg-[#0a0f1c] text-xs"
                        >
                          <div>
                            <div className="text-[#f2ead8]">
                              {def.name} (x{entry.quantity})
                            </div>
                            <div className="text-[10px] text-[#9eb0cc]">{def.description}</div>
                          </div>
                          <button
                            type="button"
                            onClick={() => equipItem(selectedMember.id, def.id)}
                            className="px-2.5 py-1 border border-[#d4b06a]/70 text-[#f2dca6] hover:bg-[#d4b06a]/20 whitespace-nowrap"
                          >
                            Equip
                          </button>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: DEATHBLOW MASTERY TREE */}
          {tab === 'deathblows' && (
            <div className="flex flex-col gap-3">
              <div className="flex gap-2">
                {party.map((m, idx) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setSelectedCharIdx(idx)}
                    className={`px-3 py-1.5 text-xs font-display border ${
                      idx === selectedCharIdx
                        ? 'border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df]'
                        : 'border-[#333f59] text-[#a9b6cf]'
                    }`}
                  >
                    {m.name}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {DEATHBLOWS.map((db) => {
                  const pct = selectedMember.deathblowMastery[db.id] ?? 0;
                  const unlocked = selectedMember.level >= db.requiredLevel;
                  return (
                    <div
                      key={db.id}
                      className="bg-[#0d1322] border border-[#d4b06a]/35 p-3 flex flex-col gap-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-display text-sm text-[#f2dca6]">{db.name}</span>
                        <span className="font-mono-num text-xs text-[#82bce6]">
                          {db.sequence.join(' + ')} · {db.apCost} AP
                        </span>
                      </div>
                      <p className="text-xs text-[#b4bfd4]">{db.description}</p>
                      <div className="flex items-center justify-between text-[11px] font-mono-num mt-1">
                        <span className="text-[#c9b285]">
                          {unlocked ? `Element: ${db.element}` : `Unlocks at Lv.${db.requiredLevel}`}
                        </span>
                        <span className="text-[#f2dca6]">Mastery {pct}%</span>
                      </div>
                      <div className="h-1.5 bg-[#1b2233]">
                        <div className="h-full bg-[#d4b06a]" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: GEAR HANGAR */}
          {tab === 'gears' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {party.map((m) => {
                if (!m.gear) return null;
                const st = getMemberStats(m);
                const gPortrait = SpriteSheetRegistry.getPortraitDataUrl(m.gear.spriteId);
                return (
                  <div
                    key={m.gear.id}
                    className="bg-[#0d1322] border border-[#d4b06a]/45 p-3.5 flex items-start gap-3"
                  >
                    <img
                      src={gPortrait}
                      alt={m.gear.name}
                      className="w-16 h-16 border border-[#d4b06a]/60 bg-[#090d17] shrink-0"
                      style={{ imageRendering: 'pixelated' }}
                    />
                    <div className="flex-1 text-xs space-y-1.5">
                      <div className="flex justify-between items-baseline">
                        <span className="font-display text-sm text-[#f2dca6]">{m.gear.name}</span>
                        <span className="text-[11px] text-[#9eb0cc]">Pilot: {m.name}</span>
                      </div>
                      <div className="font-mono-num text-[#d8e1f0]">
                        Frame HP: {m.gear.frameHp}/{st.gearMaxHp} · Fuel: {m.gear.fuel}/{st.gearMaxFuel}
                      </div>
                      <div className="font-mono-num text-[#b4bfd4]">
                        Gear ATK {st.gearAtk} · Gear DEF {st.gearDef}
                      </div>
                      <div className="text-[11px] text-[#c9b285]">
                        Frame Part:{' '}
                        {m.gear.equippedPartId ? ITEMS[m.gear.equippedPartId]?.name : 'Standard Issue'}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 6: QUEST LOG */}
          {tab === 'quests' && (
            <div className="space-y-3">
              <div className="bg-[#141d32] border border-[#e3c078] p-4">
                <div className="text-[11px] font-display tracking-widest text-[#d4b06a]">
                  CURRENT OBJECTIVE
                </div>
                <h3 className="font-display text-base text-[#fff4d8] mt-1">{activeQuest.title}</h3>
                <p className="font-serif-jp text-base text-[#ddd4c3] mt-1">{activeQuest.summary}</p>
              </div>
              <div className="space-y-2">
                {EPISODE3_QUESTS.map((q) => {
                  const done = Boolean(q.completedFlag && questFlags[q.completedFlag]);
                  return (
                    <div
                      key={q.id}
                      className="bg-[#0d1322] border border-[#2f3b54] p-3 flex items-start justify-between gap-3"
                    >
                      <div>
                        <div className="font-display text-xs text-[#f2dca6]">{q.title}</div>
                        <p className="text-xs text-[#a9b6cf] mt-0.5">{q.summary}</p>
                      </div>
                      <span
                        className={`font-mono-num text-[11px] whitespace-nowrap ${
                          done ? 'text-[#6be09a]' : 'text-[#8e9cb5]'
                        }`}
                      >
                        {done ? 'Completed' : 'In Progress'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 7: FAST TRAVEL */}
          {tab === 'travel' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {(Object.keys(MAP_REGISTRY) as MapId[]).map((id) => {
                const m = MAP_REGISTRY[id];
                const isHere = id === mapId;
                const visited = visitedMaps.includes(id);
                return (
                  <button
                    key={id}
                    type="button"
                    disabled={isHere}
                    onClick={() => {
                      setActiveOverlay(null);
                      warpToMap(id, m.defaultSpawn.x, m.defaultSpawn.z, m.defaultSpawn.facing);
                    }}
                    className={`text-left p-3.5 border transition-colors ${
                      isHere
                        ? 'border-[#e3c078] bg-[#1a253d]'
                        : 'border-[#333f59] bg-[#0e1422] hover:border-[#d4b06a]'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-display text-sm text-[#f2dca6]">{m.name}</span>
                      <span className="font-mono-num text-[11px] text-[#9eb0cc]">
                        {isHere ? 'Current' : visited ? 'Fast Travel' : 'Deploy'}
                      </span>
                    </div>
                    <p className="text-xs text-[#9eb0cc] mt-1">{m.subtitle}</p>
                  </button>
                );
              })}
            </div>
          )}

          {/* TAB 8: SAVE / LOAD (3 SLOTS + JSON EXPORT/IMPORT) */}
          {tab === 'save' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 gap-2.5">
                {([1, 2, 3] as const).map((slotId) => {
                  const slot = saveSlots[slotId - 1];
                  return (
                    <div
                      key={slotId}
                      className="bg-[#0d1322] border border-[#d4b06a]/45 p-3.5 flex flex-wrap items-center justify-between gap-3"
                    >
                      <div>
                        <div className="font-display text-sm text-[#f2dca6]">
                          Save Slot {slotId} — {slot ? slot.locationName : 'Empty'}
                        </div>
                        {slot ? (
                          <div className="text-xs text-[#a9b6cf] font-mono-num mt-0.5">
                            {formatPlaytime(slot.playtimeSeconds)} · {slot.gil} G · Tile (
                            {Math.round(slot.playerX)}, {Math.round(slot.playerZ)}) · Chests:{' '}
                            {slot.openedChests.length}
                          </div>
                        ) : (
                          <div className="text-xs text-[#7d8aa3] mt-0.5">No archive recorded yet.</div>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => saveToSlot(slotId)}
                          className="px-3 py-1.5 text-xs font-display border border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df] hover:bg-[#d4b06a]/40"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          disabled={!slot}
                          onClick={() => slot && continueFromSlot(slotId)}
                          className={`px-3 py-1.5 text-xs font-display border ${
                            slot
                              ? 'border-[#7cb8e0]/70 text-[#cfeaff] hover:bg-[#7cb8e0]/20'
                              : 'border-[#333c52] text-[#6d7891] cursor-not-allowed'
                          }`}
                        >
                          Load
                        </button>
                        <button
                          type="button"
                          disabled={!slot}
                          onClick={() => handleDownloadJson(slotId)}
                          className={`px-2.5 py-1.5 text-xs border ${
                            slot
                              ? 'border-[#5a6985] text-[#c7d2e6] hover:border-[#d4b06a]'
                              : 'border-[#2c3447] text-[#646f87] cursor-not-allowed'
                          }`}
                        >
                          Export JSON
                        </button>
                        {slot && (
                          <button
                            type="button"
                            onClick={() => deleteSaveSlot(slotId)}
                            className="px-2.5 py-1.5 text-xs border border-[#8c4b4b]/60 text-[#e8b4b4] hover:bg-[#8c4b4b]/25"
                          >
                            Clear
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* JSON Import Utility */}
              <div className="bg-[#0b101c] border border-[#303d57] p-3.5 space-y-2">
                <label
                  htmlFor="save-import-json"
                  className="block font-display text-xs tracking-wider text-[#d4b06a]"
                >
                  IMPORT SAVE JSON INTO SLOT
                </label>
                <textarea
                  id="save-import-json"
                  rows={3}
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder='Paste exported JSON save data here...'
                  className="w-full bg-[#070b14] border border-[#3a4763] p-2 text-xs font-mono-num text-[#dce4f2] focus:outline-none focus:border-[#d4b06a]"
                />
                {importError && <p className="text-xs text-[#eb7575]">{importError}</p>}
                <div className="flex gap-2">
                  {([1, 2, 3] as const).map((slotId) => (
                    <button
                      key={slotId}
                      type="button"
                      onClick={() => handleImportSubmit(slotId)}
                      className="px-3 py-1 text-xs border border-[#d4b06a]/60 text-[#f2dca6] hover:bg-[#d4b06a]/20"
                    >
                      Import → Slot {slotId}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: CONFIG — AUDIO, OST SLOTS, GRAPHICS QUALITY & ASSET DROP-IN INSPECTOR */}
          {tab === 'config' && (
            <div className="space-y-4">
              {/* Volume & Graphics Settings */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-[#0d1322] border border-[#d4b06a]/35 p-3.5 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-xs tracking-widest text-[#f2dca6]">
                      AUDIO MIXER
                    </h3>
                    <button
                      type="button"
                      onClick={() => updateAudioConfig({ muted: !config.audio.muted })}
                      className="px-2.5 py-1 text-xs border border-[#d4b06a]/60 text-[#f2dca6]"
                    >
                      {config.audio.muted ? 'Unmute All' : 'Mute All'}
                    </button>
                  </div>

                  <div>
                    <label
                      htmlFor="bgm-slider"
                      className="flex justify-between text-xs text-[#c7d1e3] mb-1"
                    >
                      <span>BGM Volume</span>
                      <span className="font-mono-num">{Math.round(config.audio.bgmVolume * 100)}%</span>
                    </label>
                    <input
                      id="bgm-slider"
                      type="range"
                      min={0}
                      max={100}
                      value={Math.round(config.audio.bgmVolume * 100)}
                      onChange={(e) =>
                        updateAudioConfig({ bgmVolume: Number(e.target.value) / 100 })
                      }
                      className="w-full accent-[#d4b06a]"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="sfx-slider"
                      className="flex justify-between text-xs text-[#c7d1e3] mb-1"
                    >
                      <span>SFX Volume</span>
                      <span className="font-mono-num">{Math.round(config.audio.sfxVolume * 100)}%</span>
                    </label>
                    <input
                      id="sfx-slider"
                      type="range"
                      min={0}
                      max={100}
                      value={Math.round(config.audio.sfxVolume * 100)}
                      onChange={(e) => {
                        updateAudioConfig({ sfxVolume: Number(e.target.value) / 100 });
                        AudioManager.playSfx('cursor');
                      }}
                      className="w-full accent-[#d4b06a]"
                    />
                  </div>

                  <p className="text-[11px] font-mono-num text-[#9eb0cc] pt-1 border-t border-[#253047]">
                    Active OST Track Slot: <span className="text-[#f2dca6]">{activeTrackFile}</span>
                  </p>
                </div>

                {/* Android GPU Quality & Touch HUD */}
                <div className="bg-[#0d1322] border border-[#d4b06a]/35 p-3.5 space-y-3">
                  <h3 className="font-display text-xs tracking-widest text-[#f2dca6]">
                    ANDROID GRAPHICS & CONTROLS
                  </h3>
                  <div>
                    <span className="block text-xs text-[#c7d1e3] mb-1.5">
                      Graphics Quality (Shadows / Particles / DoF)
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['low', 'medium', 'high'] as GraphicsQuality[]).map((q) => (
                        <button
                          key={q}
                          type="button"
                          onClick={() => {
                            AudioManager.playSfx('cursor');
                            setGraphicsQuality(q);
                          }}
                          className={`py-1.5 text-xs font-display uppercase border ${
                            config.graphicsQuality === q
                              ? 'border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df]'
                              : 'border-[#333f59] text-[#a9b6cf]'
                          }`}
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-[#253047]">
                    <span className="text-xs text-[#c7d1e3]">On-Screen Virtual Controls</span>
                    <button
                      type="button"
                      onClick={() => setShowTouchControls(!config.showTouchControls)}
                      className="px-3 py-1 text-xs border border-[#d4b06a]/60 text-[#f2dca6]"
                    >
                      {config.showTouchControls ? 'Visible' : 'Hidden'}
                    </button>
                  </div>
                </div>
              </div>

              {/* OST Track Slot Table (/public/audio/ost/) */}
              <div className="bg-[#0d1322] border border-[#303d57] p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-xs tracking-widest text-[#f2dca6]">
                    CUSTOM OST TRACK SLOTS (/public/audio/ost/)
                  </h3>
                  <span className="text-[11px] text-[#9eb0cc]">1.2s Smooth Crossfade</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {ostSlots.map((slot) => (
                    <div
                      key={slot.id}
                      className="bg-[#090e1a] border border-[#2a364f] p-2.5 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0">
                        <div className="text-[#f2ead8] truncate">{slot.label}</div>
                        <div className="font-mono-num text-[11px] text-[#9eb0cc] truncate">
                          OST Track Slot: {slot.filename}
                        </div>
                      </div>
                      <label className="px-2.5 py-1 border border-[#d4b06a]/60 text-[11px] text-[#f2dca6] hover:bg-[#d4b06a]/20 cursor-pointer whitespace-nowrap shrink-0">
                        {slot.status === 'slot_empty' ? 'Load File' : 'Loaded'}
                        <input
                          type="file"
                          accept=".mp3,.ogg,audio/*"
                          className="hidden"
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) {
                              AudioManager.registerCustomTrackFile(slot.id as OSTTrackId, f);
                              showToast(`Loaded custom OST for ${slot.filename}`);
                            }
                          }}
                        />
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Asset Drop-In Inspector (Sprites & Tiles) */}
              <div className="bg-[#0d1322] border border-[#303d57] p-3.5 space-y-2">
                <h3 className="font-display text-xs tracking-widest text-[#f2dca6]">
                  CHIBI SPRITE & TILE DROP-IN INSPECTOR (/public/assets/)
                </h3>
                <p className="text-[11px] text-[#9eb0cc]">
                  Drop 4x4 walk PNGs or 4x3 battle PNGs into /public/assets/sprites/ (or test live below) to override procedural 16-bit fallbacks with zero code changes.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2" data-tick={assetRefreshTick}>
                  {Object.values(SPRITE_MANIFEST)
                    .slice(0, 9)
                    .map((sp) => {
                      const status = SpriteSheetRegistry.getOverrideStatus(sp.walkFile);
                      return (
                        <div
                          key={sp.id}
                          className="bg-[#090e1a] border border-[#2a364f] p-2 flex items-center justify-between gap-2 text-[11px]"
                        >
                          <div className="min-w-0">
                            <div className="text-[#f2ead8] truncate">{sp.label}</div>
                            <div className="font-mono-num text-[10px] text-[#8d9cb8] truncate">
                              {sp.walkFile} ({status === 'custom_png' ? 'PNG Active' : 'Fallback'})
                            </div>
                          </div>
                          <label className="px-2 py-0.5 border border-[#5a6985] text-[#c7d2e6] hover:border-[#d4b06a] cursor-pointer whitespace-nowrap">
                            PNG
                            <input
                              type="file"
                              accept="image/png"
                              className="hidden"
                              onChange={(e) => {
                                const f = e.target.files?.[0];
                                if (f) {
                                  SpriteSheetRegistry.registerCustomSprite(sp.walkFile, f);
                                  setAssetRefreshTick((t) => t + 1);
                                  showToast(`Overrode ${sp.walkFile} with custom PNG.`);
                                }
                              }}
                            />
                          </label>
                        </div>
                      );
                    })}
                </div>
                <div className="text-[11px] font-mono-num text-[#8d9cb8] pt-1">
                  Tile Slots ({TILE_ASSET_SLOTS.length}):{' '}
                  {PixelTextureFactory.getAvailableOverrides().length} custom PNG overrides active
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
