import React, { useEffect, useRef, useState } from 'react';
import { getMapById, MAP_REGISTRY } from '../data/maps/mapRegistry';
import { getActiveQuest } from '../data/storyEpisode3';
import { AudioManager } from '../engine/AudioManager';
import { useGameState } from '../engine/GameStateContext';
import { WorldInputState } from '../engine/HD2DWorldEngine';
import { MapId } from '../types/rpg';

interface AndroidControlsProps {
  onInputChange: (input: WorldInputState) => void;
  onInteract: () => void;
}

export const AndroidControls: React.FC<AndroidControlsProps> = ({
  onInputChange,
  onInteract,
}) => {
  const {
    gameState,
    mapId,
    playerPos,
    questFlags,
    activeOverlay,
    setActiveOverlay,
    activeDialogue,
    activePrompt,
    config,
    visitedMaps,
    warpToMap,
    gil,
  } = useGameState();

  const isExploring =
    gameState === 'PLAYING_WORLDMAP' ||
    gameState === 'PLAYING_TOWN' ||
    gameState === 'PLAYING_INTERIOR' ||
    gameState === 'PLAYING_DUNGEON';

  const keysRef = useRef<Set<string>>(new Set());
  const touchStickRef = useRef<{ x: number; z: number; active: boolean }>({
    x: 0,
    z: 0,
    active: false,
  });
  const sprintTouchRef = useRef(false);
  const padRef = useRef<HTMLDivElement | null>(null);
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const [sprintingVis, setSprintingVis] = useState(false);

  const emitCombinedInput = () => {
    if (!isExploring || activeOverlay || activeDialogue) {
      onInputChange({ moveX: 0, moveZ: 0, sprint: false });
      return;
    }

    let kx = 0;
    let kz = 0;
    const keys = keysRef.current;
    if (keys.has('arrowleft') || keys.has('a')) kx -= 1;
    if (keys.has('arrowright') || keys.has('d')) kx += 1;
    if (keys.has('arrowup') || keys.has('w')) kz -= 1;
    if (keys.has('arrowdown') || keys.has('s')) kz += 1;

    const moveX = touchStickRef.current.active ? touchStickRef.current.x : kx;
    const moveZ = touchStickRef.current.active ? touchStickRef.current.z : kz;
    const sprint = sprintTouchRef.current || keys.has('shift');
    onInputChange({ moveX, moveZ, sprint });
  };

  // Clear stuck inputs when overlays open or window blurs
  useEffect(() => {
    if (!isExploring || activeOverlay || activeDialogue) {
      keysRef.current.clear();
      touchStickRef.current = { x: 0, z: 0, active: false };
      setKnobOffset({ x: 0, y: 0 });
      onInputChange({ moveX: 0, moveZ: 0, sprint: false });
    }
  }, [isExploring, activeOverlay, activeDialogue, onInputChange]);

  // Global keyboard bindings (WASD / Arrows, Enter/Space/Z = A, Shift/X = B, Q/G = Y)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement &&
        ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)
      ) {
        return;
      }
      const lower = e.key.toLowerCase();
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'w', 'a', 's', 'd', 'shift'].includes(lower)) {
        keysRef.current.add(lower);
        emitCombinedInput();
      } else if (lower === ' ' || lower === 'enter' || lower === 'z') {
        if (activeDialogue) {
          e.preventDefault();
          onInteract();
        } else if (isExploring && !activeOverlay) {
          e.preventDefault();
          onInteract();
        }
      } else if ((lower === 'm' || lower === 'q' || lower === 'g') && isExploring && !activeDialogue) {
        e.preventDefault();
        AudioManager.playSfx('cursor');
        setActiveOverlay(activeOverlay === 'map_drawer' ? null : 'map_drawer');
      } else if (lower === 'x' && isExploring && !activeDialogue) {
        e.preventDefault();
        AudioManager.playSfx('confirm');
        setActiveOverlay(activeOverlay === 'main_menu' ? null : 'main_menu');
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const lower = e.key.toLowerCase();
      if (keysRef.current.delete(lower)) {
        emitCombinedInput();
      }
    };

    const onBlur = () => {
      keysRef.current.clear();
      touchStickRef.current = { x: 0, z: 0, active: false };
      setKnobOffset({ x: 0, y: 0 });
      onInputChange({ moveX: 0, moveZ: 0, sprint: false });
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  });

  if (!isExploring) return null;

  const map = getMapById(mapId);
  const quest = getActiveQuest(questFlags);

  const handleStickPointer = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = padRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.4;
    let dx = e.clientX - cx;
    let dy = e.clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    setKnobOffset({ x: dx, y: dy });
    // Snap cleanly to 8-way or smooth analog
    touchStickRef.current = {
      x: Math.abs(dx / maxR) < 0.14 ? 0 : dx / maxR,
      z: Math.abs(dy / maxR) < 0.14 ? 0 : dy / maxR,
      active: true,
    };
    emitCombinedInput();
  };

  const releaseStick = () => {
    touchStickRef.current = { x: 0, z: 0, active: false };
    setKnobOffset({ x: 0, y: 0 });
    emitCombinedInput();
  };

  const fastTravelDestinations: Array<{ id: MapId; label: string }> = [
    { id: 'town_nisan', label: 'Town of Nisan' },
    { id: 'interior_cathedral', label: 'Nisan Cathedral' },
    { id: 'interior_atelier', label: "Lacan's Atelier" },
    { id: 'interior_inn_shop', label: 'Inn & Armory' },
    { id: 'worldmap_ignas', label: 'Ignas World Map' },
    { id: 'dungeon_zeboim_ruins', label: 'Zeboim Ruins' },
  ];

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between safe-pad">
      {/* Top Row: Compact Location Plaque + Utility Strip */}
      <div className="flex items-start justify-between gap-3">
        <div className="jrpg-window-subtle px-3.5 py-2 pointer-events-auto max-w-[300px] sm:max-w-[360px]">
          <div className="flex items-baseline justify-between gap-3">
            <h1 className="font-display text-sm sm:text-base tracking-wider text-[#f4e4bf] truncate">
              {map.name}
            </h1>
            <span className="font-mono-num text-[11px] text-[#d4b06a] whitespace-nowrap">
              {gil} G
            </span>
          </div>
          <p className="text-[11px] text-[#b4bfd4] truncate mt-0.5">{quest.title}</p>
        </div>

        {/* Compact Top-Right Quick Controls (Menu & Map) */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            type="button"
            aria-label="Toggle Area Map and Fast Travel"
            onClick={(e) => {
              e.currentTarget.blur();
              AudioManager.playSfx('cursor');
              setActiveOverlay(activeOverlay === 'map_drawer' ? null : 'map_drawer');
            }}
            className="jrpg-window-subtle min-h-[48px] min-w-[48px] px-3.5 py-2 text-xs font-display tracking-wider text-[#e8d6b0] hover:border-[#f2dca6] transition-colors whitespace-nowrap"
          >
            Map [Y]
          </button>
          <button
            type="button"
            aria-label="Open Main Menu"
            onClick={(e) => {
              e.currentTarget.blur();
              AudioManager.playSfx('confirm');
              setActiveOverlay(activeOverlay === 'main_menu' ? null : 'main_menu');
            }}
            className="jrpg-window-subtle min-h-[48px] min-w-[48px] px-3.5 py-2 text-xs font-display tracking-wider text-[#e8d6b0] hover:border-[#f2dca6] transition-colors whitespace-nowrap"
          >
            Menu [X]
          </button>
        </div>
      </div>

      {/* Contextual Interact Prompt Banner (above bottom controls) */}
      {activePrompt && !activeOverlay && !activeDialogue && (
        <div className="self-center mb-2 pointer-events-auto">
          <button
            type="button"
            onClick={(e) => {
              e.currentTarget.blur();
              onInteract();
            }}
            className="jrpg-window min-h-[48px] px-4 py-2 flex items-center gap-2.5 text-xs sm:text-sm text-[#f7ebd1] hover:border-[#f2dca6] transition-colors"
          >
            <span className="w-6 h-6 rounded-full bg-[#d4b06a] text-[#0c101b] font-bold text-xs flex items-center justify-center">
              A
            </span>
            <span className="font-display tracking-wide whitespace-nowrap">
              {activePrompt.label}
            </span>
          </button>
        </div>
      )}

      {/* Android Thumb Zones (Left Virtual D-Pad / Analog Stick + Right ABXY Tactile Cluster) */}
      {config.showTouchControls && !activeOverlay && !activeDialogue && (
        <div className="flex items-end justify-between w-full pb-1">
          {/* Left Thumb Zone: Semi-Transparent Floating 8-Way D-Pad / Analog Thumbstick */}
          <div
            ref={padRef}
            role="group"
            aria-label="Virtual 8-Way Movement Thumbstick"
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              handleStickPointer(e);
            }}
            onPointerMove={(e) => {
              if (touchStickRef.current.active) handleStickPointer(e);
            }}
            onPointerUp={releaseStick}
            onPointerCancel={releaseStick}
            className="pointer-events-auto relative w-28 h-28 sm:w-32 sm:h-32 rounded-full border border-[#d4b06a]/50 bg-[#0c111e]/60 flex items-center justify-center shadow-[0_6px_20px_rgba(0,0,0,0.55)]"
          >
            {/* 8-way cardinal ticks */}
            <span className="absolute top-2 text-[10px] text-[#d4b06a]/70 font-mono-num">N</span>
            <span className="absolute bottom-2 text-[10px] text-[#d4b06a]/70 font-mono-num">S</span>
            <span className="absolute left-2.5 text-[10px] text-[#d4b06a]/70 font-mono-num">W</span>
            <span className="absolute right-2.5 text-[10px] text-[#d4b06a]/70 font-mono-num">E</span>
            {/* Crosshair ring */}
            <div className="w-16 h-16 rounded-full border border-[#d4b06a]/25 pointer-events-none" />
            {/* Movable Thumb Knob */}
            <div
              style={{
                transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
              }}
              className="absolute w-11 h-11 rounded-full border border-[#f2dca6]/80 bg-[#1a243b]/90 shadow-[inset_0_1px_4px_rgba(242,220,166,0.4)] pointer-events-none transition-transform duration-75"
            />
          </div>

          {/* Right Thumb Zone: Tactile Circular [A] [B] [X] [Y] Buttons (>= 48px hit targets) */}
          <div className="pointer-events-auto relative w-40 h-36 sm:w-44 sm:h-40">
            {/* [Y] Map / Gear Call (Top) */}
            <button
              type="button"
              aria-label="Y Button: Map and Gear Call"
              onClick={(e) => {
                e.currentTarget.blur();
                AudioManager.playSfx('cursor');
                setActiveOverlay('map_drawer');
              }}
              className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-12 sm:w-13 sm:h-13 rounded-full border border-[#7cb8e0]/75 bg-[#101c2e]/85 text-[#cfeaff] flex flex-col items-center justify-center active:scale-95 transition-transform shadow-lg"
            >
              <span className="font-display text-xs font-bold leading-none">Y</span>
              <span className="text-[8px] tracking-wider opacity-85">MAP</span>
            </button>

            {/* [X] Main Menu (Left) */}
            <button
              type="button"
              aria-label="X Button: Main Menu"
              onClick={(e) => {
                e.currentTarget.blur();
                AudioManager.playSfx('confirm');
                setActiveOverlay('main_menu');
              }}
              className="absolute top-1/2 left-0 -translate-y-1/2 w-12 h-12 sm:w-13 sm:h-13 rounded-full border border-[#c4a668]/75 bg-[#161a2b]/85 text-[#f2dca6] flex flex-col items-center justify-center active:scale-95 transition-transform shadow-lg"
            >
              <span className="font-display text-xs font-bold leading-none">X</span>
              <span className="text-[8px] tracking-wider opacity-85">MENU</span>
            </button>

            {/* [A] Interact / Confirm (Right) */}
            <button
              type="button"
              aria-label="A Button: Interact or Confirm"
              onClick={(e) => {
                e.currentTarget.blur();
                onInteract();
              }}
              className={`absolute top-1/2 right-0 -translate-y-1/2 w-13 h-13 sm:w-14 sm:h-14 rounded-full border flex flex-col items-center justify-center active:scale-95 transition-transform shadow-lg ${
                activePrompt
                  ? 'border-[#f5dfa3] bg-[#59431d]/90 text-[#fff6df]'
                  : 'border-[#d4b06a]/80 bg-[#1a2236]/85 text-[#f2dca6]'
              }`}
            >
              <span className="font-display text-sm font-bold leading-none">A</span>
              <span className="text-[8px] tracking-wider opacity-90">
                {activePrompt ? 'ACT' : 'OK'}
              </span>
            </button>

            {/* [B] Sprint / Cancel (Bottom) */}
            <button
              type="button"
              aria-label="B Button: Hold to Sprint or Cancel"
              onPointerDown={() => {
                sprintTouchRef.current = true;
                setSprintingVis(true);
                emitCombinedInput();
              }}
              onPointerUp={() => {
                sprintTouchRef.current = false;
                setSprintingVis(false);
                emitCombinedInput();
              }}
              onPointerLeave={() => {
                sprintTouchRef.current = false;
                setSprintingVis(false);
                emitCombinedInput();
              }}
              className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-12 sm:w-13 sm:h-13 rounded-full border flex flex-col items-center justify-center active:scale-95 transition-transform shadow-lg ${
                sprintingVis
                  ? 'border-[#f2dca6] bg-[#5e2929]/90 text-[#fff2e0]'
                  : 'border-[#c46868]/75 bg-[#1b1521]/85 text-[#f0c7c7]'
              }`}
            >
              <span className="font-display text-xs font-bold leading-none">B</span>
              <span className="text-[8px] tracking-wider opacity-85">RUN</span>
            </button>
          </div>
        </div>
      )}

      {/* [Y] Area Minimap & Fast-Travel / Gear Call Drawer */}
      {activeOverlay === 'map_drawer' && (
        <div className="fixed inset-0 z-40 bg-black/70 flex items-center justify-center safe-pad pointer-events-auto">
          <div className="jrpg-window w-full max-w-2xl p-4 sm:p-5 flex flex-col gap-3 max-h-[88dvh] overflow-y-auto jrpg-scroll">
            <div className="flex items-center justify-between border-b border-[#d4b06a]/35 pb-2">
              <div>
                <h2 className="font-display text-base tracking-[0.18em] text-[#f2dca6]">
                  IGNAS CARTOGRAPHY & GEAR CALL
                </h2>
                <p className="text-xs text-[#9fb0cc]">
                  Current Sector: {map.name} · Tile ({Math.round(playerPos.x)}, {Math.round(playerPos.z)})
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  AudioManager.playSfx('cancel');
                  setActiveOverlay(null);
                }}
                className="min-h-[48px] min-w-[48px] px-4 py-2 text-xs border border-[#d4b06a]/50 text-[#f2dca6] hover:bg-[#d4b06a]/20"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Crisp Tile Minimap */}
              <div className="bg-[#0a0e18] border border-[#d4b06a]/30 p-3 flex flex-col items-center">
                <span className="text-[11px] font-display tracking-wider text-[#d4b06a] mb-2">
                  LOCAL AREA RADAR
                </span>
                <svg
                  viewBox={`0 0 ${map.width} ${map.depth}`}
                  className="w-full max-w-[240px] h-auto border border-[#3a465e]"
                  aria-label="Local area minimap"
                >
                  {map.tiles.map((row, z) =>
                    row.map((t, x) => {
                      const fill =
                        t === 'water'
                          ? '#2b5f87'
                          : t === 'cobble' || t === 'stone_plaza' || t === 'marble_checker'
                            ? '#8c8376'
                            : t === 'bridge' || t === 'wood_floor'
                              ? '#7a5436'
                              : t === 'sand'
                                ? '#c7a96d'
                                : t === 'zeboim_floor'
                                  ? '#374a66'
                                  : t.startsWith('wall') || t === 'mountain'
                                    ? '#1a202e'
                                    : '#436943';
                      return <rect key={`${x}-${z}`} x={x} y={z} width={1} height={1} fill={fill} />;
                    })
                  )}
                  {map.warpZones.map((w) => (
                    <circle key={w.id} cx={w.x + 0.5} cy={w.z + 0.5} r={0.7} fill="#66d9ff" />
                  ))}
                  {map.savePoints.map((s) => (
                    <rect key={s.id} x={s.x} y={s.z} width={1} height={1} fill="#f2d16b" />
                  ))}
                  <circle
                    cx={playerPos.x + 0.5}
                    cy={playerPos.z + 0.5}
                    r={0.85}
                    fill="#ff5c5c"
                    stroke="#ffffff"
                    strokeWidth={0.3}
                  />
                </svg>
                <div className="mt-2 flex items-center gap-3 text-[10px] text-[#9eb0cc]">
                  <span>Red: Party</span>
                  <span>·</span>
                  <span>Blue: Warp</span>
                  <span>·</span>
                  <span>Gold: Memory Cube</span>
                </div>
              </div>

              {/* Fast Travel Landmarks */}
              <div className="flex flex-col gap-2">
                <span className="text-[11px] font-display tracking-wider text-[#d4b06a]">
                  FAST TRAVEL — EPISODE III SECTORS
                </span>
                <div className="flex flex-col gap-1.5">
                  {fastTravelDestinations.map((dest) => {
                    const target = MAP_REGISTRY[dest.id];
                    const isHere = dest.id === mapId;
                    const visited = visitedMaps.includes(dest.id);
                    return (
                      <button
                        key={dest.id}
                        type="button"
                        disabled={isHere}
                        onClick={() => {
                          setActiveOverlay(null);
                          warpToMap(
                            dest.id,
                            target.defaultSpawn.x,
                            target.defaultSpawn.z,
                            target.defaultSpawn.facing
                          );
                        }}
                        className={`w-full min-h-[48px] text-left px-3 py-2 border text-xs flex items-center justify-between transition-colors ${
                          isHere
                            ? 'border-[#d4b06a] bg-[#1c263d] text-[#f5e3ba]'
                            : 'border-[#3d4a66] bg-[#101726] text-[#dce4f2] hover:border-[#d4b06a]'
                        }`}
                      >
                        <span className="font-display tracking-wide">{dest.label}</span>
                        <span className="text-[10px] text-[#9eb0cc]">
                          {isHere ? 'Here' : visited ? 'Travel' : 'Scout'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
