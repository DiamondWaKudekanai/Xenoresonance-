import React, { useState } from 'react';
import { ARMORY_SHOP_IDS, ITEM_SHOP_IDS, ITEMS } from '../data/itemsAndGear';
import { AudioManager } from '../engine/AudioManager';
import { getMemberStats } from '../engine/CombatRules';
import { useGameState } from '../engine/GameStateContext';
import { ItemDef, PartyMember } from '../types/rpg';

export const ShopModal: React.FC = () => {
  const {
    activeOverlay,
    setActiveOverlay,
    gil,
    party,
    inventory,
    restAtInn,
    buyItem,
    sellItem,
  } = useGameState();

  const [mode, setMode] = useState<'buy' | 'sell'>('buy');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [compareCharIdx, setCompareCharIdx] = useState(0);

  if (
    activeOverlay !== 'inn_modal' &&
    activeOverlay !== 'armory_shop' &&
    activeOverlay !== 'item_shop'
  ) {
    return null;
  }

  // Innkeeper Rest Modal (50 G)
  if (activeOverlay === 'inn_modal') {
    const cost = 50;
    return (
      <div className="fixed inset-0 z-40 bg-black/75 flex items-center justify-center safe-pad">
        <div className="jrpg-window w-full max-w-md p-5 flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-[#d4b06a]/35 pb-2">
            <h2 className="font-display text-base tracking-[0.18em] text-[#f2dca6]">
              NISAN SANCTUARY INN
            </h2>
            <span className="font-mono-num text-sm text-[#e8c678]">{gil} G</span>
          </div>

          <p className="font-serif-jp text-base text-[#e6decb] leading-relaxed">
            “Welcome, weary travelers. For <strong className="text-[#f2dca6]">{cost} G</strong>,
            you may rest until dawn—restoring full Party HP, EP, and Gear Fuel reserves.”
          </p>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                AudioManager.playSfx('cancel');
                setActiveOverlay(null);
              }}
              className="min-h-[48px] px-4 py-2 text-xs font-display tracking-wider border border-[#5a6680] text-[#c2cde0] hover:border-[#d4b06a]"
            >
              Leave
            </button>
            <button
              type="button"
              disabled={gil < cost}
              onClick={() => restAtInn(cost)}
              className={`min-h-[48px] px-5 py-2 text-xs font-display tracking-wider border transition-colors ${
                gil >= cost
                  ? 'border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df] hover:bg-[#d4b06a]/40'
                  : 'border-[#3e4659] text-[#7a8499] cursor-not-allowed'
              }`}
            >
              Rest Until Dawn ({cost} G)
            </button>
          </div>
        </div>
      </div>
    );
  }

  const isArmory = activeOverlay === 'armory_shop';
  const stockIds = isArmory ? ARMORY_SHOP_IDS : ITEM_SHOP_IDS;
  const displayList: ItemDef[] =
    mode === 'buy'
      ? stockIds.map((id) => ITEMS[id]).filter(Boolean)
      : inventory
          .map((e) => ITEMS[e.itemId])
          .filter(Boolean);

  const activeItem =
    (selectedId && ITEMS[selectedId]) || displayList[0] || null;
  const compareMember: PartyMember = party[compareCharIdx] ?? party[0];

  const renderStatDelta = (label: string, currentVal: number, nextVal: number) => {
    const diff = nextVal - currentVal;
    return (
      <div className="flex items-center justify-between text-xs font-mono-num py-0.5">
        <span className="text-[#9eacc4]">{label}</span>
        <span>
          <span className="text-[#dbe3f2]">{currentVal}</span>
          {diff !== 0 && (
            <span className={diff > 0 ? 'text-[#6be09a] ml-1.5' : 'text-[#eb7575] ml-1.5'}>
              → {nextVal} ({diff > 0 ? `+${diff}` : diff})
            </span>
          )}
        </span>
      </div>
    );
  };

  const getSimulatedStats = (member: PartyMember, item: ItemDef) => {
    const cur = getMemberStats(member);
    if (item.category === 'consumable') return { cur, sim: cur };
    const copy: PartyMember = {
      ...member,
      weaponId: item.category === 'weapon' ? item.id : member.weaponId,
      armorId: item.category === 'armor' ? item.id : member.armorId,
      accessoryId: item.category === 'accessory' ? item.id : member.accessoryId,
      gear:
        item.category === 'gear_part' && member.gear
          ? { ...member.gear, equippedPartId: item.id }
          : member.gear,
    };
    return { cur, sim: getMemberStats(copy) };
  };

  const ownedQty = (id: string) => inventory.find((e) => e.itemId === id)?.quantity ?? 0;

  return (
    <div className="fixed inset-0 z-40 bg-black/75 flex items-center justify-center safe-pad">
      <div className="jrpg-window w-full max-w-4xl max-h-[90dvh] flex flex-col p-4 sm:p-5 gap-3">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#d4b06a]/35 pb-2.5">
          <div>
            <h2 className="font-display text-base sm:text-lg tracking-[0.18em] text-[#f2dca6]">
              {isArmory ? 'NISAN ARMORY & GEAR WORKS' : 'APOTHECARY & PROVISIONS'}
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono-num text-sm text-[#f2dca6] border border-[#d4b06a]/40 px-3 py-2 bg-[#0b101c]">
              {gil} G
            </span>
            <button
              type="button"
              onClick={() => {
                AudioManager.playSfx('cancel');
                setActiveOverlay(null);
              }}
              className="min-h-[48px] px-4 py-2 text-xs font-display tracking-wider border border-[#d4b06a]/60 text-[#f2dca6] hover:bg-[#d4b06a]/20"
            >
              Close
            </button>
          </div>
        </div>

        {/* Buy / Sell Segmented Bar */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              AudioManager.playSfx('cursor');
              setMode('buy');
              setSelectedId(null);
            }}
            className={`min-h-[48px] px-4 py-2 text-xs font-display tracking-widest border transition-colors ${
              mode === 'buy'
                ? 'border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df]'
                : 'border-[#3c4863] text-[#9eb0cc] hover:text-white'
            }`}
          >
            Buy Stock
          </button>
          <button
            type="button"
            onClick={() => {
              AudioManager.playSfx('cursor');
              setMode('sell');
              setSelectedId(null);
            }}
            className={`min-h-[48px] px-4 py-2 text-xs font-display tracking-widest border transition-colors ${
              mode === 'sell'
                ? 'border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df]'
                : 'border-[#3c4863] text-[#9eb0cc] hover:text-white'
            }`}
          >
            Sell Inventory
          </button>
        </div>

        {/* Two-Column Stock + Live Stat Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 flex-1 min-h-0 overflow-hidden">
          <div className="md:col-span-3 overflow-y-auto jrpg-scroll pr-1 flex flex-col gap-1.5">
            {displayList.length === 0 ? (
              <p className="text-xs text-[#8d9cb8] p-4">No items available to sell.</p>
            ) : (
              displayList.map((item) => {
                const selected = activeItem?.id === item.id;
                const price = mode === 'buy' ? item.price : item.sellPrice;
                const qty = ownedQty(item.id);
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      AudioManager.playSfx('cursor');
                      setSelectedId(item.id);
                    }}
                    className={`w-full text-left px-3 py-2 border flex items-center justify-between gap-2 transition-colors ${
                      selected
                        ? 'border-[#e3c078] bg-[#1c2740]'
                        : 'border-[#2f3b54] bg-[#0e1422] hover:border-[#7c6a45]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="text-xs sm:text-sm font-medium text-[#f2ead8] truncate">
                        {item.name}
                      </div>
                      <div className="text-[11px] text-[#9aa8c2]">
                        {item.category.replace('_', ' ')} · Owned: {qty}
                      </div>
                    </div>
                    <span className="font-mono-num text-xs sm:text-sm text-[#e8c678] whitespace-nowrap">
                      {price} G
                    </span>
                  </button>
                );
              })
            )}
          </div>

          {/* Right Inspector & Live Stat Preview */}
          <div className="md:col-span-2 bg-[#0c111e] border border-[#d4b06a]/30 p-3.5 flex flex-col justify-between gap-3 overflow-y-auto jrpg-scroll">
            {activeItem ? (
              <>
                <div className="flex flex-col gap-2.5">
                  <div>
                    <h3 className="font-display text-sm text-[#f2dca6]">{activeItem.name}</h3>
                    <p className="text-xs text-[#c7d1e3] mt-1 leading-relaxed">
                      {activeItem.description}
                    </p>
                  </div>

                  {/* Character Selector for Stat Comparison */}
                  {activeItem.category !== 'consumable' && (
                    <div className="border-t border-[#d4b06a]/25 pt-2.5">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] font-display tracking-wider text-[#d4b06a]">
                          COMPARE STATS
                        </span>
                        <div className="flex gap-1">
                          {party.map((m, idx) => (
                            <button
                              key={m.id}
                              type="button"
                              onClick={() => setCompareCharIdx(idx)}
                              className={`px-2 py-0.5 text-[10px] border ${
                                idx === compareCharIdx
                                  ? 'border-[#f2dca6] bg-[#25314d] text-white'
                                  : 'border-[#333f59] text-[#9eb0cc]'
                              }`}
                            >
                              {m.name.slice(0, 3)}
                            </button>
                          ))}
                        </div>
                      </div>
                      {(() => {
                        const { cur, sim } = getSimulatedStats(compareMember, activeItem);
                        return (
                          <div className="space-y-0.5">
                            {activeItem.category === 'gear_part' ? (
                              <>
                                {renderStatDelta('Gear ATK', cur.gearAtk, sim.gearAtk)}
                                {renderStatDelta('Gear DEF', cur.gearDef, sim.gearDef)}
                                {renderStatDelta('Frame HP', cur.gearMaxHp, sim.gearMaxHp)}
                                {renderStatDelta('Max Fuel', cur.gearMaxFuel, sim.gearMaxFuel)}
                              </>
                            ) : (
                              <>
                                {renderStatDelta('ATK', cur.atk, sim.atk)}
                                {renderStatDelta('DEF', cur.def, sim.def)}
                                {renderStatDelta('ETHER', cur.ether, sim.ether)}
                                {renderStatDelta('SPD', cur.spd, sim.spd)}
                              </>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  disabled={
                    mode === 'buy'
                      ? gil < activeItem.price
                      : ownedQty(activeItem.id) <= 0
                  }
                  onClick={() => {
                    if (mode === 'buy') buyItem(activeItem.id);
                    else sellItem(activeItem.id);
                  }}
                  className={`w-full py-2.5 font-display text-xs tracking-[0.18em] border transition-colors ${
                    (mode === 'buy' ? gil >= activeItem.price : ownedQty(activeItem.id) > 0)
                      ? 'border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df] hover:bg-[#d4b06a]/40'
                      : 'border-[#3b4459] text-[#7c869c] cursor-not-allowed'
                  }`}
                >
                  {mode === 'buy'
                    ? `Purchase (${activeItem.price} G)`
                    : `Sell (+${activeItem.sellPrice} G)`}
                </button>
              </>
            ) : (
              <p className="text-xs text-[#8d9cb8]">Select an item to inspect.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
