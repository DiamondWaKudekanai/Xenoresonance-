export type GameState =
  | 'BOOT_LOGO'
  | 'PROLOGUE_INTRO'
  | 'TITLE_SCREEN'
  | 'PLAYING_WORLDMAP'
  | 'PLAYING_TOWN'
  | 'PLAYING_INTERIOR'
  | 'PLAYING_DUNGEON'
  | 'BATTLE'
  | 'CUTSCENE'
  | 'GAME_OVER';

export type MapId =
  | 'worldmap_ignas'
  | 'town_nisan'
  | 'interior_cathedral'
  | 'interior_atelier'
  | 'interior_inn_shop'
  | 'dungeon_zeboim_ruins';

export type Direction = 'S' | 'W' | 'E' | 'N';

export type GraphicsQuality = 'low' | 'medium' | 'high';

export type OSTTrackId =
  | 'title'
  | 'worldmap'
  | 'town_nisan'
  | 'interior_peaceful'
  | 'dungeon_zeboim'
  | 'battle_normal'
  | 'battle_boss'
  | 'cutscene_tragic';

export type SpriteId =
  | 'lacan'
  | 'sophia'
  | 'krelian'
  | 'roni'
  | 'npc_monk'
  | 'npc_villager'
  | 'npc_merchant'
  | 'npc_child'
  | 'npc_solaris'
  | 'npc_hologram'
  | 'gear_amon'
  | 'gear_elregrs'
  | 'gear_andvari'
  | 'gear_solaris'
  | 'enemy_trooper'
  | 'enemy_automaton'
  | 'enemy_sandworm'
  | 'boss_diabolos';

export type WeaknessType = 'PHYSICAL' | 'SWORD' | 'ETHER' | 'FIRE' | 'LIGHTNING';

export type APInput = 'T' | 'S' | 'X'; // Weak (1 AP), Med (2 AP), Strong (3 AP)

export interface DeathblowDef {
  id: string;
  name: string;
  sequence: APInput[];
  apCost: number;
  multiplier: number;
  element: WeaknessType;
  description: string;
  requiredLevel: number;
}

export interface EtherSkillDef {
  id: string;
  name: string;
  epCost: number;
  power: number;
  element: WeaknessType;
  target: 'enemy' | 'all_enemies' | 'ally' | 'all_allies';
  isHeal?: boolean;
  description: string;
}

export type ItemCategory = 'consumable' | 'weapon' | 'armor' | 'accessory' | 'gear_part';

export interface ItemDef {
  id: string;
  name: string;
  category: ItemCategory;
  price: number;
  sellPrice: number;
  description: string;
  stats?: {
    atk?: number;
    def?: number;
    ether?: number;
    spd?: number;
    maxHp?: number;
    frameHp?: number;
    maxFuel?: number;
  };
  effect?: {
    healHp?: number;
    healEp?: number;
    healFuel?: number;
    revive?: boolean;
    allParty?: boolean;
  };
  allowedChars?: string[];
}

export interface InventoryEntry {
  itemId: string;
  quantity: number;
}

export interface GearUnit {
  id: string;
  name: string;
  spriteId: SpriteId;
  frameHp: number;
  maxFrameHp: number;
  fuel: number;
  maxFuel: number;
  atkBonus: number;
  defBonus: number;
  attackLevel: number; // 0..3 (or 4 for Infinity)
  boosterActive: boolean;
  equippedPartId: string | null;
}

export interface PartyMember {
  id: 'lacan' | 'sophia' | 'krelian' | 'roni';
  name: string;
  title: string;
  spriteId: SpriteId;
  accentColor: string;
  joined: boolean;
  level: number;
  xp: number;
  nextLevelXp: number;
  hp: number;
  maxHp: number;
  ep: number;
  maxEp: number;
  baseAtk: number;
  baseDef: number;
  baseEther: number;
  baseSpd: number;
  weaponId: string | null;
  armorId: string | null;
  accessoryId: string | null;
  deathblowMastery: Record<string, number>; // 0..100
  etherSkills: EtherSkillDef[];
  gear: GearUnit | null;
}

export interface SaveSlotData {
  slotId: 1 | 2 | 3;
  version: number;
  savedAt: string;
  mapId: MapId;
  locationName: string;
  playerX: number;
  playerZ: number;
  facing: Direction;
  playtimeSeconds: number;
  gil: number;
  party: PartyMember[];
  inventory: InventoryEntry[];
  openedChests: string[];
  questFlags: Record<string, boolean>;
  visitedMaps: MapId[];
}

export interface AudioConfig {
  bgmVolume: number; // 0..1
  sfxVolume: number; // 0..1
  muted: boolean;
}

export interface AppConfig {
  audio: AudioConfig;
  graphicsQuality: GraphicsQuality;
  showTouchControls: boolean;
}

export type NpcBehavior = 'STATIONARY' | 'LOOK_AROUND' | 'PATROL_WAYPOINTS';

export interface NpcDef {
  id: string;
  name: string;
  role: string;
  spriteId: SpriteId;
  x: number;
  z: number;
  facing: Direction;
  behavior: NpcBehavior;
  waypoints?: Array<{ x: number; z: number }>;
  dialogueId?: string;
  shopType?: 'inn' | 'armory' | 'items';
  questFlagCondition?: { flag: string; expected: boolean };
  voicePitch?: number;
}

export interface WarpZone {
  id: string;
  x: number;
  z: number;
  width?: number;
  depth?: number;
  targetMap: MapId;
  targetX: number;
  targetZ: number;
  targetFacing: Direction;
  label: string;
  requiresInteract?: boolean;
}

export interface ChestDef {
  id: string;
  x: number;
  z: number;
  facing: Direction;
  rewardGil?: number;
  rewardItemId?: string;
  rewardQty?: number;
  label: string;
}

export interface SavePointDef {
  id: string;
  x: number;
  z: number;
  label: string;
}

export interface FloorSwitchDef {
  id: string;
  x: number;
  z: number;
  flagId: string;
  gateTiles: Array<{ x: number; z: number }>;
  label: string;
}

export interface EncounterZoneDef {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  stepThresholdMin: number;
  stepThresholdMax: number;
  enemyGroups: string[][];
  arenaTheme: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps';
}

export type TileType =
  | 'void'
  | 'grass'
  | 'cobble'
  | 'stone_plaza'
  | 'water'
  | 'sand'
  | 'forest'
  | 'mountain'
  | 'wood_floor'
  | 'marble_checker'
  | 'rug_red'
  | 'zeboim_floor'
  | 'bridge'
  | 'stair_n'
  | 'stair_s'
  | 'stair_e'
  | 'stair_w'
  | 'wall_stone'
  | 'wall_wood'
  | 'wall_zeboim';

export interface Building3DSpec {
  id: string;
  name: string;
  x: number; // left tile
  z: number; // top (north) tile
  width: number;
  height: number;
  depth: number;
  wallStyle: 'stone' | 'stucco' | 'cathedral' | 'zeboim';
  roofStyle: 'pitched_clay' | 'pitched_slate' | 'cathedral_spire' | 'flat_stone';
  doorTile?: { x: number; z: number };
  windowCount?: number;
}

export interface Prop3DSpec {
  id: string;
  type:
    | 'lantern'
    | 'tree_pine'
    | 'tree_oak'
    | 'pew'
    | 'altar_sophia'
    | 'stained_glass'
    | 'easel'
    | 'bed'
    | 'bookshelf'
    | 'fireplace'
    | 'paint_table'
    | 'tavern_counter'
    | 'tavern_table'
    | 'zeboim_pillar'
    | 'ether_conduit'
    | 'omnigear_relic'
    | 'world_nisan'
    | 'world_zeboim'
    | 'world_aveh'
    | 'stone_arch'
    | 'crate_stack'
    | 'well'
    | 'banner';
  x: number;
  z: number;
  rotationY?: number;
  scale?: number;
  label?: string;
}

export interface MapDefinition {
  id: MapId;
  name: string;
  subtitle: string;
  gameState: 'PLAYING_WORLDMAP' | 'PLAYING_TOWN' | 'PLAYING_INTERIOR' | 'PLAYING_DUNGEON';
  ostTrack: OSTTrackId;
  arenaTheme: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps';
  width: number;
  depth: number;
  isOutdoor: boolean;
  skyColor: string;
  fogColor: string;
  fogNear: number;
  fogFar: number;
  sunColor: string;
  sunIntensity: number;
  hemiSkyColor: string;
  hemiGroundColor: string;
  hemiIntensity: number;
  defaultSpawn: { x: number; z: number; facing: Direction };
  tiles: TileType[][];
  heightGrid: number[][];
  collisionGrid: number[][]; // 0 = walkable, 1 = blocked
  buildings: Building3DSpec[];
  props: Prop3DSpec[];
  warpZones: WarpZone[];
  chests: ChestDef[];
  savePoints: SavePointDef[];
  switches?: FloorSwitchDef[];
  encounterZones: EncounterZoneDef[];
  npcs: NpcDef[];
}

export interface DialogueLine {
  speaker: string;
  spriteId?: SpriteId;
  accentColor?: string;
  text: string;
  voicePitch?: number;
  emote?: '!' | '?' | '...' | null;
}

export type CutsceneStep =
  | { type: 'dialogue'; lines: DialogueLine[] }
  | { type: 'emote'; actorId: string; emote: '!' | '?' | '...' }
  | { type: 'face'; actorId: string; facing: Direction }
  | { type: 'move'; actorId: string; path: Array<{ x: number; z: number }> }
  | { type: 'camera_pan'; dx: number; dz: number; durationMs: number }
  | { type: 'fade'; direction: 'out' | 'in'; durationMs: number }
  | { type: 'flash'; color: string; durationMs: number }
  | { type: 'set_flag'; flag: string; value: boolean }
  | { type: 'join_party'; memberId: PartyMember['id'] }
  | { type: 'sfx'; sound: string }
  | { type: 'start_battle'; enemyIds: string[]; isBoss: boolean; allowGears: boolean; arenaTheme: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps'; victoryFlag?: string }
  | { type: 'warp'; mapId: MapId; x: number; z: number; facing: Direction };

export interface CutsceneScript {
  id: string;
  title: string;
  ostTrack?: OSTTrackId;
  steps: CutsceneStep[];
}

export interface EnemyTemplate {
  id: string;
  name: string;
  spriteId: SpriteId;
  isBoss?: boolean;
  isGearScale?: boolean;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
  maxShield: number;
  weaknesses: WeaknessType[];
  xpReward: number;
  gilReward: number;
  dropItemId?: string;
  scale: number;
  skills: Array<{ name: string; multiplier: number; aoe?: boolean; element: WeaknessType }>;
}

export interface BattleEnemyInstance {
  uid: string;
  templateId: string;
  name: string;
  spriteId: SpriteId;
  isBoss: boolean;
  isGearScale: boolean;
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
  shield: number;
  maxShield: number;
  brokenTurns: number;
  weaknesses: WeaknessType[];
  revealedWeaknesses: WeaknessType[];
  xpReward: number;
  gilReward: number;
  dropItemId?: string;
  scale: number;
  animState: 'idle' | 'attack' | 'hurt' | 'ko';
}

export interface BattleContextData {
  enemyIds: string[];
  isBoss: boolean;
  allowGears: boolean;
  arenaTheme: 'ignas_plains' | 'zeboim_ruins' | 'cathedral_steps';
  returnMapId: MapId;
  returnX: number;
  returnZ: number;
  returnFacing: Direction;
  victoryFlag?: string;
}

export interface InteractablePrompt {
  type: 'npc' | 'chest' | 'save' | 'warp' | 'switch' | 'boss';
  id: string;
  label: string;
  x: number;
  z: number;
}
