import { CutsceneScript, DialogueLine } from '../types/rpg';

export interface PrologueBeat {
  era: string;
  year: string;
  title: string;
  body: string;
}

export const PROLOGUE_TIMELINE: PrologueBeat[] = [
  {
    era: 'EPISODE I — THE FALL OF THE ELDRIDGE',
    year: 'T.C. 4767',
    title: 'Ten Thousand Years Ago',
    body: 'An interstellar colony vessel carrying an ancient biological weapon tore through the heavens and crashed upon an uncharted blue world. From its wreckage emerged the first mother and the hidden monolith known as the Zohar.',
  },
  {
    era: 'EPISODE II — THE ZEBOIM CIVILIZATION',
    year: 'YEAR 5999',
    title: 'The Sunken Metropolis',
    body: 'Four millennia ago, humanity reached an age of radiant science beneath the surface of Ignas. Yet genetic decay and war reduced Zeboim to silent concrete ruins—leaving behind only the echoes of Kim Kasim and dormant machines.',
  },
  {
    era: 'EPISODE III — THE CRADLE OF NISAN',
    year: 'YEAR 9499',
    title: 'Five Hundred Years Before the Awakening',
    body: 'Beneath the watchful floating bastion of Shevat and the shadow of Solaris, the Holy Mother Sophia tends the sanctuary of Nisan. Beside her stand the Guard Commander Krelian, the exiled Aveh prince Roni Fatima, and a young painter named Lacan.',
  },
];

export interface QuestObjective {
  id: string;
  title: string;
  summary: string;
  completedFlag?: string;
}

export const EPISODE3_QUESTS: QuestObjective[] = [
  {
    id: 'q1_atelier',
    title: 'Chapter 1: Shadows Over Nisan',
    summary: 'Leave Lacan’s Atelier and proceed north up the stone steps into the Nisan Cathedral to answer Sophia and Krelian’s summons.',
    completedFlag: 'cathedral_summit_done',
  },
  {
    id: 'q2_worldmap',
    title: 'The Golden Tremors of Ignas',
    summary: 'Exit the southern archway of Nisan onto the Ignas World Map and march east to the Zeboim Excavation Ruins.',
    completedFlag: 'zeboim_hologram_seen',
  },
  {
    id: 'q3_puzzle',
    title: 'Echoes of Kim Kasim',
    summary: 'Inspect the Zeboim Archive Hologram and activate the glowing Resonance Floor Switch on the west side of the Conduit Hall to unseal the Boss Sanctum.',
    completedFlag: 'zeboim_gate_unlocked',
  },
  {
    id: 'q4_boss',
    title: 'The Dormant Omnigear',
    summary: 'Save at the Sanctum Memory Cube, confront the Solaris Inquisitor squadron, and defeat the awakened Prototype Diabolos Gear.',
    completedFlag: 'zeboim_boss_defeated',
  },
];

export function getActiveQuest(flags: Record<string, boolean>): QuestObjective {
  for (const q of EPISODE3_QUESTS) {
    if (q.completedFlag && !flags[q.completedFlag]) {
      return q;
    }
  }
  return {
    id: 'q_complete',
    title: 'Chapter 1 Complete — Dawn of the Diabolos War',
    summary: 'Prototype Diabolos has been silenced. Continue exploring Ignas, mastering Deathblows, and preparing the Gears of Nisan for the coming war with Solaris.',
  };
}

export const CUTSCENE_SCRIPTS: Record<string, CutsceneScript> = {
  scene1_atelier_intro: {
    id: 'scene1_atelier_intro',
    title: 'Scene 1 — Lacan’s Atelier',
    ostTrack: 'interior_peaceful',
    steps: [
      {
        type: 'dialogue',
        lines: [
          {
            speaker: 'Lacan',
            spriteId: 'lacan',
            accentColor: '#d4a35a',
            text: 'The ochre light across the cathedral nave... no matter how many layers I glaze, I still cannot capture her expression.',
            voicePitch: 1.0,
          },
          {
            speaker: 'Krelian',
            spriteId: 'krelian',
            accentColor: '#7898d4',
            text: 'Lacan. Put down your brush. Sophia has summoned us to the Cathedral altar at once.',
            voicePitch: 0.94,
            emote: '!',
          },
          {
            speaker: 'Lacan',
            spriteId: 'lacan',
            accentColor: '#d4a35a',
            text: 'Krelian? You look pale. Did the tremors return beneath the eastern hills?',
            voicePitch: 1.0,
          },
          {
            speaker: 'Krelian',
            spriteId: 'krelian',
            accentColor: '#7898d4',
            text: 'Worse. Watchtowers spotted Solaris reconnaissance vessels gliding above the Ignas cloudbank. Come—meet us inside Nisan Cathedral.',
            voicePitch: 0.94,
          },
        ],
      },
      { type: 'set_flag', flag: 'atelier_intro_seen', value: true },
    ],
  },

  scene2_cathedral_summit: {
    id: 'scene2_cathedral_summit',
    title: 'Scene 2 — The Sanctuary Pact',
    ostTrack: 'cutscene_tragic',
    steps: [
      { type: 'emote', actorId: 'npc_cathedral_sophia', emote: '!' },
      {
        type: 'dialogue',
        lines: [
          {
            speaker: 'Sophia',
            spriteId: 'sophia',
            accentColor: '#d87070',
            text: 'Thank you for coming, Lacan. Even when the skies darken, seeing your face brings calm to this hall.',
            voicePitch: 1.24,
          },
          {
            speaker: 'Krelian',
            spriteId: 'krelian',
            accentColor: '#7898d4',
            text: 'Three nights ago, golden pulses shook the Zeboim Excavation Ruins east of Nisan. Now Solaris airships circle the excavation shaft.',
            voicePitch: 0.94,
          },
          {
            speaker: 'Roni Fatima',
            spriteId: 'roni',
            accentColor: '#e0b84c',
            text: 'And they are not merely surveying! Aveh scouts confirmed Solaris Inquisitors hauling Gear frames down into the subterranean chambers.',
            voicePitch: 1.05,
            emote: '!',
          },
          {
            speaker: 'Lacan',
            spriteId: 'lacan',
            accentColor: '#d4a35a',
            text: 'Roni Fatima... You rode all the way from the Aveh border to warn Nisan?',
            voicePitch: 1.0,
          },
          {
            speaker: 'Roni Fatima',
            spriteId: 'roni',
            accentColor: '#e0b84c',
            text: 'If Solaris unearths a Zeboim-era weapon, neither Aveh nor Nisan will survive the season. My blade—and my Gear Andvari—stand with you.',
            voicePitch: 1.05,
          },
          {
            speaker: 'Sophia',
            spriteId: 'sophia',
            accentColor: '#d87070',
            text: 'Then we shall descend together. Exit Nisan to the south, cross the Ignas plains, and uncover what sleeps beneath Zeboim.',
            voicePitch: 1.24,
          },
        ],
      },
      { type: 'set_flag', flag: 'cathedral_summit_done', value: true },
    ],
  },

  scene3_zeboim_hologram: {
    id: 'scene3_zeboim_hologram',
    title: 'Scene 3 — Echoes of Episode II',
    ostTrack: 'cutscene_tragic',
    steps: [
      { type: 'flash', color: '#5ecbff', durationMs: 360 },
      {
        type: 'dialogue',
        lines: [
          {
            speaker: 'Zeboim Archive',
            spriteId: 'npc_hologram',
            accentColor: '#5ecbff',
            text: '[ARCHIVE LOG 4012 — DR. KIM KASIM]: The molecular nanomachines failed to arrest the species limit. Yet the dormant combat frame in Chamber Three still resonates with the Prime Monolith.',
            voicePitch: 1.12,
          },
          {
            speaker: 'Krelian',
            spriteId: 'krelian',
            accentColor: '#7898d4',
            text: 'Nanomachines... four thousand years before our time, a scientist stood in this very vault trying to rewrite human mortality.',
            voicePitch: 0.94,
            emote: '...',
          },
          {
            speaker: 'Sophia',
            spriteId: 'sophia',
            accentColor: '#d87070',
            text: 'Look toward the western conduit pillar—a Resonance Floor Switch still glows. Stepping upon it should unseal the northern bulkhead gate.',
            voicePitch: 1.24,
          },
        ],
      },
      { type: 'set_flag', flag: 'zeboim_hologram_seen', value: true },
    ],
  },

  scene4_zeboim_boss: {
    id: 'scene4_zeboim_boss',
    title: 'Climax — Awakening of Prototype Diabolos',
    ostTrack: 'battle_boss',
    steps: [
      { type: 'emote', actorId: 'npc_solaris_inquisitor', emote: '!' },
      { type: 'flash', color: '#ff5252', durationMs: 420 },
      {
        type: 'dialogue',
        lines: [
          {
            speaker: 'Solaris Inquisitor',
            spriteId: 'npc_solaris',
            accentColor: '#e05858',
            text: 'Lambs of Nisan—and the exile of House Fatima! You are too late. The Zeboim Omnigear prototype has already synchronized with our ether lattice!',
            voicePitch: 0.78,
          },
          {
            speaker: 'Roni Fatima',
            spriteId: 'roni',
            accentColor: '#e0b84c',
            text: 'Look at that silhouette—it’s waking up! Everyone, link with your Gears when the field opens and shatter its Shields!',
            voicePitch: 1.05,
          },
          {
            speaker: 'Lacan',
            spriteId: 'lacan',
            accentColor: '#d4a35a',
            text: 'Stay behind me, Sophia! We will not let Solaris turn this ruin into another war!',
            voicePitch: 1.0,
          },
        ],
      },
      {
        type: 'start_battle',
        enemyIds: ['boss_diabolos', 'solaris_trooper'],
        isBoss: true,
        allowGears: true,
        arenaTheme: 'zeboim_ruins',
        victoryFlag: 'zeboim_boss_defeated',
      },
    ],
  },
};

export const NPC_DIALOGUES: Record<string, DialogueLine[]> = {
  nisan_elder: [
    {
      speaker: 'Brother Tomas',
      spriteId: 'npc_monk',
      accentColor: '#d4b06a',
      text: 'Peace be with you, Lacan. Sophia awaits inside the Cathedral at the top of the stone terrace.',
    },
    {
      speaker: 'Brother Tomas',
      spriteId: 'npc_monk',
      accentColor: '#d4b06a',
      text: 'Remember: the golden Memory Cube in the plaza lets you record your journey across all three archive slots.',
    },
  ],
  nisan_gate_guard: [
    {
      speaker: 'Guard Captain Hal',
      spriteId: 'npc_solaris',
      accentColor: '#7898d4',
      text: 'Beyond this southern arch lies the Ignas Overworld. Watch yourself—Solaris patrols and dune stalkers roam the plains.',
    },
  ],
  nisan_scholar: [
    {
      speaker: 'Archivist Meriel',
      spriteId: 'npc_villager',
      accentColor: '#b5a3d8',
      text: 'Shevat’s sky-scholars whisper that the ruins east of here predate even the founding of Solaris by four thousand years.',
    },
  ],
  nisan_child: [
    {
      speaker: 'Young Luca',
      spriteId: 'npc_child',
      accentColor: '#e0b84c',
      text: 'Hey Lacan! Are you really painting the Holy Mother’s portrait for the grand altar? I saw the lanterns flickering on the canal bridge!',
    },
  ],
  nisan_florist: [
    {
      speaker: 'Sister Clara',
      spriteId: 'npc_monk',
      accentColor: '#d87070',
      text: 'Stained glass catches the sunset differently each evening. Walk right through the recessed cathedral archway to step inside.',
    },
  ],
  nisan_angler: [
    {
      speaker: 'Old Man Gaspard',
      spriteId: 'npc_villager',
      accentColor: '#6cb0cc',
      text: 'The canal water went ripple-crazy during last night’s tremor. Something colossal is humming deep under Ignas.',
    },
  ],
  nisan_peddler: [
    {
      speaker: 'Peddler Oren',
      spriteId: 'npc_merchant',
      accentColor: '#d4a35a',
      text: 'Need fresh Aquasols, blades, or Gear armor plating? Step right inside the Inn & Armory behind me—Master Galahad just forged fresh stock!',
    },
  ],
  nisan_solaris_spy: [
    {
      speaker: 'Cloaked Traveler',
      spriteId: 'npc_solaris',
      accentColor: '#c45454',
      text: '...Hmph. Just passing through Nisan. Pay no mind to the brass compass on my lapel.',
    },
  ],
  cathedral_krelian: [
    {
      speaker: 'Krelian',
      spriteId: 'krelian',
      accentColor: '#7898d4',
      text: 'The Zeboim ruins lie across the eastern road on the Ignas World Map. Stock up on Aquasol and Zohar Fuel Cells before we descend.',
    },
  ],
  cathedral_cantor: [
    {
      speaker: 'Brother Aldous',
      spriteId: 'npc_monk',
      accentColor: '#d4b06a',
      text: 'Our hymns echo through the nave for those lost in the ancient wars. May the portrait of Sophia watch over Nisan forever.',
    },
  ],
  cathedral_pilgrim: [
    {
      speaker: 'Pilgrim Elena',
      spriteId: 'npc_villager',
      accentColor: '#d87070',
      text: 'I walked three days from Aveh to see the sanctuary light fall across this marble floor. It truly feels untouched by war.',
    },
  ],
  atelier_apprentice: [
    {
      speaker: 'Apprentice Theo',
      spriteId: 'npc_child',
      accentColor: '#d4a35a',
      text: 'I ground fresh lapis lazuli and gold leaf for your easel, Master Lacan! Don’t keep Lady Sophia waiting at the Cathedral!',
    },
  ],
  tavern_bard: [
    {
      speaker: 'Minstrel Doran',
      spriteId: 'npc_villager',
      accentColor: '#e0b84c',
      text: 'They say five hundred years from now, songs will still remember the painter of Nisan and the prince of Aveh.',
    },
  ],
  tavern_tech: [
    {
      speaker: 'Mercenary Vane',
      spriteId: 'npc_solaris',
      accentColor: '#6cb0cc',
      text: 'Combat tip: chain Weak [T], Medium [S], and Strong [X] strikes to unleash Deathblows like Raijin and Kishin—and shatter enemy Shields for 2x BREAK damage!',
    },
  ],
  aveh_post_guard: [
    {
      speaker: 'Aveh Border Captain',
      spriteId: 'npc_solaris',
      accentColor: '#e0b84c',
      text: 'Hail, Prince Roni and companions of Nisan! Feel free to take the Zohar Fuel Cells from our supply crate to the south. Zeboim Ruins lie straight east along the cobbled road.',
    },
  ],
};
