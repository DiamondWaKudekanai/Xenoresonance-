import {
  Building3DSpec,
  MapDefinition,
  MapId,
  Prop3DSpec,
  TileType,
} from '../../types/rpg';

function makeGrid<T>(width: number, depth: number, fill: T): T[][] {
  return Array.from({ length: depth }, () => Array.from({ length: width }, () => fill));
}

function fillRect<T>(
  grid: T[][],
  x0: number,
  z0: number,
  w: number,
  d: number,
  val: T
) {
  for (let z = z0; z < z0 + d; z++) {
    if (z < 0 || z >= grid.length) continue;
    for (let x = x0; x < x0 + w; x++) {
      if (x < 0 || x >= grid[0].length) continue;
      grid[z][x] = val;
    }
  }
}

function applyBuildingsToCollision(
  collision: number[][],
  buildings: Building3DSpec[]
) {
  for (const b of buildings) {
    fillRect(collision, b.x, b.z, b.width, b.depth, 1);
    // Keep recessed doorway tile & approach tile walkable
    if (b.doorTile) {
      if (collision[b.doorTile.z] && collision[b.doorTile.z][b.doorTile.x] !== undefined) {
        collision[b.doorTile.z][b.doorTile.x] = 0;
      }
      if (collision[b.doorTile.z + 1] && collision[b.doorTile.z + 1][b.doorTile.x] !== undefined) {
        collision[b.doorTile.z + 1][b.doorTile.x] = 0;
      }
    }
  }
}

// ============================================================================
// MAP 1: WORLD MAP — IGNAS CONTINENT (32 x 24)
// ============================================================================
function buildWorldmapIgnas(): MapDefinition {
  const width = 32;
  const depth = 24;
  const tiles = makeGrid<TileType>(width, depth, 'water');
  const heightGrid = makeGrid<number>(width, depth, 0);
  const collisionGrid = makeGrid<number>(width, depth, 1);

  // Main Ignas landmass
  fillRect(tiles, 3, 3, 26, 18, 'grass');
  fillRect(collisionGrid, 3, 3, 26, 18, 0);
  fillRect(heightGrid, 3, 3, 26, 18, 0.25);

  // Taper coastlines cleanly
  fillRect(tiles, 3, 3, 3, 2, 'water');
  fillRect(collisionGrid, 3, 3, 3, 2, 1);
  fillRect(heightGrid, 3, 3, 3, 2, 0);

  fillRect(tiles, 26, 18, 3, 3, 'water');
  fillRect(collisionGrid, 26, 18, 3, 3, 1);
  fillRect(heightGrid, 26, 18, 3, 3, 0);

  // Western Ignas Golden Desert (toward Aveh Border Post)
  fillRect(tiles, 4, 11, 11, 9, 'sand');
  // Northern Mountain Spine around Nisan highlands
  fillRect(tiles, 7, 3, 18, 3, 'mountain');
  fillRect(collisionGrid, 7, 3, 18, 3, 1);
  fillRect(heightGrid, 7, 3, 18, 3, 1.4);

  // Eastern Zeboim Badlands & Pines
  fillRect(tiles, 19, 6, 9, 7, 'forest');
  fillRect(tiles, 21, 13, 6, 5, 'sand');

  // Mountain ridge dividing north & south with pass
  fillRect(tiles, 14, 11, 2, 4, 'mountain');
  fillRect(collisionGrid, 14, 11, 2, 4, 1);
  fillRect(heightGrid, 14, 11, 2, 4, 1.3);

  // Cobble roads linking Town of Nisan (11,8), Aveh Border Post (7,16), Zeboim Ruins (24,15)
  fillRect(tiles, 11, 8, 2, 9, 'cobble');
  fillRect(tiles, 7, 16, 18, 2, 'cobble');
  fillRect(tiles, 23, 14, 2, 3, 'cobble');
  // Ensure road tiles are walkable
  fillRect(collisionGrid, 11, 8, 2, 9, 0);
  fillRect(collisionGrid, 7, 16, 18, 2, 0);
  fillRect(collisionGrid, 23, 14, 2, 3, 0);

  const props: Prop3DSpec[] = [
    { id: 'wm_nisan', type: 'world_nisan', x: 11, z: 7, label: 'Town of Nisan' },
    { id: 'wm_zeboim', type: 'world_zeboim', x: 24, z: 14, label: 'Zeboim Excavation Ruins' },
    { id: 'wm_aveh', type: 'world_aveh', x: 6, z: 16, label: 'Aveh Border Post' },
    // Pine grove accents
    { id: 'wm_tree_1', type: 'tree_pine', x: 20, z: 8, scale: 0.75 },
    { id: 'wm_tree_2', type: 'tree_pine', x: 22, z: 9, scale: 0.8 },
    { id: 'wm_tree_3', type: 'tree_pine', x: 25, z: 8, scale: 0.7 },
    { id: 'wm_tree_4', type: 'tree_pine', x: 19, z: 11, scale: 0.85 },
    { id: 'wm_tree_5', type: 'tree_pine', x: 8, z: 8, scale: 0.75 },
    { id: 'wm_tree_6', type: 'tree_pine', x: 15, z: 8, scale: 0.72 },
  ];

  return {
    id: 'worldmap_ignas',
    name: 'Ignas Continent',
    subtitle: 'Overworld — Year 9499',
    gameState: 'PLAYING_WORLDMAP',
    ostTrack: 'worldmap',
    arenaTheme: 'ignas_plains',
    width,
    depth,
    isOutdoor: true,
    skyColor: '#4c6d92',
    fogColor: '#6f8aa8',
    fogNear: 18,
    fogFar: 46,
    sunColor: '#ffe0b5',
    sunIntensity: 2.1,
    hemiSkyColor: '#90b8e4',
    hemiGroundColor: '#5c4b37',
    hemiIntensity: 0.9,
    defaultSpawn: { x: 11, z: 9, facing: 'S' },
    tiles,
    heightGrid,
    collisionGrid,
    buildings: [],
    props,
    warpZones: [
      {
        id: 'warp_to_nisan',
        x: 11,
        z: 8,
        targetMap: 'town_nisan',
        targetX: 15,
        targetZ: 23,
        targetFacing: 'N',
        label: 'Enter Town of Nisan',
      },
      {
        id: 'warp_to_zeboim',
        x: 24,
        z: 15,
        targetMap: 'dungeon_zeboim_ruins',
        targetX: 12,
        targetZ: 24,
        targetFacing: 'N',
        label: 'Enter Zeboim Ruins',
      },
    ],
    chests: [
      {
        id: 'chest_world_aveh_supply',
        x: 8,
        z: 18,
        facing: 'S',
        rewardItemId: 'zohar_fuel',
        rewardQty: 2,
        label: 'Aveh Supply Crate',
      },
    ],
    savePoints: [
      {
        id: 'save_world_crossroads',
        x: 17,
        z: 15,
        label: 'Ignas Crossroads Memory Cube',
      },
    ],
    encounterZones: [
      {
        minX: 4,
        maxX: 27,
        minZ: 6,
        maxZ: 20,
        stepThresholdMin: 12,
        stepThresholdMax: 20,
        enemyGroups: [
          ['ignas_sandworm', 'ignas_sandworm'],
          ['solaris_trooper', 'ignas_sandworm'],
          ['solaris_trooper', 'solaris_trooper'],
        ],
        arenaTheme: 'ignas_plains',
      },
    ],
    npcs: [
      {
        id: 'npc_aveh_border_guard',
        name: 'Aveh Border Captain',
        role: 'Border Sentinel',
        spriteId: 'npc_solaris',
        x: 7,
        z: 15,
        facing: 'E',
        behavior: 'LOOK_AROUND',
        dialogueId: 'aveh_post_guard',
        voicePitch: 0.9,
      },
    ],
  };
}

// ============================================================================
// MAP 2: TOWN OF NISAN — MAIN TOWN EXTERIOR (30 x 26)
// ============================================================================
function buildTownNisan(): MapDefinition {
  const width = 30;
  const depth = 26;
  const tiles = makeGrid<TileType>(width, depth, 'grass');
  const heightGrid = makeGrid<number>(width, depth, 0);
  const collisionGrid = makeGrid<number>(width, depth, 0);

  // Outer stone perimeter cliffs/hedges (natural town edge)
  for (let x = 0; x < width; x++) {
    collisionGrid[0][x] = 1;
    collisionGrid[1][x] = 1;
    collisionGrid[depth - 1][x] = 1;
  }
  for (let z = 0; z < depth; z++) {
    collisionGrid[z][0] = 1;
    collisionGrid[z][width - 1] = 1;
  }
  // Open south gate to World Map
  collisionGrid[depth - 1][14] = 0;
  collisionGrid[depth - 1][15] = 0;

  // Raised Upper Cathedral Terrace (height = 1.0)
  fillRect(tiles, 6, 2, 18, 11, 'stone_plaza');
  fillRect(heightGrid, 6, 2, 18, 11, 1.0);

  // Mid Plaza Terrace (height = 0.5)
  fillRect(tiles, 3, 13, 24, 6, 'cobble');
  fillRect(heightGrid, 3, 13, 24, 6, 0.5);

  // Stairways connecting Mid Plaza (0.5) -> Upper Terrace (1.0)
  fillRect(tiles, 14, 12, 2, 1, 'stair_n');
  fillRect(heightGrid, 14, 12, 2, 1, 0.75);

  // Block ledge edge between terrace & mid plaza except at stairs
  for (let x = 6; x < 24; x++) {
    if (x !== 14 && x !== 15) {
      collisionGrid[12][x] = 1;
    }
  }

  // Sparkling Canal running East-West at z = 19..20
  fillRect(tiles, 1, 19, width - 2, 2, 'water');
  fillRect(collisionGrid, 1, 19, width - 2, 2, 1);
  fillRect(heightGrid, 1, 19, width - 2, 2, -0.2);

  // Arched Wooden Bridge spanning the canal at x = 14..15, z = 19..20
  fillRect(tiles, 14, 19, 2, 2, 'bridge');
  fillRect(collisionGrid, 14, 19, 2, 2, 0);
  fillRect(heightGrid, 14, 19, 2, 2, 0.35);

  // Lower South Promenade (z = 21..25)
  fillRect(tiles, 13, 21, 4, 5, 'cobble');
  fillRect(heightGrid, 13, 21, 4, 5, 0.15);
  // Step down from mid plaza to bridge
  fillRect(tiles, 14, 18, 2, 1, 'stair_s');
  fillRect(heightGrid, 14, 18, 2, 1, 0.42);

  // Central cobbled avenue to buildings
  fillRect(tiles, 5, 16, 20, 2, 'cobble');

  // 3D Modular Buildings with Exact Octopath Proportions & Real Recessed Doorways
  const buildings: Building3DSpec[] = [
    {
      id: 'nisan_cathedral',
      name: 'Nisan Cathedral',
      x: 9,
      z: 2,
      width: 12,
      height: 8.5,
      depth: 9,
      wallStyle: 'cathedral',
      roofStyle: 'cathedral_spire',
      doorTile: { x: 15, z: 10 },
      windowCount: 4,
    },
    {
      id: 'lacan_atelier',
      name: "Lacan's Atelier",
      x: 3,
      z: 12,
      width: 6,
      height: 4.2,
      depth: 5,
      wallStyle: 'stucco',
      roofStyle: 'pitched_clay',
      doorTile: { x: 6, z: 16 },
      windowCount: 2,
    },
    {
      id: 'nisan_inn_shop',
      name: 'Nisan Inn & Armory',
      x: 20,
      z: 12,
      width: 7,
      height: 4.6,
      depth: 5,
      wallStyle: 'stone',
      roofStyle: 'pitched_slate',
      doorTile: { x: 23, z: 16 },
      windowCount: 3,
    },
  ];
  applyBuildingsToCollision(collisionGrid, buildings);

  // Keep doorway approach clear on terrace/plaza
  collisionGrid[11][15] = 0;
  collisionGrid[11][14] = 0;
  collisionGrid[17][6] = 0;
  collisionGrid[17][23] = 0;

  const props: Prop3DSpec[] = [
    // Warm flickering lanterns (capped <= 5 active lights)
    { id: 'lan_1', type: 'lantern', x: 13, z: 11 },
    { id: 'lan_2', type: 'lantern', x: 17, z: 11 },
    { id: 'lan_3', type: 'lantern', x: 13, z: 18 },
    { id: 'lan_4', type: 'lantern', x: 16, z: 18 },
    { id: 'lan_5', type: 'lantern', x: 8, z: 17 },
    { id: 'lan_6', type: 'lantern', x: 21, z: 17 },
    // Trees framing outer meadow
    { id: 'tree_1', type: 'tree_oak', x: 3, z: 5, scale: 1.1 },
    { id: 'tree_2', type: 'tree_pine', x: 26, z: 5, scale: 1.15 },
    { id: 'tree_3', type: 'tree_oak', x: 5, z: 22, scale: 1.05 },
    { id: 'tree_4', type: 'tree_pine', x: 8, z: 23, scale: 0.95 },
    { id: 'tree_5', type: 'tree_oak', x: 23, z: 22, scale: 1.1 },
    { id: 'tree_6', type: 'tree_pine', x: 26, z: 23, scale: 1.0 },
    // Plaza details
    { id: 'well_plaza', type: 'well', x: 11, z: 15 },
    { id: 'crates_inn', type: 'crate_stack', x: 27, z: 16 },
    { id: 'south_arch', type: 'stone_arch', x: 14.5, z: 24.5 },
    { id: 'banner_l', type: 'banner', x: 11, z: 11 },
    { id: 'banner_r', type: 'banner', x: 19, z: 11 },
  ];
  collisionGrid[15][11] = 1; // well

  return {
    id: 'town_nisan',
    name: 'Town of Nisan',
    subtitle: 'Holy Sanctuary of Ignas',
    gameState: 'PLAYING_TOWN',
    ostTrack: 'town_nisan',
    arenaTheme: 'cathedral_steps',
    width,
    depth,
    isOutdoor: true,
    skyColor: '#485d82',
    fogColor: '#697c9c',
    fogNear: 18,
    fogFar: 44,
    sunColor: '#ffd49b',
    sunIntensity: 2.2,
    hemiSkyColor: '#8eb2df',
    hemiGroundColor: '#56473d',
    hemiIntensity: 0.85,
    defaultSpawn: { x: 15, z: 17, facing: 'N' },
    tiles,
    heightGrid,
    collisionGrid,
    buildings,
    props,
    warpZones: [
      {
        id: 'warp_cathedral_in',
        x: 15,
        z: 10,
        targetMap: 'interior_cathedral',
        targetX: 8,
        targetZ: 15,
        targetFacing: 'N',
        label: 'Enter Nisan Cathedral',
      },
      {
        id: 'warp_atelier_in',
        x: 6,
        z: 16,
        targetMap: 'interior_atelier',
        targetX: 6,
        targetZ: 8,
        targetFacing: 'N',
        label: "Enter Lacan's Atelier",
      },
      {
        id: 'warp_inn_in',
        x: 23,
        z: 16,
        targetMap: 'interior_inn_shop',
        targetX: 7,
        targetZ: 10,
        targetFacing: 'N',
        label: 'Enter Inn & Armory',
      },
      {
        id: 'warp_world_out',
        x: 14,
        z: 25,
        width: 2,
        targetMap: 'worldmap_ignas',
        targetX: 11,
        targetZ: 9,
        targetFacing: 'S',
        label: 'Exit to Ignas World Map',
      },
    ],
    chests: [
      {
        id: 'chest_nisan_east_plaza',
        x: 25,
        z: 10,
        facing: 'S',
        rewardGil: 180,
        label: 'Sanctuary Offering Box',
      },
      {
        id: 'chest_nisan_canal_bank',
        x: 9,
        z: 22,
        facing: 'E',
        rewardItemId: 'rosesol',
        rewardQty: 2,
        label: 'Herb Satchel',
      },
    ],
    savePoints: [
      {
        id: 'save_nisan_square',
        x: 18,
        z: 14,
        label: 'Nisan Plaza Memory Cube',
      },
    ],
    encounterZones: [], // ZERO random battles inside Towns!
    npcs: [
      {
        id: 'npc_nisan_elder',
        name: 'Brother Tomas',
        role: 'Nisan Elder',
        spriteId: 'npc_monk',
        x: 13,
        z: 13,
        facing: 'S',
        behavior: 'LOOK_AROUND',
        dialogueId: 'nisan_elder',
        voicePitch: 0.82,
      },
      {
        id: 'npc_nisan_guard',
        name: 'Guard Captain Hal',
        role: 'Sanctuary Watch',
        spriteId: 'npc_solaris',
        x: 16,
        z: 22,
        facing: 'N',
        behavior: 'PATROL_WAYPOINTS',
        waypoints: [
          { x: 16, z: 22 },
          { x: 19, z: 22 },
          { x: 19, z: 24 },
          { x: 16, z: 24 },
        ],
        dialogueId: 'nisan_gate_guard',
        voicePitch: 0.92,
      },
      {
        id: 'npc_nisan_scholar',
        name: 'Archivist Meriel',
        role: 'Shevat Historian',
        spriteId: 'npc_villager',
        x: 9,
        z: 14,
        facing: 'E',
        behavior: 'PATROL_WAYPOINTS',
        waypoints: [
          { x: 9, z: 14 },
          { x: 13, z: 14 },
          { x: 13, z: 16 },
          { x: 9, z: 16 },
        ],
        dialogueId: 'nisan_scholar',
        voicePitch: 1.15,
      },
      {
        id: 'npc_nisan_child',
        name: 'Young Luca',
        role: 'Town Child',
        spriteId: 'npc_child',
        x: 17,
        z: 16,
        facing: 'W',
        behavior: 'PATROL_WAYPOINTS',
        waypoints: [
          { x: 17, z: 16 },
          { x: 20, z: 16 },
          { x: 20, z: 18 },
          { x: 17, z: 18 },
        ],
        dialogueId: 'nisan_child',
        voicePitch: 1.38,
      },
      {
        id: 'npc_nisan_florist',
        name: 'Sister Clara',
        role: 'Cathedral Keeper',
        spriteId: 'npc_monk',
        x: 18,
        z: 11,
        facing: 'S',
        behavior: 'STATIONARY',
        dialogueId: 'nisan_florist',
        voicePitch: 1.22,
      },
      {
        id: 'npc_nisan_angler',
        name: 'Old Man Gaspard',
        role: 'Canal Watch',
        spriteId: 'npc_villager',
        x: 11,
        z: 21,
        facing: 'N',
        behavior: 'STATIONARY',
        dialogueId: 'nisan_angler',
        voicePitch: 0.78,
      },
      {
        id: 'npc_nisan_merchant_street',
        name: 'Peddler Oren',
        role: 'Ignas Caravaner',
        spriteId: 'npc_merchant',
        x: 21,
        z: 17,
        facing: 'S',
        behavior: 'LOOK_AROUND',
        dialogueId: 'nisan_peddler',
        voicePitch: 0.96,
      },
      {
        id: 'npc_solaris_spy',
        name: 'Cloaked Traveler',
        role: 'Suspicious Scout',
        spriteId: 'npc_solaris',
        x: 24,
        z: 21,
        facing: 'W',
        behavior: 'LOOK_AROUND',
        dialogueId: 'nisan_solaris_spy',
        voicePitch: 0.88,
      },
    ],
  };
}

// ============================================================================
// MAP 3: NISAN CATHEDRAL INTERIOR (16 x 18)
// ============================================================================
function buildInteriorCathedral(): MapDefinition {
  const width = 16;
  const depth = 18;
  const tiles = makeGrid<TileType>(width, depth, 'marble_checker');
  const heightGrid = makeGrid<number>(width, depth, 0);
  const collisionGrid = makeGrid<number>(width, depth, 0);

  // Sanctuary outer walls (cut-away south wall open for Octopath diorama camera)
  for (let x = 0; x < width; x++) {
    tiles[0][x] = 'wall_stone';
    tiles[1][x] = 'wall_stone';
    collisionGrid[0][x] = 1;
    collisionGrid[1][x] = 1;
    collisionGrid[depth - 1][x] = 1;
  }
  for (let z = 0; z < depth; z++) {
    tiles[z][0] = 'wall_stone';
    tiles[z][width - 1] = 'wall_stone';
    collisionGrid[z][0] = 1;
    collisionGrid[z][width - 1] = 1;
  }

  // Raised Altar Dais at North end (z = 2..5)
  fillRect(tiles, 4, 2, 8, 4, 'stone_plaza');
  fillRect(heightGrid, 4, 2, 8, 4, 0.45);
  fillRect(tiles, 7, 5, 2, 1, 'stair_n');
  fillRect(heightGrid, 7, 5, 2, 1, 0.22);

  // Crimson Sanctuary Carpet down the center aisle
  fillRect(tiles, 7, 6, 2, 10, 'rug_red');
  collisionGrid[16][7] = 0;
  collisionGrid[16][8] = 0;

  const props: Prop3DSpec[] = [
    { id: 'altar_sophia', type: 'altar_sophia', x: 7.5, z: 2.8 },
    // Stained glass windows with volumetric sunbeams along north & side walls
    { id: 'sg_1', type: 'stained_glass', x: 4, z: 1.6 },
    { id: 'sg_2', type: 'stained_glass', x: 7.5, z: 1.6 },
    { id: 'sg_3', type: 'stained_glass', x: 11, z: 1.6 },
    // Wooden pews (left and right aisles)
    { id: 'pew_l1', type: 'pew', x: 4, z: 8 },
    { id: 'pew_l2', type: 'pew', x: 4, z: 10 },
    { id: 'pew_l3', type: 'pew', x: 4, z: 12 },
    { id: 'pew_r1', type: 'pew', x: 11, z: 8 },
    { id: 'pew_r2', type: 'pew', x: 11, z: 10 },
    { id: 'pew_r3', type: 'pew', x: 11, z: 12 },
    // Warm sanctuary candle stands
    { id: 'cath_lan_1', type: 'lantern', x: 5, z: 4 },
    { id: 'cath_lan_2', type: 'lantern', x: 10, z: 4 },
    { id: 'cath_lan_3', type: 'lantern', x: 6, z: 14 },
    { id: 'cath_lan_4', type: 'lantern', x: 9, z: 14 },
  ];

  // Pew collisions
  for (const z of [8, 10, 12]) {
    fillRect(collisionGrid, 3, z, 3, 1, 1);
    fillRect(collisionGrid, 10, z, 3, 1, 1);
  }
  fillRect(collisionGrid, 6, 2, 4, 2, 1); // Altar

  return {
    id: 'interior_cathedral',
    name: 'Nisan Cathedral',
    subtitle: 'Sanctuary of the Holy Mother',
    gameState: 'PLAYING_INTERIOR',
    ostTrack: 'interior_peaceful',
    arenaTheme: 'cathedral_steps',
    width,
    depth,
    isOutdoor: false,
    skyColor: '#151b2b',
    fogColor: '#1b2236',
    fogNear: 18,
    fogFar: 38,
    sunColor: '#ffe4b5',
    sunIntensity: 1.7,
    hemiSkyColor: '#98b6e6',
    hemiGroundColor: '#57483e',
    hemiIntensity: 0.9,
    defaultSpawn: { x: 8, z: 15, facing: 'N' },
    tiles,
    heightGrid,
    collisionGrid,
    buildings: [],
    props,
    warpZones: [
      {
        id: 'warp_cathedral_out',
        x: 7,
        z: 16,
        width: 2,
        targetMap: 'town_nisan',
        targetX: 15,
        targetZ: 11,
        targetFacing: 'S',
        label: 'Exit to Town of Nisan',
      },
    ],
    chests: [
      {
        id: 'chest_cathedral_reliquary',
        x: 13,
        z: 4,
        facing: 'W',
        rewardItemId: 'zohar_pendant',
        rewardQty: 1,
        label: 'Cathedral Reliquary',
      },
    ],
    savePoints: [],
    encounterZones: [],
    npcs: [
      {
        id: 'npc_cathedral_sophia',
        name: 'Sophia',
        role: 'Holy Mother of Nisan',
        spriteId: 'sophia',
        x: 7,
        z: 4,
        facing: 'S',
        behavior: 'STATIONARY',
        dialogueId: 'cathedral_sophia_story',
        voicePitch: 1.24,
      },
      {
        id: 'npc_cathedral_krelian',
        name: 'Krelian',
        role: 'Nisan Guard Commander',
        spriteId: 'krelian',
        x: 9,
        z: 4,
        facing: 'S',
        behavior: 'STATIONARY',
        dialogueId: 'cathedral_krelian',
        voicePitch: 0.95,
      },
      {
        id: 'npc_cathedral_cantor',
        name: 'Brother Aldous',
        role: 'Choir Cantor',
        spriteId: 'npc_monk',
        x: 2,
        z: 7,
        facing: 'E',
        behavior: 'LOOK_AROUND',
        dialogueId: 'cathedral_cantor',
        voicePitch: 0.85,
      },
      {
        id: 'npc_cathedral_pilgrim',
        name: 'Pilgrim Elena',
        role: 'Aveh Traveler',
        spriteId: 'npc_villager',
        x: 13,
        z: 11,
        facing: 'W',
        behavior: 'STATIONARY',
        dialogueId: 'cathedral_pilgrim',
        voicePitch: 1.18,
      },
    ],
  };
}

// ============================================================================
// MAP 4: LACAN'S ATELIER INTERIOR (12 x 10)
// ============================================================================
function buildInteriorAtelier(): MapDefinition {
  const width = 12;
  const depth = 10;
  const tiles = makeGrid<TileType>(width, depth, 'wood_floor');
  const heightGrid = makeGrid<number>(width, depth, 0);
  const collisionGrid = makeGrid<number>(width, depth, 0);

  for (let x = 0; x < width; x++) {
    tiles[0][x] = 'wall_wood';
    collisionGrid[0][x] = 1;
    collisionGrid[depth - 1][x] = 1;
  }
  for (let z = 0; z < depth; z++) {
    tiles[z][0] = 'wall_wood';
    tiles[z][width - 1] = 'wall_wood';
    collisionGrid[z][0] = 1;
    collisionGrid[z][width - 1] = 1;
  }

  // Exit rug
  fillRect(tiles, 5, 8, 2, 1, 'rug_red');
  collisionGrid[8][5] = 0;
  collisionGrid[8][6] = 0;

  const props: Prop3DSpec[] = [
    { id: 'atelier_easel_1', type: 'easel', x: 5, z: 3 },
    { id: 'atelier_easel_2', type: 'easel', x: 7, z: 3 },
    { id: 'atelier_table', type: 'paint_table', x: 3, z: 4 },
    { id: 'atelier_bed', type: 'bed', x: 9, z: 3 },
    { id: 'atelier_shelf', type: 'bookshelf', x: 2, z: 1.5 },
    { id: 'atelier_fire', type: 'fireplace', x: 6, z: 1.4 },
    { id: 'atelier_lan', type: 'lantern', x: 9, z: 6 },
  ];

  collisionGrid[3][5] = 1;
  collisionGrid[3][7] = 1;
  collisionGrid[4][3] = 1;
  collisionGrid[3][9] = 1;
  collisionGrid[2][9] = 1;
  collisionGrid[1][2] = 1;
  collisionGrid[1][6] = 1;

  return {
    id: 'interior_atelier',
    name: "Lacan's Atelier",
    subtitle: 'Painter Workshop — Nisan West Quarter',
    gameState: 'PLAYING_INTERIOR',
    ostTrack: 'interior_peaceful',
    arenaTheme: 'cathedral_steps',
    width,
    depth,
    isOutdoor: false,
    skyColor: '#1a1512',
    fogColor: '#231b16',
    fogNear: 14,
    fogFar: 32,
    sunColor: '#ffcf96',
    sunIntensity: 1.4,
    hemiSkyColor: '#b59d84',
    hemiGroundColor: '#4c3828',
    hemiIntensity: 0.9,
    defaultSpawn: { x: 6, z: 6, facing: 'N' },
    tiles,
    heightGrid,
    collisionGrid,
    buildings: [],
    props,
    warpZones: [
      {
        id: 'warp_atelier_out',
        x: 5,
        z: 8,
        width: 2,
        targetMap: 'town_nisan',
        targetX: 6,
        targetZ: 17,
        targetFacing: 'S',
        label: 'Exit to Town of Nisan',
      },
    ],
    chests: [
      {
        id: 'chest_atelier_pigments',
        x: 2,
        z: 6,
        facing: 'E',
        rewardItemId: 'aquasol',
        rewardQty: 3,
        label: 'Atelier Supply Trunk',
      },
    ],
    savePoints: [],
    encounterZones: [],
    npcs: [
      {
        id: 'npc_atelier_apprentice',
        name: 'Apprentice Theo',
        role: 'Studio Assistant',
        spriteId: 'npc_child',
        x: 3,
        z: 6,
        facing: 'N',
        behavior: 'LOOK_AROUND',
        dialogueId: 'atelier_apprentice',
        voicePitch: 1.28,
      },
    ],
  };
}

// ============================================================================
// MAP 5: NISAN INN, TAVERN & ARMORY INTERIOR (14 x 12)
// ============================================================================
function buildInteriorInnShop(): MapDefinition {
  const width = 14;
  const depth = 12;
  const tiles = makeGrid<TileType>(width, depth, 'wood_floor');
  const heightGrid = makeGrid<number>(width, depth, 0);
  const collisionGrid = makeGrid<number>(width, depth, 0);

  for (let x = 0; x < width; x++) {
    tiles[0][x] = 'wall_wood';
    collisionGrid[0][x] = 1;
    collisionGrid[depth - 1][x] = 1;
  }
  for (let z = 0; z < depth; z++) {
    tiles[z][0] = 'wall_wood';
    tiles[z][width - 1] = 'wall_wood';
    collisionGrid[z][0] = 1;
    collisionGrid[z][width - 1] = 1;
  }

  fillRect(tiles, 6, 10, 2, 1, 'rug_red');
  collisionGrid[10][6] = 0;
  collisionGrid[10][7] = 0;

  const props: Prop3DSpec[] = [
    { id: 'inn_counter_l', type: 'tavern_counter', x: 3.5, z: 3 },
    { id: 'inn_counter_c', type: 'tavern_counter', x: 7, z: 3 },
    { id: 'inn_counter_r', type: 'tavern_counter', x: 10.5, z: 3 },
    { id: 'inn_table_1', type: 'tavern_table', x: 3.5, z: 7 },
    { id: 'inn_table_2', type: 'tavern_table', x: 10.5, z: 7 },
    { id: 'inn_fire', type: 'fireplace', x: 7, z: 1.3 },
    { id: 'inn_lan_1', type: 'lantern', x: 2, z: 5 },
    { id: 'inn_lan_2', type: 'lantern', x: 12, z: 5 },
  ];

  // Counter & table collisions (leave approach spaces in front of each merchant!)
  fillRect(collisionGrid, 2, 3, 10, 1, 1);
  collisionGrid[7][3] = 1;
  collisionGrid[7][4] = 1;
  collisionGrid[7][10] = 1;
  collisionGrid[7][11] = 1;

  return {
    id: 'interior_inn_shop',
    name: 'Nisan Inn & Armory',
    subtitle: 'Rest, Provisions & Gear Parts',
    gameState: 'PLAYING_INTERIOR',
    ostTrack: 'interior_peaceful',
    arenaTheme: 'cathedral_steps',
    width,
    depth,
    isOutdoor: false,
    skyColor: '#191410',
    fogColor: '#241c15',
    fogNear: 14,
    fogFar: 32,
    sunColor: '#ffcb8c',
    sunIntensity: 1.45,
    hemiSkyColor: '#bca182',
    hemiGroundColor: '#4a3625',
    hemiIntensity: 0.9,
    defaultSpawn: { x: 7, z: 9, facing: 'N' },
    tiles,
    heightGrid,
    collisionGrid,
    buildings: [],
    props,
    warpZones: [
      {
        id: 'warp_inn_out',
        x: 6,
        z: 10,
        width: 2,
        targetMap: 'town_nisan',
        targetX: 23,
        targetZ: 17,
        targetFacing: 'S',
        label: 'Exit to Town of Nisan',
      },
    ],
    chests: [],
    savePoints: [],
    encounterZones: [],
    npcs: [
      {
        id: 'npc_innkeeper',
        name: 'Innkeeper Marta',
        role: 'Rest (50 G)',
        spriteId: 'npc_merchant',
        x: 3,
        z: 4,
        facing: 'S',
        behavior: 'STATIONARY',
        shopType: 'inn',
        voicePitch: 1.12,
      },
      {
        id: 'npc_armory_smith',
        name: 'Master Smith Galahad',
        role: 'Armory & Gear Parts',
        spriteId: 'npc_merchant',
        x: 7,
        z: 4,
        facing: 'S',
        behavior: 'STATIONARY',
        shopType: 'armory',
        voicePitch: 0.82,
      },
      {
        id: 'npc_item_apothecary',
        name: 'Apothecary Mina',
        role: 'Items & Fuel Cells',
        spriteId: 'npc_villager',
        x: 11,
        z: 4,
        facing: 'S',
        behavior: 'STATIONARY',
        shopType: 'items',
        voicePitch: 1.25,
      },
      {
        id: 'npc_tavern_bard',
        name: 'Minstrel Doran',
        role: 'Traveling Bard',
        spriteId: 'npc_villager',
        x: 2,
        z: 7,
        facing: 'E',
        behavior: 'LOOK_AROUND',
        dialogueId: 'tavern_bard',
        voicePitch: 1.02,
      },
      {
        id: 'npc_tavern_caravan',
        name: 'Mercenary Vane',
        role: 'Gear Technician',
        spriteId: 'npc_solaris',
        x: 9,
        z: 7,
        facing: 'E',
        behavior: 'LOOK_AROUND',
        dialogueId: 'tavern_tech',
        voicePitch: 0.88,
      },
    ],
  };
}

// ============================================================================
// MAP 6: ZEBOIM EXCAVATION RUINS — MULTI-CHAMBER DUNGEON (24 x 28)
// ============================================================================
function buildDungeonZeboimRuins(): MapDefinition {
  const width = 24;
  const depth = 28;
  const tiles = makeGrid<TileType>(width, depth, 'wall_zeboim');
  const heightGrid = makeGrid<number>(width, depth, 0);
  const collisionGrid = makeGrid<number>(width, depth, 1);

  // Chamber 1: South Entry Antechamber (x=5..18, z=20..25)
  fillRect(tiles, 5, 20, 14, 6, 'zeboim_floor');
  fillRect(collisionGrid, 5, 20, 14, 6, 0);

  // Open southern cutaway border (z=26..27) so the fixed-tilt camera looks straight into Chamber 1 unobstructed
  fillRect(tiles, 0, 26, width, 2, 'void');

  // Corridor 1 -> 2 (x=10..13, z=17..20)
  fillRect(tiles, 10, 17, 4, 4, 'zeboim_floor');
  fillRect(collisionGrid, 10, 17, 4, 4, 0);

  // Chamber 2: Central Conduit Puzzle Hall (x=3..20, z=10..17)
  fillRect(tiles, 3, 10, 18, 8, 'zeboim_floor');
  fillRect(collisionGrid, 3, 10, 18, 8, 0);

  // Bulkhead Gate Corridor 2 -> 3 (x=11..12, z=8..10) — Locked until floor switch solved!
  fillRect(tiles, 11, 8, 2, 3, 'zeboim_floor');
  fillRect(collisionGrid, 11, 8, 2, 3, 0);

  // Chamber 3: North Boss Sanctum (x=6..17, z=2..8)
  fillRect(tiles, 6, 2, 12, 7, 'zeboim_floor');
  fillRect(collisionGrid, 6, 2, 12, 7, 0);
  // Raised Omnigear Plinth (x=10..13, z=2..4)
  fillRect(tiles, 10, 2, 4, 3, 'stone_plaza');
  fillRect(heightGrid, 10, 2, 4, 3, 0.45);
  collisionGrid[3][11] = 1;
  collisionGrid[3][12] = 1;

  // Exit mat at south end
  fillRect(tiles, 11, 25, 2, 1, 'stair_s');

  const props: Prop3DSpec[] = [
    // Crumbling concrete pillars
    { id: 'z_pil_1', type: 'zeboim_pillar', x: 7, z: 22 },
    { id: 'z_pil_2', type: 'zeboim_pillar', x: 16, z: 22 },
    { id: 'z_pil_3', type: 'zeboim_pillar', x: 7, z: 12 },
    { id: 'z_pil_4', type: 'zeboim_pillar', x: 16, z: 12 },
    { id: 'z_pil_5', type: 'zeboim_pillar', x: 7, z: 15 },
    { id: 'z_pil_6', type: 'zeboim_pillar', x: 16, z: 15 },
    { id: 'z_pil_7', type: 'zeboim_pillar', x: 8, z: 5 },
    { id: 'z_pil_8', type: 'zeboim_pillar', x: 15, z: 5 },
    // Flickering blue ether conduits
    { id: 'z_eth_1', type: 'ether_conduit', x: 9, z: 20 },
    { id: 'z_eth_2', type: 'ether_conduit', x: 14, z: 20 },
    { id: 'z_eth_3', type: 'ether_conduit', x: 4, z: 13 },
    { id: 'z_eth_4', type: 'ether_conduit', x: 19, z: 13 },
    { id: 'z_eth_5', type: 'ether_conduit', x: 9, z: 3 },
    { id: 'z_eth_6', type: 'ether_conduit', x: 14, z: 3 },
    // Dormant Omnigear Relic in Boss Chamber
    { id: 'z_omnigear', type: 'omnigear_relic', x: 11.5, z: 3.1 },
  ];

  // Pillar collisions
  for (const [px, pz] of [
    [7, 22], [16, 22], [7, 12], [16, 12], [7, 15], [16, 15], [8, 5], [15, 5],
  ]) {
    collisionGrid[pz][px] = 1;
  }

  return {
    id: 'dungeon_zeboim_ruins',
    name: 'Zeboim Excavation Ruins',
    subtitle: 'Subterranean Episode II Reliquary',
    gameState: 'PLAYING_DUNGEON',
    ostTrack: 'dungeon_zeboim',
    arenaTheme: 'zeboim_ruins',
    width,
    depth,
    isOutdoor: false,
    skyColor: '#0c1320',
    fogColor: '#121e30',
    fogNear: 12,
    fogFar: 32,
    sunColor: '#98c4ff',
    sunIntensity: 1.25,
    hemiSkyColor: '#5c8dc4',
    hemiGroundColor: '#253142',
    hemiIntensity: 0.85,
    defaultSpawn: { x: 12, z: 22, facing: 'N' },
    tiles,
    heightGrid,
    collisionGrid,
    buildings: [],
    props,
    warpZones: [
      {
        id: 'warp_zeboim_out',
        x: 11,
        z: 25,
        width: 2,
        targetMap: 'worldmap_ignas',
        targetX: 24,
        targetZ: 16,
        targetFacing: 'S',
        label: 'Ascend to Ignas World Map',
      },
    ],
    chests: [
      {
        id: 'chest_zeboim_1',
        x: 6,
        z: 24,
        facing: 'E',
        rewardItemId: 'zeboim_blade',
        rewardQty: 1,
        label: 'Zeboim Alloy Locker',
      },
      {
        id: 'chest_zeboim_2',
        x: 17,
        z: 24,
        facing: 'W',
        rewardGil: 450,
        label: 'Ancient Credit Cache',
      },
      {
        id: 'chest_zeboim_3',
        x: 4,
        z: 16,
        facing: 'E',
        rewardItemId: 'ether_mail',
        rewardQty: 1,
        label: 'Nano-Weave Pod',
      },
      {
        id: 'chest_zeboim_4',
        x: 19,
        z: 16,
        facing: 'W',
        rewardItemId: 'zetasol',
        rewardQty: 2,
        label: 'Medical Cryo-Case',
      },
    ],
    savePoints: [
      {
        id: 'save_zeboim_preboss',
        x: 14,
        z: 7,
        label: 'Sanctum Memory Cube',
      },
    ],
    switches: [
      {
        id: 'switch_zeboim_gate',
        x: 5,
        z: 13,
        flagId: 'zeboim_gate_unlocked',
        gateTiles: [
          { x: 11, z: 9 },
          { x: 12, z: 9 },
        ],
        label: 'Resonance Gate Switch',
      },
    ],
    encounterZones: [
      {
        minX: 3,
        maxX: 20,
        minZ: 10,
        maxZ: 24,
        stepThresholdMin: 14,
        stepThresholdMax: 22,
        enemyGroups: [
          ['zeboim_automaton', 'solaris_trooper'],
          ['zeboim_automaton', 'zeboim_automaton'],
          ['solaris_trooper', 'solaris_trooper'],
        ],
        arenaTheme: 'zeboim_ruins',
      },
    ],
    npcs: [
      {
        id: 'npc_zeboim_hologram',
        name: 'Zeboim Archive Terminal',
        role: 'Episode II Hologram',
        spriteId: 'npc_hologram',
        x: 12,
        z: 13,
        facing: 'S',
        behavior: 'STATIONARY',
        dialogueId: 'zeboim_hologram_story',
        voicePitch: 1.08,
      },
      {
        id: 'npc_solaris_inquisitor',
        name: 'Solaris Inquisitor',
        role: 'Boss Guard',
        spriteId: 'npc_solaris',
        x: 11,
        z: 5,
        facing: 'S',
        behavior: 'STATIONARY',
        dialogueId: 'zeboim_boss_encounter',
        questFlagCondition: { flag: 'zeboim_boss_defeated', expected: false },
        voicePitch: 0.78,
      },
    ],
  };
}

export const MAP_REGISTRY: Record<MapId, MapDefinition> = {
  worldmap_ignas: buildWorldmapIgnas(),
  town_nisan: buildTownNisan(),
  interior_cathedral: buildInteriorCathedral(),
  interior_atelier: buildInteriorAtelier(),
  interior_inn_shop: buildInteriorInnShop(),
  dungeon_zeboim_ruins: buildDungeonZeboimRuins(),
};

export function getMapById(id: MapId): MapDefinition {
  return MAP_REGISTRY[id];
}
