import React, { useCallback, useEffect, useRef } from 'react';
import { getMapById } from './data/maps/mapRegistry';
import { GameStateProvider, useGameState } from './engine/GameStateContext';
import { HD2DWorldEngine, WorldInputState } from './engine/HD2DWorldEngine';
import { AndroidControls } from './ui/AndroidControls';
import { BattleOverlay } from './ui/BattleOverlay';
import { BootAndPrologue } from './ui/BootAndPrologue';
import { DialogueOverlay } from './ui/DialogueOverlay';
import { MainMenu } from './ui/MainMenu';
import { ShopModal } from './ui/ShopModal';
import { TitleScreen } from './ui/TitleScreen';

const JRPGViewportShell: React.FC = () => {
  const {
    gameState,
    mapId,
    playerPos,
    party,
    openedChests,
    questFlags,
    config,
    activeOverlay,
    activeDialogue,
    screenFade,
    screenFlash,
    toastMessage,
    warpToMap,
    startBattle,
    setActivePrompt,
    updatePlayerPos,
    triggerInteract,
    startNewGame,
    returnToTitle,
  } = useGameState();

  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<HD2DWorldEngine | null>(null);
  const loadedMapKeyRef = useRef<string>('');

  // Store live callbacks in refs so HD2DWorldEngine never tears down on React HUD updates
  const callbacksRef = useRef({
    warpToMap,
    startBattle,
    setActivePrompt,
    updatePlayerPos,
  });
  callbacksRef.current = {
    warpToMap,
    startBattle,
    setActivePrompt,
    updatePlayerPos,
  };

  // Mount HD2DWorldEngine ONCE
  useEffect(() => {
    const el = canvasMountRef.current;
    if (!el) return;
    const engine = new HD2DWorldEngine(
      el,
      {
        onWarp: (tMap, tx, tz, tf) => callbacksRef.current.warpToMap(tMap, tx, tz, tf, true),
        onEncounter: (enemyIds, arenaTheme) =>
          callbacksRef.current.startBattle(enemyIds, { isBoss: false, arenaTheme }),
        onPromptChange: (p) => callbacksRef.current.setActivePrompt(p),
        onPositionSample: (x, z, f) => callbacksRef.current.updatePlayerPos(x, z, f),
      },
      config.graphicsQuality
    );
    engine.start();
    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
      loadedMapKeyRef.current = '';
    };
  }, []);

  // Update graphics quality live without tearing down scene
  useEffect(() => {
    engineRef.current?.applyQuality(config.graphicsQuality);
  }, [config.graphicsQuality]);

  // Load 3D map diorama whenever mapId or active leader changes (or initial boot)
  const leaderId = party[0]?.id ?? 'lacan';
  useEffect(() => {
    const eng = engineRef.current;
    if (!eng) return;
    const targetMapId =
      gameState === 'TITLE_SCREEN' || gameState === 'BOOT_LOGO' || gameState === 'PROLOGUE_INTRO'
        ? 'town_nisan'
        : mapId;
    const loadKey = `${targetMapId}:${leaderId}`;
    if (loadedMapKeyRef.current !== loadKey) {
      loadedMapKeyRef.current = loadKey;
      const mapDef = getMapById(targetMapId);
      eng.loadMap(
        mapDef,
        playerPos.x,
        playerPos.z,
        playerPos.facing,
        party,
        openedChests,
        questFlags
      );
    }
  }, [mapId, gameState, leaderId]);

  // Sync opened chests & floor-switch quest flags to 3D world props immediately
  useEffect(() => {
    engineRef.current?.setQuestState(openedChests, questFlags);
  }, [openedChests, questFlags]);

  // Sync world camera / simulation mode with JRPG GameState
  useEffect(() => {
    const eng = engineRef.current;
    if (!eng) return;
    if (gameState === 'TITLE_SCREEN' || gameState === 'BOOT_LOGO' || gameState === 'PROLOGUE_INTRO') {
      eng.setMode('title_tour');
    } else if (gameState === 'BATTLE' || gameState === 'GAME_OVER') {
      eng.setMode('frozen');
    } else if (activeOverlay || activeDialogue || gameState === 'CUTSCENE') {
      eng.setMode('frozen');
    } else {
      eng.setMode('gameplay');
    }
  }, [gameState, activeOverlay, activeDialogue]);

  const handleInputChange = useCallback((input: WorldInputState) => {
    engineRef.current?.setInput(input);
  }, []);

  const handleInteract = useCallback(() => {
    triggerInteract((npcId) => {
      engineRef.current?.faceNpcTowardPlayer(npcId);
    });
  }, [triggerInteract]);

  return (
    <main className="relative w-dvw h-dvh overflow-hidden bg-[#090c14]">
      {/* Isolated WebGL World Canvas Container (Never re-mounts on HUD state updates) */}
      <div
        ref={canvasMountRef}
        data-testid="world-canvas-container"
        className={`absolute inset-0 w-full h-full ${gameState === 'BATTLE' ? 'invisible' : 'visible'}`}
      />

      {/* State Screens & Overlays */}
      <BootAndPrologue />
      <TitleScreen />
      <AndroidControls onInputChange={handleInputChange} onInteract={handleInteract} />
      <DialogueOverlay />
      <ShopModal />
      <MainMenu />
      <BattleOverlay />

      {/* Game Over Modal */}
      {gameState === 'GAME_OVER' && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center safe-pad">
          <div className="jrpg-window w-full max-w-md p-6 text-center flex flex-col gap-4">
            <h2 className="font-display text-2xl tracking-[0.28em] text-[#e06a6a]">
              FALLEN IN BATTLE
            </h2>
            <p className="font-serif-jp text-base text-[#d4cbb8]">
              The light of Nisan fades beneath Ignas... yet destiny endures.
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                data-start="true"
                onClick={() => startNewGame(true)}
                className="min-h-[48px] px-5 py-2.5 font-display text-xs tracking-widest border border-[#e3c078] bg-[#d4b06a]/25 text-[#fff6df] hover:bg-[#d4b06a]/40"
              >
                Try Again
              </button>
              <button
                type="button"
                onClick={returnToTitle}
                className="min-h-[48px] px-5 py-2.5 font-display text-xs tracking-widest border border-[#5a6680] text-[#cbd5e8] hover:border-[#d4b06a]"
              >
                Title Screen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subtle Non-Blocking Toast Banner */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
          <div className="jrpg-window-subtle px-4 py-1.5 text-xs text-[#f5e3ba] whitespace-nowrap">
            {toastMessage}
          </div>
        </div>
      )}

      {/* Screen Flash Layer (Cutscenes / Switches / Battle Transition) */}
      {screenFlash && (
        <div
          className="fixed inset-0 z-50 pointer-events-none transition-opacity duration-200"
          style={{ backgroundColor: screenFlash, opacity: 0.65 }}
        />
      )}

      {/* Smooth Fade-to-Black Map & Inn Transition Curtain */}
      <div
        className="fixed inset-0 z-50 bg-black pointer-events-none transition-opacity duration-200"
        style={{ opacity: screenFade }}
      />
    </main>
  );
};

export default function App() {
  return (
    <GameStateProvider>
      <JRPGViewportShell />
    </GameStateProvider>
  );
}
