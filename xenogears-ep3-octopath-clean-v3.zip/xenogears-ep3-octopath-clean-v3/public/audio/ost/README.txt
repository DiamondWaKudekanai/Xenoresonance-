Place custom .mp3 or .ogg soundtrack files in this directory (/public/audio/ost/):
- title.mp3
- worldmap.mp3
- town_nisan.mp3
- interior_peaceful.mp3
- dungeon_zeboim.mp3
- battle_normal.mp3
- battle_boss.mp3
- cutscene_tragic.mp3

Add the filenames to manifest.json under "available", or load them directly at runtime inside the Config -> OST Track Slots menu.
