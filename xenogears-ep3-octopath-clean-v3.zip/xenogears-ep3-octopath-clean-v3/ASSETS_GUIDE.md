# Xenogears Episode III: Cradle of Nisan — Asset & OST Drop-In Guide

This project ships with 100% self-contained procedural pixel-art fallbacks and a Web Audio SFX bank so it runs with zero missing assets out of the box. You can drop in custom music, chibi sprite sheets, and seamless tile textures at any time without modifying source code.

---

## 1. Custom OST Tracks (`public/audio/ost/`)

Place `.mp3` or `.ogg` soundtrack files inside `public/audio/ost/` and list the filenames in `public/audio/ost/manifest.json` under `"available"` (or load them live from **Config -> OST Track Slots**).

| Track Slot | Filename | Scene / Map |
| :--- | :--- | :--- |
| Title Theme | `title.mp3` (or `.ogg`) | Boot / Title Screen |
| World Map | `worldmap.mp3` | `worldmap_ignas` Overworld |
| Town of Nisan | `town_nisan.mp3` | `town_nisan` Exterior |
| Peaceful Interior | `interior_peaceful.mp3` | Cathedral, Atelier, Inn & Armory |
| Zeboim Dungeon | `dungeon_zeboim.mp3` | `dungeon_zeboim_ruins` |
| Normal Battle | `battle_normal.mp3` | Random Encounters |
| Boss Battle | `battle_boss.mp3` | Prototype Diabolos / Story Bosses |
| Cutscene Theme | `cutscene_tragic.mp3` | Story Cutscenes & Prologue |

Crossfades automatically execute over **1.2 seconds** on map and battle transitions.

---

## 2. Chibi Sprite Sheets (`public/assets/sprites/`)

All sprites use strict **uniform transparent PNG grids** (no blind cropping, nearest-neighbor filtering, `alphaTest = 0.5`). List added filenames in `public/assets/sprites/manifest.json` under `"available"`.

### Overworld Walk Sheets (`*_walk.png`)
- **Grid:** Exact `4 columns x 4 rows`
- **Cell Dimensions:** `32x32` (`128x128` PNG) or `48x48` (`192x192` PNG); Gears use `64x64` (`256x256` PNG)
- **Row Layout:**
  - Row 0: Facing Down (South) — `[Idle, Left-Step, Idle, Right-Step]`
  - Row 1: Facing Left (West) — `[Idle, Left-Step, Idle, Right-Step]`
  - Row 2: Facing Right (East) — `[Idle, Left-Step, Idle, Right-Step]`
  - Row 3: Facing Up (North) — `[Idle, Left-Step, Idle, Right-Step]`

### Battle Sheets (`*_battle.png`)
- **Grid:** Exact `4 columns x 3 rows`
- **Cell Dimensions:** `32x32` (`128x96` PNG) for party/troopers, `48x48` (`192x144` PNG) for large enemies, `64x64` (`256x192` PNG) for Gears and Bosses
- **Row Layout:**
  - Row 0: Idle Breathing (4 frames)
  - Row 1: `[Physical Strike, Strong Finisher, Ether Cast, Guard]`
  - Row 2: `[Hurt/Recoil, Low-HP Kneel, Victory Pose, KO]`

### Supported Filenames
- Party: `lacan_walk.png`, `lacan_battle.png`, `sophia_walk.png`, `sophia_battle.png`, `krelian_walk.png`, `krelian_battle.png`, `roni_walk.png`, `roni_battle.png`
- NPCs: `npc_monk_walk.png`, `npc_villager_walk.png`, `npc_merchant_walk.png`, `npc_child_walk.png`, `npc_solaris_walk.png`, `npc_hologram_walk.png`
- Gears: `gear_amon_battle.png`, `gear_elregrs_battle.png`, `gear_andvari_battle.png`, `gear_solaris_battle.png`
- Enemies/Boss: `enemy_trooper_battle.png`, `enemy_automaton_battle.png`, `enemy_sandworm_battle.png`, `boss_diabolos_battle.png`

---

## 3. Seamless 3D Tile Textures (`public/assets/tiles/`)

Place seamless `16x16` or `32x32` pixel-art PNG tiles in `public/assets/tiles/` and add them to `public/assets/tiles/manifest.json`:
- `grass.png`, `cobble.png`, `stone_plaza.png`, `water.png`, `sand.png`
- `wood_floor.png`, `marble_checker.png`, `zeboim_floor.png`
- `wall_stone.png`, `wall_stucco.png`, `roof_clay.png`, `roof_slate.png`

---

## 4. Android Build via Capacitor

```bash
npm run android:sync
npm run android:open
```

- Application ID: `com.xenoresonance.episode3`
- Locked to landscape immersive fullscreen with safe-area notch margins.
- Android hardware Back button is intercepted to toggle the in-game Menu/Pause overlay instead of terminating the WebView.
