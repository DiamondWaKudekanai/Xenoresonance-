# Octopath Traveler 1:1 Map Rebuild & Perfect Works Expansion Prompt

All **22 chibi/Gear/enemy sprite sheets**, **21 seamless world & architecture tiles**, **9 PS1-style portraits**, **39 props/landmarks/backdrops**, **8 VFX strips**, and **9 combat UI icons** are ALREADY installed and wired in `public/assets/`.

Paste the prompt below into Google AI Studio after importing this repository to force AI Studio to rebuild the map layouts (`src/data/maps/mapRegistry.ts` and `src/engine/HD2DWorldEngine.ts`) to match **Octopath Traveler 1:1** while expanding the lore directly from **Xenogears Perfect Works (Episode III -> PSX Episode V)**.

---

## Copy-Paste Prompt for Google AI Studio

```text
DO NOT regenerate or replace any PNG/JPG files inside `public/assets/`! Every chibi 4x4 walk sheet, 4x3 battle sheet, 256x256 portrait, seamless tile, interior prop, world map landmark, and painted battle backdrop is already installed and live.

Your task is to REBUILD THE MAP ARCHITECTURE AND LEVEL DESIGN in `src/data/maps/mapRegistry.ts`, `src/engine/HD2DWorldEngine.ts`, and `src/data/storyEpisode3.ts` so every area feels 1:1 like OCTOPATH TRAVELER's iconic HD-2D dioramas, expanded with deep Xenogears Perfect Works lore (Episode III: Year 9499 connecting directly to Xenogears PSX Episode V):

1. OCTOPATH TRAVELER 1:1 DIORAMA LEVEL DESIGN (`src/data/maps/mapRegistry.ts` & `src/engine/HD2DWorldEngine.ts`):
   - **Multi-Tiered Elevation & Stone Staircases:** Eliminate flat square grids! Sculpt `town_nisan` across 3 distinct vertical tiers (Lower Canal & Market at `y = 0`, Mid-Town Artisan Terrace with Lacan's Atelier & Inn at `y = 1.0`, and the Upper Sanctuary Plateau for Nisan Cathedral at `y = 2.0`), linked by wide stepped stone staircases (`stone_plaza` + stone banisters) and an arched wooden bridge over a shimmering animated water canal (`water.png` UV scroll).
   - **Foreground Framing & Parallax Depth (The True Octopath Signature):** Place out-of-focus foreground framing props (`prop_pine_tall.png`, `prop_lantern_hanging.png`, stone cliff ledges, low wooden fences) along the southern camera-side edge of `town_nisan` and `dungeon_zeboim_ruins` so the Tilt-Shift DoF shader naturally blurs the foreground while keeping the chibi party razor-sharp in the focal plane.
   - **Crisp 3D Architecture + Warm Window Glow:** Give every 3D building in `town_nisan` pitched overhanging eaves (`roof_clay.png` / `roof_slate.png`), timber trim beams, recessed dark doorways with warm threshold light spills, and glowing stained-glass volumetric sunbeams (`stained_glass.png`) inside `interior_cathedral`.
   - **Tight, Cozy Octopath Interior Framing:** For `interior_atelier`, `interior_cathedral`, and `interior_inn_shop`, surround the cut-away 3D room with pure black void outside the walls, tighten the camera closer (`distance ~8.8`, `FOV 32°`), and add warm flickering fireplace/candle pools so interiors feel intimate like Octopath Traveler's taverns and chapels.
   - **Multi-Chamber Zeboim Ruins Dungeon (`dungeon_zeboim_ruins`):** Redesign the dungeon into 3 dramatic interconnected rooms: (1) Sunken Excavation Entrance with crumbling concrete arches and cyan conduit floors, (2) Dr. Kim Kasim's Episode II Nanotech Archive Chamber with glowing hologram terminal (`prop_zeboim_console.png`) and floor-switch gate puzzle, and (3) The Sealed Zohar-Resonance Vault where the Solaris Inquisitor awakens Prototype Diabolos.

2. XENOGEARS PERFECT WORKS -> PSX EPISODE V LORE EXPANSION (`src/data/storyEpisode3.ts`):
   - Deepen all NPC dialogues, inspectable lore objects, and story cutscenes to connect **Episode III (Year 9499)** directly to the **Xenogears PSX (Episode V)** canon:
     * **Lacan & Sophia's Tragedy:** Foreshadow Lacan's unfinished portrait of Sophia in his atelier (the exact painting Fei and Elly discover 500 years later in Nisan Mausoleum in Xenogears PSX).
     * **Krelian's Turning Point:** Have Krelian react intensely to Dr. Kim Kasim's Episode II Zeboim nanomachine archive (`npc_hologram` / `prop_zeboim_console.png`), planting the seed of his obsession with nanomachines and human evolution seen in Xenogears PSX.
     * **Roni Fatima & The Fatima Lineage:** Connect Roni's blue-and-gold Gear **Andvari** and the Aveh desert border directly to Bart Fatima's heritage in Episode V.
     * **Shevat, Solaris & The Gazel Ministry:** Add ambient Nisan townsfolk and the hooded Solaris spy referencing the floating sky-city of Shevat, the Solaris surface purges, and the buried Zohar Modifier.

3. VISUAL POLISH CHECK:
   - Ensure `TiltShiftShader` keeps the center 50% of the screen completely sharp (zero muddy blur on characters) and only softens the top 18% and bottom 18%.
   - Keep lighting warm and readable (`HemisphereLight >= 0.85`, golden directional sun, warm lantern pools) — never pitch black.
   - Run `npm run lint` and `npm run build` to verify zero TypeScript or bundler errors.
```
