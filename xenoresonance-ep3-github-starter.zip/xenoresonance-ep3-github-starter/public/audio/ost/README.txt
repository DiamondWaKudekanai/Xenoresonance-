XENORESONANCE: EPISODE III — CUSTOM OST DROP-IN FOLDER
=======================================================
Drop your own composed .mp3 or .ogg soundtrack files into this folder using
these exact filenames. AudioManager.ts will automatically detect and crossfade
them when switching scenes! If a file is missing, the engine stays silent with
zero errors.

Required / Supported Track Filenames:
- title.mp3               (Title Screen & Prologue Intro)
- worldmap.mp3            (Ignas Continent Overworld)
- town_nisan.mp3          (Town of Nisan Exterior)
- interior_peaceful.mp3   (Lacan's Atelier, Nisan Cathedral, Inn & Shop)
- dungeon_zeboim.mp3      (Zeboim Excavation Ruins Dungeon)
- battle_normal.mp3       (Standard Field & Dungeon Combat)
- battle_boss.mp3         (Solaris Inquisitor & Prototype Diabolos Boss)
- cutscene_tragic.mp3     (Dramatic Story Cutscenes)
