export type Direction = 'down' | 'left' | 'right' | 'up';

export type GameMode =
  | 'BOOT'
  | 'PROLOGUE_INTRO'
  | 'TITLE_SCREEN'
  | 'PLAYING_WORLDMAP'
  | 'PLAYING_TOWN'
  | 'PLAYING_INTERIOR'
  | 'PLAYING_DUNGEON'
  | 'BATTLE'
  | 'CUTSCENE'
  | 'GAME_OVER';

export type MapId =
  | 'worldmap_ignas'
  | 'town_nisan'
  | 'interior_cathedral'
  | 'interior_atelier'
  | 'interior_inn_shop'
  | 'dungeon_zeboim_ruins';

export type OstTrackId =
  | 'title'
  | 'worldmap'
  | 'town_nisan'
  | 'interior_peaceful'
  | 'dungeon_zeboim'
  | 'battle_normal'
  | 'battle_boss'
  | 'cutscene_tragic';

export type DamageElement = 'fist' | 'sword' | 'staff' | 'fire' | 'lightning' | 'wind';

export type AttackInput = 'T' | 'S' | 'X';

export interface DeathblowDef {
  id: string;
  name: string;
  subtitle: string;
  sequence: AttackInput[];
  apCost: number;
  multiplier: number;
  element: DamageElement;
  vfxKey: 'vfx_raijin' | 'vfx_senretsu' | 'vfx_tenbu' | 'vfx_kishin';
  description: string;
}

export interface EtherArtDef {
  id: string;
  name: string;
  epCost: number;
  power: number;
  element: DamageElement | 'heal';
  target: 'single_enemy' | 'all_enemies' | 'single_ally' | 'all_allies';
  vfxKey: 'vfx_heal' | 'vfx_flame' | 'vfx_summon_circle' | 'vfx_raijin';
  description: string;
}

export interface GearUnit {
  id: string;
  name: string;
  title: string;
  spritePath: string;
  maxFrameHp: number;
  frameHp: number;
  maxFuel: number;
  fuel: number;
  attackLevel: number; // 0..3, 4 = Infinity
  boosterActive: boolean;
  armor: number;
  etherAmp: number;
}

export interface PartyMember {
  id: 'lacan' | 'sophia' | 'krelian' | 'roni';
  name: string;
  roleTitle: string;
  level: number;
  xp: number;
  nextLevelXp: number;
  hp: number;
  maxHp: number;
  ep: number;
  maxEp: number;
  maxAp: number;
  comboBank: number; // 0..28
  atk: number;
  def: number;
  ether: number;
  speed: number;
  weaponType: 'fist' | 'sword' | 'staff';
  walkSheet: string;
  battleSheet: string;
  portraitNormal: string;
  portraitAlt: string;
  gear: GearUnit | null;
  inGear: boolean;
  etherArts: EtherArtDef[];
  deathblowMastery: Record<string, number>;
}

export interface EnemySpec {
  id: string;
  name: string;
  title: string;
  spritePath: string;
  isBoss: boolean;
  isGearScale: boolean;
  maxHp: number;
  atk: number;
  def: number;
  speed: number;
  maxShields: number;
  weaknesses: DamageElement[];
  xpReward: number;
  gilReward: number;
}

export interface ItemDef {
  id: string;
  name: string;
  category: 'consumable' | 'weapon' | 'armor' | 'gear_part';
  price: number;
  description: string;
  healHp?: number;
  healEp?: number;
  healFuel?: number;
  atkBonus?: number;
  defBonus?: number;
}

export interface Building3DSpec {
  id: string;
  label: string;
  tileX: number;
  tileZ: number;
  widthTiles: number;
  heightUnits: number;
  depthTiles: number;
  wallTile: string;
  roofTile: string;
  accentWindowTile?: string;
  doorOffsetX: number; // relative to building center
  targetMap?: MapId;
  targetSpawnX?: number;
  targetSpawnZ?: number;
  targetFacing?: Direction;
}

export interface PropPlacement {
  id: string;
  propKey: string;
  tileX: number;
  tileY: number;
  tileZ: number;
  heightUnits: number;
  collides: boolean;
  interactiveType?: 'chest' | 'save_point' | 'hologram' | 'inn_counter' | 'shop_counter';
  chestItemId?: string;
  chestQty?: number;
  dialogueId?: string;
}

export interface NpcPlacement {
  id: string;
  name: string;
  npcSpriteKey: string;
  tileX: number;
  tileZ: number;
  facing: Direction;
  behavior: 'STATIONARY' | 'LOOK_AROUND' | 'PATROL_WAYPOINTS';
  waypoints?: Array<{ x: number; z: number }>;
  dialogueId: string;
  role?: 'story' | 'innkeeper' | 'merchant' | 'villager';
}

export interface WarpZone {
  id: string;
  label: string;
  tileX: number;
  tileZ: number;
  radius: number;
  targetMap: MapId;
  spawnX: number;
  spawnZ: number;
  facing: Direction;
}

export interface MapDefinition {
  id: MapId;
  name: string;
  subtitle: string;
  mode: 'PLAYING_WORLDMAP' | 'PLAYING_TOWN' | 'PLAYING_INTERIOR' | 'PLAYING_DUNGEON';
  ostTrack: OstTrackId;
  battleBackdrop: string;
  widthTiles: number;
  depthTiles: number;
  groundTile: string;
  secondaryPathTile?: string;
  wallTile?: string;
  ambientHex: string;
  ambientIntensity: number;
  sunHex: string;
  sunIntensity: number;
  fogHex: string;
  fogDensity: number;
  allowRandomEncounters: boolean;
  encounterPool: string[];
  buildings: Building3DSpec[];
  props: PropPlacement[];
  npcs: NpcPlacement[];
  warps: WarpZone[];
}

export interface CutsceneLine {
  speaker: string;
  portrait?: string;
  text: string;
  sfx?: 'confirm' | 'alert' | 'ether';
}

export interface StoryScene {
  id: string;
  title: string;
  requiredFlag?: string;
  setsFlag?: string;
  ostOverride?: OstTrackId;
  triggersEncounterId?: string;
  lines: CutsceneLine[];
}

export interface SaveSlotData {
  slotIndex: 0 | 1 | 2;
  savedAtIso: string;
  playtimeSeconds: number;
  mapId: MapId;
  playerX: number;
  playerZ: number;
  facing: Direction;
  gil: number;
  questObjective: string;
  storyFlags: Record<string, boolean>;
  openedChestIds: string[];
  party: PartyMember[];
  inventory: Array<{ itemId: string; quantity: number }>;
}
