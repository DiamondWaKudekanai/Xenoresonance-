import { StoryScene } from '../types/game';
import { ASSETS } from './assets';

export const PROLOGUE_CRAWL_LINES: string[] = [
  'Year 9499 — Five hundred years before the fall of Lahan Village.',
  'High above the clouds, the floating empire of Solaris tightens its grip over the surface nations.',
  'In the mountain sanctuary of Nisan, a young painter named Lacan works quietly in his atelier,',
  'unaware that the Holy Mother Sophia, Commander Krelian, and Prince Roni Fatima are about to',
  'uncover an ancient Zeboim relic buried beneath the Ignas sands...',
];

export const STORY_SCENES: Record<string, StoryScene> = {
  intro_atelier_wake: {
    id: 'intro_atelier_wake',
    title: 'Morning in Nisan',
    setsFlag: 'intro_done',
    lines: [
      {
        speaker: 'Lacan',
        portrait: ASSETS.portraits.lacanNormal,
        text: 'The light on the cathedral spires looks different today... almost golden.',
      },
      {
        speaker: 'Lacan',
        portrait: ASSETS.portraits.lacanDetermined,
        text: 'Krelian sent word earlier. I should head up to the Nisan Cathedral and see what Sophia needs.',
      },
    ],
  },

  scene_cathedral_summons: {
    id: 'scene_cathedral_summons',
    title: 'Council of the Sanctuary',
    setsFlag: 'cathedral_council_done',
    lines: [
      {
        speaker: 'Sophia',
        portrait: ASSETS.portraits.sophiaSerene,
        text: 'Thank you for coming, Lacan. Your portrait of the sanctuary has brought comfort to everyone in Nisan.',
      },
      {
        speaker: 'Krelian',
        portrait: ASSETS.portraits.krelianCalm,
        text: 'Forgive the abrupt summons, Lacan. Scouts from Shevat and Aveh confirmed Solaris airships descending toward the Zeboim Excavation Ruins.',
      },
      {
        speaker: 'Roni Fatima',
        portrait: ASSETS.portraits.roniGrin,
        text: 'Ha! If Solaris wants whatever ancient machine is sleeping in that crater, Aveh and Nisan are going to beat them to it!',
      },
      {
        speaker: 'Sophia',
        portrait: ASSETS.portraits.sophiaSorrowful,
        text: 'Please be careful... I can feel a resonance beneath the earth. Something ancient is waking up.',
      },
      {
        speaker: 'Krelian',
        portrait: ASSETS.portraits.krelianBrooding,
        text: 'Then we move together. Exit Nisan to the south, cross the Ignas Overworld to the northeast, and secure the Zeboim Ruins before Solaris does.',
      },
    ],
  },

  scene_zeboim_hologram: {
    id: 'scene_zeboim_hologram',
    title: 'Echoes of Zeboim (Episode II)',
    setsFlag: 'zeboim_hologram_seen',
    lines: [
      {
        speaker: 'Ancient Console',
        text: '[ZEBOIM ARCHIVE — BIOLOGICAL RESEARCH LOG #409 · DR. KIM KASIM]',
      },
      {
        speaker: 'Ancient Console',
        text: '"The nanomachine stabilizer is complete... If humanity falls to its own war, let this archive survive for the next era."',
      },
      {
        speaker: 'Krelian',
        portrait: ASSETS.portraits.krelianBrooding,
        text: 'Nanomachine cellular control... four thousand years before our time. Such knowledge could heal the world—or remake it entirely.',
      },
    ],
  },

  scene_zeboim_boss: {
    id: 'scene_zeboim_boss',
    title: 'The Awakened Relic',
    setsFlag: 'chapter1_boss_triggered',
    ostOverride: 'battle_boss',
    triggersEncounterId: 'prototype_diabolos',
    lines: [
      {
        speaker: 'Solaris Inquisitor',
        portrait: ASSETS.portraits.solarisInquisitor,
        text: 'Halt, surface lambs of Nisan! By decree of the Gazel Ministry, this Omnigear relic belongs to Solaris!',
      },
      {
        speaker: 'Roni Fatima',
        portrait: ASSETS.portraits.roniGrin,
        text: 'Talk is cheap, tin-face! Lacan, Krelian—ready your Gears! Let’s break its shields and send it back to the scrap heap!',
      },
      {
        speaker: 'Lacan',
        portrait: ASSETS.portraits.lacanDetermined,
        text: 'I will not let Solaris burn Nisan! Stand behind me, Sophia!',
      },
    ],
  },

  npc_monk_nisan: {
    id: 'npc_monk_nisan',
    title: 'Brother Thomas',
    lines: [
      { speaker: 'Brother Thomas', text: 'May the grace of the Holy Mother guide your steps, young Lacan.' },
    ],
  },

  npc_guard_gate: {
    id: 'npc_guard_gate',
    title: 'Nisan Sentinel',
    lines: [
      { speaker: 'Nisan Sentinel', text: 'Beyond the southern gate lies the Ignas World Map. Watch out for Solaris patrols near the Zeboim Ruins!' },
    ],
  },

  npc_child_nisan: {
    id: 'npc_child_nisan',
    title: 'Mika',
    lines: [
      { speaker: 'Mika', text: 'Hey Lacan! Are you gonna paint a giant metal knight next? Prince Roni showed me his Gear!' },
    ],
  },

  npc_solaris_spy: {
    id: 'npc_solaris_spy',
    title: 'Hooded Traveler',
    lines: [
      { speaker: 'Hooded Traveler', text: '...Pay me no mind, painter. The skies above Ignas will soon grow very crowded.' },
    ],
  },

  inspect_easel: {
    id: 'inspect_easel',
    title: 'Unfinished Canvas',
    lines: [
      { speaker: 'Lacan', portrait: ASSETS.portraits.lacanNormal, text: 'My unfinished portrait of Sophia. I still haven’t captured the warmth in her eyes.' },
    ],
  },
};
