import React, { useEffect, useState } from 'react';
import { ASSETS } from './data/assets';
import { INITIAL_PARTY, ENEMIES } from './data/characters';
import { MAPS } from './data/maps';
import { PROLOGUE_CRAWL_LINES } from './data/story';
import { audioManager } from './engine/AudioManager';
import { createNewGameState, listAllSaveSlots, writeSaveSlot } from './engine/SaveManager';
import { GameMode, MapId, SaveSlotData } from './types/game';

export default function App() {
  const [mode, setMode] = useState<GameMode>('TITLE_SCREEN');
  const [saveData, setSaveData] = useState<SaveSlotData>(() => createNewGameState(0));
  const [slots, setSlots] = useState<Array<SaveSlotData | null>>([]);
  const [showContinue, setShowContinue] = useState(false);
  const [showAssetVault, setShowAssetVault] = useState(false);
  const [prologueIdx, setPrologueIdx] = useState(0);

  useEffect(() => {
    setSlots(listAllSaveSlots());
  }, [mode]);

  const startNewGame = () => {
    audioManager.playSfx('confirm');
    audioManager.playOst('title');
    const fresh = createNewGameState(0);
    writeSaveSlot(fresh);
    setSaveData(fresh);
    setPrologueIdx(0);
    setMode('PROLOGUE_INTRO');
  };

  const loadSlot = (slot: SaveSlotData) => {
    audioManager.playSfx('confirm');
    setSaveData(slot);
    setShowContinue(false);
    setMode(MAPS[slot.mapId].mode);
    audioManager.playOst(MAPS[slot.mapId].ostTrack);
  };

  const travelToMap = (mapId: MapId) => {
    audioManager.playSfx('door');
    const nextMap = MAPS[mapId];
    const updated: SaveSlotData = { ...saveData, mapId };
    setSaveData(updated);
    writeSaveSlot(updated);
    setMode(nextMap.mode);
    audioManager.playOst(nextMap.ostTrack);
  };

  // =========================================================================
  // 1. TITLE SCREEN (Uses Verified Hand-Drawn Nisan Twilight Key Art)
  // =========================================================================
  if (mode === 'TITLE_SCREEN') {
    return (
      <main className="relative w-full h-full overflow-hidden flex items-center justify-center bg-[#050814]">
        <img
          src={ASSETS.backdrops.titleKeyArt}
          alt="Nisan Cathedral at Twilight"
          className="absolute inset-0 w-full h-full object-cover pixelated opacity-90"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050814] via-[#050814]/35 to-transparent" />

        <div className="relative z-10 flex flex-col items-center text-center px-6 max-w-2xl">
          <p className="font-rpg-mono text-xs tracking-[0.35em] text-amber-300 uppercase mb-2 drop-shadow">
            Perfect Works · Episode III · Year 9499
          </p>
          <h1 className="font-rpg-title text-4xl md:text-6xl font-bold tracking-wider text-amber-50 drop-shadow-[0_4px_18px_rgba(0,0,0,0.95)]">
            XENORESONANCE
          </h1>
          <p className="text-base md:text-lg italic text-amber-100/90 mt-1 mb-8 drop-shadow">
            The Nisan Chronicles — HD-2D Android JRPG Starter
          </p>

          <div className="rpg-window p-4 w-72 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={startNewGame}
              className="w-full py-2.5 px-4 text-sm font-rpg-title tracking-widest text-amber-200 hover:bg-amber-400/20 border border-amber-400/50 transition cursor-pointer"
            >
              NEW CHRONICLE
            </button>
            <button
              type="button"
              onClick={() => {
                audioManager.playSfx('cursor');
                setShowContinue((v) => !v);
              }}
              className="w-full py-2.5 px-4 text-sm font-rpg-title tracking-widest text-slate-200 hover:bg-amber-400/15 border border-slate-500/40 transition cursor-pointer"
            >
              CONTINUE ({slots.filter(Boolean).length}/3)
            </button>
            <button
              type="button"
              onClick={() => {
                audioManager.playSfx('cursor');
                setShowAssetVault((v) => !v);
              }}
              className="w-full py-2 px-4 text-xs font-rpg-mono tracking-wider text-sky-300 hover:bg-sky-400/15 border border-sky-400/40 transition cursor-pointer"
            >
              ASSET & SPRITE VAULT
            </button>
          </div>

          {showContinue && (
            <div className="rpg-window mt-3 p-3 w-80 space-y-1.5 text-left">
              {([0, 1, 2] as const).map((idx) => {
                const slot = slots[idx];
                return (
                  <button
                    key={idx}
                    type="button"
                    disabled={!slot}
                    onClick={() => slot && loadSlot(slot)}
                    className="w-full p-2 border border-amber-400/30 hover:bg-amber-400/15 disabled:opacity-40 flex justify-between text-xs font-rpg-mono cursor-pointer"
                  >
                    <span>SLOT {idx + 1}</span>
                    <span className="text-amber-200">
                      {slot ? MAPS[slot.mapId].name : 'EMPTY'}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Asset Verification Modal so you can preview every bundled PNG immediately */}
        {showAssetVault && (
          <div className="fixed inset-0 z-30 bg-black/85 flex items-center justify-center p-4">
            <div className="rpg-window w-full max-w-4xl max-h-[88dvh] overflow-y-auto p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-amber-400/30 pb-2">
                <h2 className="font-rpg-title text-lg text-amber-200">
                  VERIFIED EPISODE III PIXEL ART VAULT
                </h2>
                <button
                  type="button"
                  onClick={() => setShowAssetVault(false)}
                  className="px-3 py-1 text-xs font-rpg-mono border border-amber-400 text-amber-200 cursor-pointer"
                >
                  CLOSE
                </button>
              </div>

              <div>
                <h3 className="font-rpg-mono text-xs text-sky-300 mb-2">
                  PARTY PORTRAITS & 4x4 CHIBI WALK SHEETS
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {INITIAL_PARTY.map((m) => (
                    <div key={m.id} className="border border-slate-700 bg-slate-950/70 p-2 text-center">
                      <img src={m.portraitNormal} alt={m.name} className="w-20 h-20 mx-auto pixelated" />
                      <div className="font-rpg-title text-sm text-amber-200 mt-1">{m.name}</div>
                      <img src={m.walkSheet} alt={`${m.name} walk`} className="w-28 h-28 mx-auto mt-1 pixelated" />
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-rpg-mono text-xs text-sky-300 mb-2">
                  OMNIGEARS, ENEMIES & PROTOTYPE DIABOLOS BOSS
                </h3>
                <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                  {[
                    ASSETS.battle.gears.amon,
                    ASSETS.battle.gears.elRegrs,
                    ASSETS.battle.gears.andvari,
                    ENEMIES.solaris_inquisitor.spritePath,
                    ENEMIES.zeboim_drone.spritePath,
                    ENEMIES.prototype_diabolos.spritePath,
                  ].map((src, i) => (
                    <div key={i} className="border border-slate-700 bg-slate-950/70 p-2 flex items-center justify-center">
                      <img src={src} alt="Combat Unit" className="h-24 object-contain pixelated" />
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-rpg-mono text-xs text-sky-300 mb-2">
                  SEAMLESS 3D TILES & WORLD MAP LANDMARKS
                </h3>
                <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
                  {Object.values(ASSETS.tiles).map((src, i) => (
                    <img key={i} src={src} alt="Tile" className="w-16 h-16 object-cover pixelated border border-slate-700" />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    );
  }

  // =========================================================================
  // 2. PROLOGUE INTRO CRAWL
  // =========================================================================
  if (mode === 'PROLOGUE_INTRO') {
    const isLast = prologueIdx >= PROLOGUE_CRAWL_LINES.length - 1;
    return (
      <main
        onClick={() => {
          audioManager.playSfx('confirm');
          if (isLast) {
            travelToMap('interior_atelier');
          } else {
            setPrologueIdx((i) => i + 1);
          }
        }}
        className="relative w-full h-full bg-[#040610] flex flex-col items-center justify-center p-8 text-center cursor-pointer"
      >
        <p className="font-rpg-mono text-xs tracking-[0.3em] text-amber-400/80 mb-6">
          PROLOGUE · EPISODE III
        </p>
        <p className="text-xl md:text-2xl text-amber-50 max-w-2xl leading-relaxed">
          {PROLOGUE_CRAWL_LINES[prologueIdx]}
        </p>
        <p className="font-rpg-mono text-xs text-slate-400 mt-10">
          {isLast ? 'TAP / CLICK TO ENTER LACAN’S ATELIER ▶' : 'TAP / CLICK TO CONTINUE ▶'}
        </p>
      </main>
    );
  }

  // =========================================================================
  // 3. INTERACTIVE STARTER SHELL (READY FOR AI STUDIO 3D HD-2D ENGINE WIRING)
  // =========================================================================
  const currentMap = MAPS[saveData.mapId];

  return (
    <main className="relative w-full h-full bg-[#070b18] flex flex-col justify-between p-4">
      <img
        src={currentMap.battleBackdrop}
        alt={currentMap.name}
        className="absolute inset-0 w-full h-full object-cover pixelated opacity-45"
      />
      <div className="relative z-10 flex items-start justify-between gap-4">
        <div className="rpg-window px-4 py-2.5">
          <div className="font-rpg-title text-sm text-amber-300">{currentMap.name}</div>
          <div className="text-xs text-slate-300">{currentMap.subtitle}</div>
          <div className="font-rpg-mono text-[11px] text-sky-300 mt-1">
            QUEST: {saveData.questObjective}
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            audioManager.playSfx('cancel');
            setMode('TITLE_SCREEN');
          }}
          className="rpg-window px-3 py-1.5 font-rpg-mono text-xs text-amber-200 cursor-pointer"
        >
          TITLE SCREEN
        </button>
      </div>

      {/* Central Starter Status Notice */}
      <div className="relative z-10 rpg-window max-w-2xl mx-auto p-5 text-center space-y-3">
        <div className="font-rpg-mono text-xs text-amber-300">
          STARTER REPOSITORY READY FOR AI STUDIO BUILD
        </div>
        <p className="text-sm text-slate-200">
          All 100+ Episode III sprites, portraits, seamless 3D tiles, props, world map landmarks,
          battle backdrops, VFX strips, and 6 map schemas are verified and loaded. Open{' '}
          <span className="font-rpg-mono text-amber-200">AI_STUDIO_BLUEPRINT.md</span> and run
          Prompts 1–4 in AI Studio to attach the 3D HD-2D Three.js World Renderer, Chibi
          Follow-the-Leader Animator, Cutscene/Shop Director, and Side-View Combat Arena.
        </p>
        <div className="flex flex-wrap justify-center gap-2 pt-2">
          {(Object.keys(MAPS) as MapId[]).map((mid) => (
            <button
              key={mid}
              type="button"
              onClick={() => travelToMap(mid)}
              className={`px-3 py-1.5 text-xs font-rpg-mono border cursor-pointer ${
                saveData.mapId === mid
                  ? 'border-amber-400 bg-amber-400/20 text-amber-200'
                  : 'border-slate-600 bg-slate-900/70 text-slate-300'
              }`}
            >
              {MAPS[mid].name}
            </button>
          ))}
        </div>
      </div>

      <div className="relative z-10 rpg-window px-4 py-2 flex items-center justify-between text-xs font-rpg-mono">
        <div className="flex gap-4">
          {saveData.party.map((p) => (
            <span key={p.id}>
              <strong className="text-amber-200">{p.name}</strong> HP {p.hp}/{p.maxHp}
            </span>
          ))}
        </div>
        <span className="text-amber-300">{saveData.gil} G</span>
      </div>
    </main>
  );
}
