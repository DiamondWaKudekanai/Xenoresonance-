import { SaveSlotData } from '../types/game';
import { INITIAL_PARTY } from '../data/characters';

const SAVE_KEY_PREFIX = 'xenoresonance_ep3_slot_';

export function createNewGameState(slotIndex: 0 | 1 | 2): SaveSlotData {
  return {
    slotIndex,
    savedAtIso: new Date().toISOString(),
    playtimeSeconds: 0,
    mapId: 'interior_atelier',
    playerX: 0,
    playerZ: 1,
    facing: 'down',
    gil: 350,
    questObjective: 'Visit Sophia and Krelian at the Nisan Cathedral.',
    storyFlags: {},
    openedChestIds: [],
    party: INITIAL_PARTY.map((m) => ({
      ...m,
      gear: m.gear ? { ...m.gear } : null,
      deathblowMastery: { ...m.deathblowMastery },
    })),
    inventory: [
      { itemId: 'aquasol', quantity: 4 },
      { itemId: 'rosesol', quantity: 2 },
      { itemId: 'zohar_fuel_cell', quantity: 2 },
    ],
  };
}

export function loadSaveSlot(slotIndex: 0 | 1 | 2): SaveSlotData | null {
  try {
    const raw = window.localStorage.getItem(`${SAVE_KEY_PREFIX}${slotIndex}`);
    if (!raw) return null;
    return JSON.parse(raw) as SaveSlotData;
  } catch {
    return null;
  }
}

export function writeSaveSlot(data: SaveSlotData): void {
  try {
    const payload: SaveSlotData = {
      ...data,
      savedAtIso: new Date().toISOString(),
    };
    window.localStorage.setItem(`${SAVE_KEY_PREFIX}${data.slotIndex}`, JSON.stringify(payload));
  } catch {
    // Ignore quota errors
  }
}

export function listAllSaveSlots(): Array<SaveSlotData | null> {
  return [loadSaveSlot(0), loadSaveSlot(1), loadSaveSlot(2)];
}
