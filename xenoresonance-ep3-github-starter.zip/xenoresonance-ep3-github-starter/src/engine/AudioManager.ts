import { OstTrackId } from '../types/game';

/**
 * Custom OST & SFX Router
 * Automatically loads and crossfades user-supplied tracks from `/audio/ost/<track>.mp3`.
 * Fails silently with zero console errors when custom OST files haven't been dropped in yet.
 */
class AudioManagerImpl {
  private currentTrack: OstTrackId | null = null;
  private activeAudio: HTMLAudioElement | null = null;
  private bgmVolume = 0.7;
  private sfxVolume = 0.8;
  private muted = false;
  private sfxCtx: AudioContext | null = null;
  private missingTracks = new Set<OstTrackId>();

  public getCurrentTrack(): OstTrackId | null {
    return this.currentTrack;
  }

  public isTrackMissing(track: OstTrackId): boolean {
    return this.missingTracks.has(track);
  }

  public setVolumes(bgm: number, sfx: number): void {
    this.bgmVolume = Math.max(0, Math.min(1, bgm));
    this.sfxVolume = Math.max(0, Math.min(1, sfx));
    if (this.activeAudio && !this.muted) {
      this.activeAudio.volume = this.bgmVolume;
    }
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.activeAudio) {
      this.activeAudio.volume = muted ? 0 : this.bgmVolume;
    }
  }

  public playOst(track: OstTrackId): void {
    if (this.currentTrack === track) return;
    this.currentTrack = track;

    const prevAudio = this.activeAudio;
    if (prevAudio) {
      this.fadeAudio(prevAudio, prevAudio.volume, 0, 900, () => {
        prevAudio.pause();
        prevAudio.src = '';
      });
    }

    if (this.missingTracks.has(track)) {
      this.activeAudio = null;
      return;
    }

    const nextAudio = new Audio(`/audio/ost/${track}.mp3`);
    nextAudio.loop = true;
    nextAudio.volume = 0;

    nextAudio.addEventListener('error', () => {
      this.missingTracks.add(track);
      if (this.activeAudio === nextAudio) {
        this.activeAudio = null;
      }
    });

    this.activeAudio = nextAudio;
    nextAudio
      .play()
      .then(() => {
        if (!this.muted) {
          this.fadeAudio(nextAudio, 0, this.bgmVolume, 1100);
        }
      })
      .catch(() => {
        // Browser autoplay policy or file not dropped in yet
      });
  }

  public stopOst(): void {
    if (this.activeAudio) {
      this.activeAudio.pause();
      this.activeAudio = null;
    }
    this.currentTrack = null;
  }

  private fadeAudio(
    el: HTMLAudioElement,
    from: number,
    to: number,
    durationMs: number,
    onDone?: () => void
  ): void {
    const start = performance.now();
    const step = (now: number) => {
      const t = Math.min(1, (now - start) / durationMs);
      el.volume = Math.max(0, Math.min(1, from + (to - from) * t));
      if (t < 1) {
        requestAnimationFrame(step);
      } else if (onDone) {
        onDone();
      }
    };
    requestAnimationFrame(step);
  }

  public playSfx(kind: 'cursor' | 'confirm' | 'cancel' | 'chest' | 'door' | 'break'): void {
    if (this.muted || this.sfxVolume <= 0 || typeof window === 'undefined') return;
    try {
      if (!this.sfxCtx) {
        const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!Ctx) return;
        this.sfxCtx = new Ctx();
      }
      if (this.sfxCtx.state === 'suspended') {
        void this.sfxCtx.resume();
      }
      const ctx = this.sfxCtx;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      const presets: Record<typeof kind, { f0: number; f1: number; dur: number; type: OscillatorType }> = {
        cursor: { f0: 980, f1: 1240, dur: 0.055, type: 'triangle' },
        confirm: { f0: 740, f1: 1180, dur: 0.11, type: 'sine' },
        cancel: { f0: 420, f1: 260, dur: 0.09, type: 'triangle' },
        door: { f0: 210, f1: 140, dur: 0.16, type: 'sine' },
        chest: { f0: 523, f1: 1046, dur: 0.24, type: 'triangle' },
        break: { f0: 180, f1: 42, dur: 0.28, type: 'sawtooth' },
      };

      const p = presets[kind];
      osc.type = p.type;
      osc.frequency.setValueAtTime(p.f0, now);
      osc.frequency.exponentialRampToValueAtTime(p.f1, now + p.dur);

      gain.gain.setValueAtTime(0.08 * this.sfxVolume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + p.dur);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + p.dur + 0.02);
    } catch {
      // Ignore audio errors
    }
  }
}

export const audioManager = new AudioManagerImpl();
