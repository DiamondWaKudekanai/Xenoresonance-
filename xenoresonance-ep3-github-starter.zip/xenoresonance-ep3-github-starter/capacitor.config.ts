const config = {
  appId: 'com.xenoresonance.episode3',
  appName: 'Xenoresonance Episode III',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
    backgroundColor: '#050814',
  },
};

export default config;
