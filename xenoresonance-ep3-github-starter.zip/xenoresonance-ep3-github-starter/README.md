# Xenoresonance: Episode III — The Nisan Chronicles

An **Octopath Traveler HD-2D** style Android JRPG starter repository rooted in the ***Xenogears Perfect Works* Episode III** era (Year 9499 — 500 years before Episode V), featuring **Lacan**, **Sophia**, **Krelian**, and **Roni Fatima**.

## What Is Included in This Repository
- **100% AI Studio Build Compatible:** Standard Vite + React 19 + TypeScript + Three.js + Tailwind CSS v4 structure (`vite.config.ts`, `metadata.json`, `package.json`, `tsconfig.json`).
- **Pre-Cleaned Transparent Pixel Art Asset Pack (`public/assets/`):**
  - 4 uniform `512×512` `4×4` chibi 4-directional walk sheets (`lacan_walk.png`, `sophia_walk.png`, `krelian_walk.png`, `roni_walk.png`)
  - 6 town NPC directional strips (`monk`, `innkeeper`, `shopkeeper`, `child`, `guard`, `solaris_spy`)
  - 4 hero `4×1` battle strips + 3 Omnigears (`Amon`, `El-Regrs`, `Andvari`) + 2 enemies + `Prototype Diabolos` Boss
  - 8 hand-drawn `256×256` PS1-style dialogue portraits
  - 16 seamless `256×256` 3D architecture & terrain tile textures
  - 22 semantically named interior, town, and Zeboim dungeon transparent props
  - Title Screen key art + 3 HD-2D side-view battle backdrops
  - 8 overworld miniature landmarks & Shevat sky cruiser
  - 8 animated `4×1` / `2×1` Deathblow & Ether VFX strips + 9 crisp `64×64` combat weakness/status UI icons
- **Expandable JRPG Data Schemas (`src/data/`):**
  - `assets.ts` (typed asset registry + Octopath 1u=1tile scale contract)
  - `characters.ts` (stats, Deathblows, Chi/Ether arts, Omnigears, items, enemies/bosses)
  - `maps.ts` (6 interconnected maps: Ignas World Map, Town of Nisan, Lacan's Atelier, Nisan Cathedral, Nisan Inn & Armory, Zeboim Excavation Ruins)
  - `story.ts` (complete playable Chapter 1 Episode III script)
- **Custom OST Drop-In Engine (`src/engine/AudioManager.ts` & `public/audio/ost/`):** Drop your own `.mp3` soundtrack tracks into `public/audio/ost/` for automatic crossfading.
- **Android Ready (`capacitor.config.ts`):** Pre-configured for Capacitor Android APK export.

## How to Load Into Google AI Studio via GitHub
1. Extract this ZIP into a new GitHub repository and push to `main`.
2. Open **Google AI Studio → Build** and connect/import your GitHub repository.
3. Follow the 4 sequential prompts in **`AI_STUDIO_BLUEPRINT.md`** to wire the 3D HD-2D world engine, living NPCs/shops, and side-view combat system directly onto the bundled assets and data schemas.

## Run Locally
```bash
npm install
npm run dev
```
