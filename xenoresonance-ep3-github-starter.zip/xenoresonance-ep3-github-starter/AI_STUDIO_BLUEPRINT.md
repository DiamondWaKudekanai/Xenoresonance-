# AI Studio Build Blueprint — Xenoresonance: Episode III

## STRICT ARCHITECTURAL RULES FOR AI STUDIO AGENTS
Read this BEFORE editing any files in this repository:
1. **NEVER generate procedural Canvas rectangles or placeholder pixel art!** Every sprite, portrait, seamless tile, interior prop, world map landmark, battle backdrop, VFX strip, and UI icon is ALREADY pre-cleaned (transparent RGBA PNG) inside `public/assets/` and registered in `src/data/assets.ts`.
2. **Respect the Octopath HD-2D Scale Contract (`SCALE_CONTRACT` in `src/data/assets.ts`):**
   - `1.0 Three.js unit = 1 logical tile`
   - Chibi humans (`lacan`, `sophia`, `krelian`, `roni`, NPCs): `1.0u × 1.15u` vertical Y-cylindrical billboards.
   - Gears (`amon`, `elRegrs`, `andvari`, `prototypeDiabolos`): `2.6u × 3.0u` in battle.
   - **Buildings in `town_nisan` MUST be real 3D meshes** (`BoxGeometry` walls + pitched prism roofs UV-mapped to `ASSETS.tiles.*` with `THREE.NearestFilter` and `THREE.RepeatWrapping`) — NEVER 2D billboards!
   - **Interior maps (`interior_atelier`, `interior_cathedral`, `interior_inn_shop`)** MUST render as cut-away 3D rooms (floor + north/east/west 3D walls) populated with the transparent prop PNGs from `ASSETS.props.*`.
3. **Uniform Sprite UV Animation (60 FPS Android-Safe):**
   - Walk sheets (`ASSETS.sprites.*Walk`) are exact `512×512` `4×4` uniform grids (`cols=4, rows=4`, rows top-to-bottom: `down, left, right, up`). Animate with `texture.repeat.set(0.25, 0.25)` and `texture.offset.set(col * 0.25, 1 - (row + 1) * 0.25)`.
   - Battle hero strips (`ASSETS.battle.lacan/sophia/krelian/roni`) are exact `768×192` `4×1` grids (`idle, strike, ether, victory`).
   - VFX strips (`ASSETS.vfx.*`) are exact `1024×256` `4×1` grids (except `vfx_summon_circle` and `vfx_shield_break` which are `512×256` `2×1`).
4. **Bright, Warm Octopath Lighting:** Keep `ambientIntensity` between `0.78` and `0.95` and warm lantern `PointLight`s. NEVER crush the scene with stacked dark CSS overlays.
5. **Custom OST Support:** Always route music through `src/engine/AudioManager.ts` (`audioManager.playOst(...)`). Never replace it with noisy procedural synth loops.

---

## 4 SEQUENTIAL PROMPTS TO COMPLETE THE GAME IN AI STUDIO

### Prompt 1 — Build the 3D HD-2D World & Interior Renderer (`src/engine/HD2DWorldCanvas.tsx`)
> Read `AI_STUDIO_BLUEPRINT.md`, `src/data/assets.ts`, `src/data/maps.ts`, and `src/types/game.ts`.
> Build `src/engine/HD2DWorldCanvas.tsx` using Three.js and wire it into `src/App.tsx` whenever the mode is `PLAYING_WORLDMAP`, `PLAYING_TOWN`, `PLAYING_INTERIOR`, or `PLAYING_DUNGEON`.
> Requirements:
> 1. Load textures exclusively from `ASSETS` with `THREE.NearestFilter` and `THREE.SRGBColorSpace` (zero procedural Canvas drawings).
> 2. Render each map in `MAPS[mapId]`:
>    - Ground plane (`widthTiles × depthTiles`) wrapped with `groundTile` (`RepeatWrapping`).
>    - True 3D buildings from `map.buildings` (textured 3D box walls + pitched 3D roof prism + recessed glowing doorway + `accentWindowTile` on Nisan Cathedral).
>    - Cut-away 3D walls (North, West, East) for `PLAYING_INTERIOR` and `PLAYING_DUNGEON` maps.
>    - 2.5D camera-facing prop billboards from `map.props` using `ASSETS.props` / `ASSETS.worldmap` with `alphaTest: 0.5` and matching `MeshDepthMaterial` shadows.
>    - Warm flickering `PointLight`s near lanterns, fireplaces, and Memory Cubes.
> 3. Camera: Octopath fixed-tilt diorama perspective (`FOV 34°`, 28° downward tilt, smooth lerp follow, subtle parallax).
> 4. Chibi Party Leader + Follow-the-Leader Party Train (Lacan, Sophia, Krelian, Roni) using the exact `4×4` UV walk sheets in `ASSETS.sprites.*Walk`, smooth collision against buildings/props/walls, and automatic fade-to-black map transitions when stepping onto `map.warps` or building doorways.
> 5. Add `src/ui/AndroidControls.tsx`: responsive landscape floating D-Pad (left thumb) + tactile `[A] Interact`, `[B] Sprint`, `[X] Menu`, `[Y] Map` buttons (right thumb) plus WASD/Arrow/Enter/M keyboard support.

### Prompt 2 — Living NPCs, Cutscene Director, Chests, Save Points, Inn & Shop (`src/ui/DialogueOverlay.tsx`, `src/ui/ShopModal.tsx`, `src/ui/MainMenuModal.tsx`)
> Using `src/data/story.ts`, `src/data/maps.ts`, `src/data/characters.ts`, and `src/engine/SaveManager.ts`:
> 1. Render all `map.npcs` inside `HD2DWorldCanvas.tsx` using their transparent strips from `ASSETS.sprites.npcs` (or party sheets for story NPCs in `interior_cathedral`), supporting `STATIONARY`, `LOOK_AROUND`, and `PATROL_WAYPOINTS` AI. Show a floating `[A]` prompt bubble when the player is within 1.6 tiles of an NPC, chest, Memory Cube, or hologram console.
> 2. Build `src/ui/DialogueOverlay.tsx`: classic gold-trimmed slate box with the crisp `256×256` portrait from `ASSETS.portraits`, typewriter text, and story flag progression (automatically triggering `intro_atelier_wake` on first New Game entry, updating `questObjective`, and launching the `prototype_diabolos` boss battle after `scene_zeboim_boss`).
> 3. Wire interactive Treasure Chests (swapping `prop_chest_closed` -> `prop_chest_open`, awarding items, saving to `openedChestIds`), Memory Cube Save Points (opening the 3-slot Save modal), Innkeeper Bram (50G full HP/EP/Fuel rest), and Merchant Clara (`src/ui/ShopModal.tsx` buying/selling items from `ITEMS`).
> 4. Build a touch-friendly `src/ui/MainMenuModal.tsx` with tabs for Party Status, Inventory/Healing, Deathblow Mastery, Gear Hangar, Quest Log, Save/Load (3 slots), and Audio/Graphics Config (showing custom OST slot status from `audioManager`).

### Prompt 3 — Octopath Break/Boost + Xenogears AP Deathblow & Gear Battle Engine (`src/ui/BattleScene.tsx`, `src/engine/CombatEngine.ts`)
> Build the full playable side-view HD-2D Battle System (`src/engine/CombatEngine.ts` and `src/ui/BattleScene.tsx`) triggered by random encounters on `worldmap_ignas` / `dungeon_zeboim_ruins` and by the `prototype_diabolos` boss cutscene:
> 1. Render the zone's `map.battleBackdrop` (`ASSETS.backdrops.*`) with subtle depth parallax and warm lighting.
> 2. Right side: the 4 chibi heroes rendered from their `4×1` `ASSETS.battle.*` strips (stepping forward to strike, playing their `ether` and `victory` frames) — or swapping cleanly to their `ASSETS.battle.gears.*` Omnigears (`Amon`, `El-Regrs`, `Andvari`) when calling a Gear!
> 3. Left side: enemies from `ENEMIES` (`ASSETS.battle.enemies.*`) with visible Shield Counter + weakness icons rendered directly from `ASSETS.icons.*` (`fist`, `sword`, `staff`, `fire`, `lightning`, `wind`, `shield`).
> 4. Combat mechanics:
>    - Top Turn-Order Timeline showing the next 8 actor portraits.
>    - On-Foot AP Chaining (`Weak [1 AP]`, `Med [2 AP]`, `Strong [3 AP]` up to 7 AP) queueing sequential strikes and unlocking `DEATHBLOWS` (`T+X = Raijin`, `T+T+X = Senretsu`, `S+T+X = Tenbu`, `S+S+X = Kishin`) with unspent AP stored in `comboBank` (up to 28 AP for multi-Deathblow bursts).
>    - Octopath **Shield Break**: hitting enemy weaknesses reduces Shields to 0, playing `ASSETS.vfx.vfx_shield_break`, freezing for 80ms hit-stop, stunning the enemy for 1 turn, and doubling damage!
>    - Play the animated `4×1` PNG VFX strips (`ASSETS.vfx.*`) directly over targets on every Deathblow and Ether Art!
>    - Gear Combat Mode: Fuel gauge, Frame HP, Attack Level (1–3/∞), `Booster` (2× speed), and `Charge` (restore Fuel).
>    - Victory summary awarding XP, Level-Ups, Deathblow Mastery %, and Gil before returning seamlessly to the map tile and OST.

### Prompt 4 — Android Polish, Performance & Expandability Check
> Audit the complete game for Android landscape WebView / Capacitor performance:
> 1. Cap WebGL `devicePixelRatio` at `1.5`, dispose Three.js geometries/textures cleanly on map unload, and pause rendering/audio on `document.visibilityState === 'hidden'`.
> 2. Ensure all touch buttons have comfortable 48px+ hit targets and respect `env(safe-area-inset-*)`.
> 3. Verify `npm run lint` (`tsc --noEmit`) and `npm run build` pass with zero errors.
